#!/usr/bin/env bash
# Starts SDS100 Monitor from the folder this script is in.
# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
exec /usr/bin/env python3 sds100_monitor.py "$@"
