#!/usr/bin/env bash
# SDS100 Monitor installer — copies the program to ~/SDS100Monitor-<version>
# and adds it to the application menu. Never removes other versions.
# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
set -euo pipefail
VERSION="1.0-RC-Beta"
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/SDS100Monitor-$VERSION"
DESKTOP="$HOME/.local/share/applications/sds100-monitor-${VERSION,,}.desktop"
if [[ "$SOURCE" == "$(realpath -m "$DEST")" ]]; then
  echo "This copy is already installed at $DEST." >&2
  echo "Run install.sh from the downloaded source folder instead." >&2
  exit 1
fi
if ! python3 -c "import PyQt6.QtWidgets, serial" 2>/dev/null; then
  echo "Missing requirements. On Kubuntu/Ubuntu/Debian install them with:"
  echo "  sudo apt install python3-pyqt6 python3-serial"
  echo "Then run this installer again."
  exit 1
fi
mkdir -p "$DEST" "$(dirname "$DESKTOP")"
for f in sds100_monitor.py sds100-monitor.svg launch.sh uninstall.sh README.md ABOUT.md LICENSE CHANGELOG.md; do
  cp -a "$SOURCE/$f" "$DEST/"
done
chmod +x "$DEST/launch.sh" "$DEST/uninstall.sh"
cat > "$DESKTOP" <<DESK
[Desktop Entry]
Type=Application
Name=SDS100 Monitor $VERSION
Comment=Monitor and control a Uniden SDS100 scanner
Exec="$DEST/launch.sh"
Terminal=false
Categories=Utility;
Keywords=scanner;radio;SDS100;Uniden;
Icon=$DEST/sds100-monitor.svg
DESK
echo "Installed SDS100 Monitor $VERSION at $DEST"
echo "Start it from the application menu, or run: $DEST/launch.sh"
echo "The scanner must be connected by USB and set to Serial Port mode."
