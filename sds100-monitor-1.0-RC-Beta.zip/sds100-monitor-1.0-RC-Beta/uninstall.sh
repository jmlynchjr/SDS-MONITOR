#!/usr/bin/env bash
# SDS100 Monitor uninstaller — removes this version's program folder and menu
# entry. Your reception history, unit ID logs and settings are kept.
# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
set -euo pipefail
VERSION="1.0-RC-Beta"
DEST="$HOME/SDS100Monitor-$VERSION"
DESKTOP="$HOME/.local/share/applications/sds100-monitor-${VERSION,,}.desktop"
echo "This removes:"
[[ -d "$DEST" ]] && echo "  $DEST"
[[ -f "$DESKTOP" ]] && echo "  $DESKTOP"
if [[ ! -d "$DEST" && ! -f "$DESKTOP" ]]; then echo "  (nothing — version $VERSION is not installed)"; exit 0; fi
echo "Kept: ~/SDS100Monitor (reception history, unit ID logs) and ~/.config/SDS100Monitor (settings)."
read -r -p "Type yes to uninstall: " answer
[[ "$answer" == "yes" ]] || { echo "Cancelled."; exit 0; }
[[ "$DEST" == "$HOME"/SDS100Monitor-* && -d "$DEST" && ! -L "$DEST" ]] && rm -rf -- "$DEST"
rm -f -- "$DESKTOP"
echo "SDS100 Monitor $VERSION uninstalled."
