# SDS100 Monitor — Roadmap

Status at v1.0-RC-Beta (internal build 1.1.21, 26 October 2026). Items 1–12 of the October 2026 feature list are done and were reported working on the SDS100. Items 13 and 14 are deferred for future development.

All commands referenced are from the **SDS100/SDS200/SDS150 Remote Command Specification V2.00** (2025-07-07):
https://info.uniden.com/twiki/pub/UnidenMan4/SDS100FirmwareUpdate/SDS_Series_RemoteCommand_Specification_V2_00.pdf

---

## Deferred features

### 13. Event-driven status (PSI) for more accurate reception timing

**Why:** Reception start, end and duration are currently estimated from polled status (GSI every 250–5000 ms; default 500 ms). Durations are therefore accurate only to about one polling interval, and two transmissions closer together than one interval on the same channel merge into one. If the scanner pushes status by itself, the timing improves and the serial link carries fewer requests.

**What the spec says:** `PSI` — "Push scanner info as XML at intervals". The spec says the interval can be changed by a parameter but **does not name the parameter or its values**. The reply is presumably the same `<ScannerInfo>` XML as GSI.

**Unknowns to resolve first (capture samples):**
1. Exact syntax: try `PSI` alone, then `PSI,<n>` with candidate values (e.g. `PSI,500`, `PSI,1`), observing what comes back and how often. A capture-script mode that sends one PSI command and records **everything for 10–20 seconds with timestamps** is needed — the current `r` option stops after 1.5 s of silence.
2. How to stop it (`PSI,0`? `PSI,OFF`?) — essential, so the program can always turn it off on disconnect and on exit.
3. Whether pushed status arrives on change only or at a fixed interval, and whether GSI still works while PSI is active.

**Implementation sketch (once known):**
- `ScannerThread`: a "push mode" that sends PSI on connect and does not poll GSI; falls back to GSI polling if no push arrives within a few seconds. Always sends the stop command in the drain step before the port closes (see `run()`).
- Timing: record the event start/end at the time each XML block *arrives* (add a timestamp to `xml_received`), instead of poll time. Revisit `finish_event()`'s "last seen + one interval" estimate.
- Setting: Polling → "Push (PSI)" choice in the connection bar, defaulting to GSI until proven.
- Keep the CSV format unchanged.

### 14. Analyze tools and discovery

**Why:** The SDS100's Analyze functions (system status, LCN finder, activity log, RF power plot, band scope, raw data) and Discovery results would be far easier to read on the PC.

**What the spec says:**
- `AST,[mode],…` starts an analyze data stream. Modes: `CURRENT_ACTIVITY`, `LCN_MONITOR`, `ACTIVITY_LOG`, `LCN_FINDER`, `BAND_SCOPE`, `RAW_DATA_OUTPUT`, `SYSTEM_STATUS`, `RF_POWER_PLOT`. Further parameters per mode are listed in the spec but output formats are not shown.
- `APR,[mode]` pauses/resumes an analyze mode.
- `GLT,TRN_DISCOV` and `GLT,CNV_DISCOV` list Discovery sessions (fields: Name, Delay, Logging, Duration, CompareDB, SystemName/Type, SiteName, TimeOutTimer, AutoStore / Lower, Upper, Mod, Step…).

**Unknowns to resolve first:**
1. The exact parameters each AST mode needs (re-read the spec's AST section; capture with the scanner already in that Analyze screen).
2. The data format each mode streams, how fast, and how to stop it (likely leaving the mode or `APR`). The same timed-capture mode as for PSI is needed.
3. Discovery: capture `GLT,TRN_DISCOV` and `GLT,CNV_DISCOV` with `gsi_capture.py` option `r` (both already allowed), ideally after running a discovery session.

**Suggested order:** Discovery session list first (read-only `GLT`, lowest risk) → System Status → LCN Finder → RF Power Plot (graph, can reuse `BarChart`/`WaterfallGraph` drawing) → the rest.

**Implementation sketch:** a new "Analyze…" window like the Waterfall window (separate, maximizable), one tab per mode; a parser per mode tested against captured samples first, as was done for GWF.

---

## Other ideas (not yet scheduled)

Rough order of usefulness. Commands are in spec V2.00.

- **Recordings browser:** `GLT,UREC` (folders), `GLT,UREC_FILE,<folder>`, `GLT,IREC_FILE` list recording files with times. Show them next to reception history (match by time). The audio files themselves are only reachable in Mass Storage mode, not over serial.
- **Fire Tone-Out list:** `GLT,FTO` (index, frequency, mode, name, tone A/B) — show, and jump to Tone-Out mode (`JPM,FTO_MODE,…`).
- **Custom search banks:** `GLT,CS_BANK` (name, lower/upper, mode, step) — show; start a bank search (`JPM,CTM_MODE,…`).
- **Number-tag jump:** `JNT,[FL_TAG],[SYS_TAG],[CHAN_TAG]` — type a number tag to jump to a channel.
- **Display mirror:** `STS` returns the scanner's display lines; could show a "scanner screen" panel.
- **Menu control:** `MNU`, `MSI` (menu status as XML), `MSV` (set value), `MSB` (back) — remote menu navigation. Larger job; needs samples of `MSI`.
- **Power off button:** `POF` (with confirmation).
- **Waterfall efficiency:** `GW2` returns the same 240 points as binary (smaller than GWF's hex text). Note the spec's GW2 section prints "GWF" in its syntax lines — likely a copy error; needs a sample.
- **Alerts:** per-rule sound choice; quiet hours; option to log alerts to a CSV.
- **Charts:** export chart data to CSV; compare two periods.
- **Unit ID log:** let the user give names to unit IDs (stored locally) and show those names in the live panel, history and alerts.
- **SDS200 support:** volume 0–29 and squelch 0–19 are already handled from the model reply; everything else is untested on an SDS200.

### Housekeeping

- **Help:** Help → About and Help → License exist since v1.0-RC-Beta. A short user guide (Help → User Guide) would still help new users.
- **Relationship with the database & favorites manager:** this program descends from an earlier version that also had a database/favorites panel. Decide whether the two stay separate programs or are combined.
- **Before 1.0 final:** review the Uniden remote-command specification's terms; test with a second scanner or firmware version; add screenshots to the README; collect beta feedback.
- **Code size:** `sds100_monitor.py` is ~4,000 lines in one file. If it keeps growing, split into modules (serial thread, waterfall, scanner tools, history/charts, main window). The tests load the single file by path and would need the same change.

---

## Worth re-checking on the scanner

These were built from the spec and pass the tests, but specific paths may not yet have been exercised on real hardware:

| Area | What to check |
|---|---|
| Lists → **site** hold / avoid | The spec doesn't confirm `HLD,SITE` / `AVD,SITE`. If the scanner replies NG, remove SITE from `HOLDABLE`. |
| Lists → **permanent avoid** and **remove avoid** | Confirm the Avoid column updates after the automatic refresh. |
| Lists → **long lists** | Lists sent in parts (`<Footer … EOT="0">`) are requested again automatically — only seen in the spec, not in a capture. A department with hundreds of talkgroups would test it. |
| Lists → element names below favorites lists | The spec only shows `<FL>` XML. Systems/departments/channels are read generically; if the scanner uses other attribute names, capture `GLT,SYS,<fl index>` etc. and adjust `ScannerTools.make_item()`. |
| **Quick Search Hold** format | The program learned which frequency format the scanner accepts and stored it as `qsh_format` in the settings file (`100hz` or `mhz` — see DEVELOPER_NOTES). Worth recording which one it is, and removing the fallback once confirmed. |
| **Clock** daylight-saving | The DST value is copied back unchanged. Re-check after the next daylight-saving change (early November and March). |
| **Location** | The format is copied from the scanner's own reply. Capture `LCR` (option `r`) for the notes. |
| **START WATERFALL (JPM)** | Sends `JPM,WF_MODE,0` (index marked "Reserve" in the spec). Note whether it replies OK or NG; the FUNC + search key method is the documented one. |
| Keypress diagnostic | `KEY` modes L/H/R are undocumented; only FUNC + `KEY,<key>,L` long presses were verified (4, 8, 9, AVOID, REPLAY). Holding AVOID without FUNC is still untested. |
| Alerts on other desktops | Notifications use `notify-send` (present on Kubuntu), falling back to a tray icon; sound uses `paplay`, falling back to a beep. |
