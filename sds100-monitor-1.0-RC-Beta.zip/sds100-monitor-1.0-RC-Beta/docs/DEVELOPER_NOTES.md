# SDS100 Monitor — Developer notes (v1.0-RC-Beta)

Technical notes for continuing development. Read with `ROADMAP.md`. Released as **v1.0-RC-Beta**, which is internal build 1.1.21.

## 1. What the program is

A PyQt6 desktop program for Kubuntu that connects to a **Uniden SDS100** over USB serial (`/dev/ttyACM0`, scanner in *Serial Port* mode) and provides live monitoring, reception history and statistics, scanner and keypad control, a waterfall window, scanner configuration tools, alerts, charts and a unit ID log.

- Lineage: based on SDS100 Monitor **V24**, with V24's database/favorites dock removed; versions continue as 1.1.x. Earlier installs V9 and V24 are separate programs.
- One Python file: `sds100_monitor.py` in the repository root (~4,000 lines). Requires `python3-pyqt6` and `python3-serial`; Python 3.9+ (uses `str.removesuffix` and `:=`).
- Each version installs to its own folder `~/SDS100Monitor-<version>/` with its own menu entry; `install.sh` never removes other versions.

## 2. Project rules (keep these)

1. **New version number for every build delivered** — bump `VERSION` in `sds100_monitor.py`, `VERSION` in `install.sh` and `uninstall.sh`, the version badge and install paths in `README.md`, the version line in `ABOUT.md`, and add a `CHANGELOG.md` entry. Never reuse a number. (Internal builds used 1.1.x; public releases continue from 1.0-RC-Beta.)
2. **The reception history CSV format never changes** (`HEADERS`). New per-reception data goes in separate files (as the unit ID log does) or is display-only (Site, Unit ID).
3. **Verify formats with real captures before relying on them.** Where the spec is vague, build defensively: read first and mirror the scanner's format (clock, location), try a documented alternative and remember what works (QSH), confirm the result by reading back, and tell the user plainly when something is unknown.
4. **Safety:** confirm before permanent or surprising actions (temporary/permanent avoid, quick-key changes affect the whole set); keys that mean different things in different modes are enabled only when the mode is detected (waterfall soft keys); the capture tool only sends read-only commands; never leave a key held (diagnostic release on close/disconnect); one program on the serial port at a time.
5. **User data is never modified** by cleanup or the archive browser; damaged CSV files are skipped with a warning, never rewritten.

## 3. Code map

| Lines (approx.) | Name | Role |
|---|---|---|
| top | `VERSION`, `DATA_DIR`, `DAILY_LOG_DIR`, `HEADERS` | constants; history CSV columns |
| ~123 | `HistoryArchiveBrowser` | History → Browse CSV archives (read-only, paged 250 rows) |
| ~290 | `port_users()` | Linux `/proc` scan for other processes holding the serial port |
| ~319 | `ScannerThread` | the only code that touches the serial port (QThread) |
| ~482 | `KeyProtocolDiagnostic` | experimental `KEY` mode tester (P/L/H/R) |
| ~611 | `parse_mhz()`, `parse_step_mhz()` | `' 162.550000MHz'` → `162.55`; `'25kHz'` → `0.025` |
| ~632 | `WaterfallGraph` | FFT trace + scrolling waterfall from GWF frames; hover/double-click to tune |
| ~772 | `WaterfallWindow` | separate, maximizable waterfall window (View → Waterfall…) |
| ~788 | `RotaryDial` | clickable knob in the keypad panel |
| ~838 | `SERVICE_TYPES`, `LIST_KINDS`, `HOLDABLE` | service type names (PST1–37, ST1–10); GLT list hierarchy |
| ~863 | `ScannerTools` | View → Scanner Tools…: Lists, Quick Keys, Service Types, Location (+ Alerts tab) |
| ~1463 | `alert_matches()`, `AlertsPanel` | alert rule matching; Alerts tab |
| ~1587 | `load_reception_rows()`, `BarChart`, `ActivityCharts` | History → Activity Charts… |
| ~1795 | `UNIT_LOG_DIR`, `UNIT_HEADERS`, `UnitIdLog` | unit ID logging and History → Unit ID Log… |
| ~1906 | `Monitor` | main window: docks, controls, reply routing, status processing, settings, Help → About / License (reads `ABOUT.md` and `LICENSE` next to the program) |

Main window panels (docks, tabbed by default): LIVE MONITOR (statistics + history), SCANNER CONTROL (holds/avoid, audio, recording, clock, tune), SDS100 KEYPAD, SCANNER INFORMATION. Separate windows: Waterfall, Scanner Tools, Activity Charts, Unit ID Log, Archive Browser, Keypress Diagnostic.

### Serial thread (`ScannerThread.run`)

- Refuses to start if `port_users()` finds another process on the port; opens with `exclusive=True`.
- On connect: emits `CONNECTED`, sends `MDL` and `VER`.
- Loop (~0.1 s read timeout): send one queued command (FIFO `queue.Queue`, filled by `send_command()` from the GUI thread); send `GSI` every `poll_ms`; while `graph_enabled`, send `GWF,1,ON` every `graph_ms`; read and `consume()`.
- On stop: sends everything still queued (e.g. a key release) before closing the port, then emits `DISCONNECTED`.
- `consume(buf)` handles data strictly in arrival order:
  - `<ScannerInfo>…</ScannerInfo>` → `xml_received(str)` (GSI)
  - `<GLT>…</GLT>` or `<GLT />` → `list_received(str)`
  - other lines (ending in CR **or LF**) → `emit_reply()`: `GWF,` frames → `graph_received(list[int])`; framing lines (`GSI,<XML>,`, `GLT,<XML>,`, `<?xml…`) dropped; everything else → `command_result("REPLY: …")`, **untruncated** (quick-key replies are ~200 characters; truncating them was the v1.1.21 bug).
  - The thread also emits `command_result("SENT: …")` for each command sent.

### Reply routing in the GUI

`command_result` is connected to `Monitor.command_reply`, `Monitor.scanner_identity` (MDL/VER → status bar) and `Monitor.scanner_output` (re-emitted for the diagnostic window). `command_reply()` first calls `route_reply()`, which offers the reply to:

1. `ScannerTools.route()` (if the window has been opened): `FQK/SQK/DQK`, `SVC`, `LCR`, `GLT` errors — and hides their `SENT:` lines.
2. Battery (`GCS`, polled every 30 s, kept out of the status line), clock (`DTM` while a read/sync is in progress), Quick Search Hold (`QSH`), recording errors (`URC,ERR,…`).

Anything not consumed is shown (shortened to 160 characters) in the Control, Keypad and Waterfall status lines.

### Status processing (`Monitor.process_xml`, once per GSI)

1. Finds the channel element: `ConvFrequency`, `TGID`, `TrunkingChannel` or `SrchFrequency`. Records indices for hold/avoid (`4294967295` = no index).
2. Builds `info` (System, Department, Channel, Frequency, Talkgroup, Mode, RSSI). Search/Close Call hits: System = mode, Department = search bank, Channel = frequency. Trunked frequency comes from `SiteFrequency`.
3. Display-only: Site (`Site@Name`), Unit ID (`UnitID@U_Id`, shown as "Name (UID)" when it has a name).
4. Updates the waterfall status/graph band, audio sliders, recording state, QSH confirmation.
5. Reception events: receiving = `Property@Mute == "Unmute"` and a channel name. A change of (System, Department, Channel, Frequency, Talkgroup) starts a new event. `finish_event()` writes the CSV row; end = last seen + one polling interval.
6. Alerts: checked when an event starts, and when a new unit ID appears (P25 often reports the unit a moment later) — at most one alert per reception plus a per-rule cooldown.
7. Unit ID log: one row each time a different unit is heard during receiving.

## 4. Scanner protocol — what is known

**Verified** = confirmed from captures in `tests/samples/`. **Reported working** = built from the spec and reported working on the SDS100 during testing on 26 Oct 2026, without a captured sample. **In use since before 1.1.12** = already in the program before this round of work. **Spec only** = from spec V2.00, not yet exercised.

| Command / data | Format | Status |
|---|---|---|
| Line endings | Replies end in CR. **GCS ends in LF.** GSI and GLT XML contain CRs between elements. | Verified (GSI); GCS from spec; reader accepts both |
| `GSI` | `GSI,<XML>,\r<?xml…?>\r<ScannerInfo Mode="…" V_Screen="…">…</ScannerInfo>\r` | Verified |
| GSI conventional / trunked | `<ConvFrequency …>`; trunked: `<TGID Name Index TGID="TGID:44002" SvcType …>`, `<UnitID Name U_Id>` (empty `<UnitID />` when none), `<Site Name Index>`, `<SiteFrequency Freq=" 859.962500MHz">`. Idle ID scanning: `TGID="TGID: ---"`, department without Name, Index 4294967295. | Verified |
| GSI search / Close Call | `<SrchFrequency Freq=" 52.000000MHz" Mod TGID="TGID None" U_Id="UID None">`, `<SearchBanks Name="Custom 3">`, `<SearchRange Lower Upper>`; Mode "Custom Search" / "Close Call Only" | Verified (Close Call only while muted) |
| GSI waterfall | Mode="Waterfall"; `<WaterfallBand Lower Center Upper Mod Step="25kHz" Span="1.44MHz" Limit>`, `<WaterfallSettings MF Gain="Auto">` | Verified |
| GSI `Property` | `VOL`, `SQL`, `Rec="Off/On"`, `Mute="Mute/Unmute"`, `Rssi` (-999 = none), `Sig`, `P25Status` | Verified |
| `GWF,1,ON` | **One frame per request** (not a stream): `GWF,` + 240 two-digit hex levels (0–255), comma-separated, trailing comma, CR. Bin i = Lower + i·Span/240; center at bin 120. Noise ~50–70, strong carrier ~180. | Verified |
| `GWF,1,OFF` | Also returns a frame; sent when the graph stops | Verified (reply seen) |
| `FQK` | `FQK,` + 100 values (0 none, 1 disabled, 2 enabled), ~200 chars | Verified |
| `SQK,<fl qk>` / `DQK,<fl qk>,<sys qk>` | Get replies may repeat the quick keys before the 100 values — the program takes the **last 100**. Set: `SQK,<fl>,<100 values>`, `DQK,<fl>,<sys>,<100 values>`; 0 values are ignored by the scanner. | Spec; reported working |
| `GLT,FL` | `GLT,<XML>,\r…<GLT>\r<FL Index Name Monitor Q_Key N_Tag />…</GLT>` | Spec example; reported working |
| `GLT,SYS/DEPT/SITE/CFREQ/TGID/SFREQ,<index>` | Elements assumed to be named like the list type, attributes per spec field lists. Long lists: `<Footer No EOT="0">` → send the same command again for the next part. | Spec; reported working (paging not seen) |
| `HLD,<SYS/DEPT/CFREQ/TGID>,<index>,` | Hold. `SITE` not confirmed. | In use since before 1.1.12; SITE spec only |
| `AVD,<kind>,<index>,,<1 perm / 2 temp / 3 stop>` | Avoid | Temporary/stop in use since before 1.1.12; permanent spec only |
| `PRV`/`NXT,<kind>,<index>,,1` | previous/next | In use since before 1.1.12 |
| `JPM,SCN_MODE,4294967295` | resume scanning | In use since before 1.1.12 |
| `JPM,WX_MODE,NORMAL` | weather scan | Documented; in use since before 1.1.12 |
| `JPM,WF_MODE,0` | index is "Reserve" in the spec | Unknown result |
| `KEY,<code>,P` | press; codes: M F L 0–9 . E > < ^ V Y A B C R (A/B/C = soft keys 1–3; V = backlight on SDS100) | In use since before 1.1.12; waterfall soft keys reported working |
| `KEY,F,P` then `KEY,<k>,L` | FUNC + long press for 4, 8, 9, L (AVOID), Y (REPLAY) | Verified by user |
| `VOL,n` / `SQL,n` | 0–15 on SDS100 (0–29 / 0–19 SDS200). Set reply is bare `VOL` / `SQL`. | Reported working |
| `GCS` | `GCS,CST=n,VOLT=nmV:n%,CURR=±nmA,TEMP= n.nnC\n`; CST 0 no ext. power, 1 gauge init, 2 temp NG, 3 power NG, 4 full, 5 recharge, 6 charging | Spec; reported working |
| `URC` / `URC,0/1` | recording; errors `URC,ERR,0001` file, `0002` low battery, `0003` session limit, `0004` RTC lost | Spec; reported working |
| `DTM` | get `DTM,<dst>,YYYY,MM,DD,hh,mm,ss,<rtc 0/1>` (8 fields); set without RTC field. DST value undefined — the program copies the scanner's own value back. | Reported working |
| `QSH,<freq>` | Frequency format undefined in the spec. The program tries 100 Hz units (`01624000`, BCD536HP convention), falls back to MHz (`162.400000`), verifies via GSI, remembers the working one in setting `qsh_format`. Not accepted in menus / Direct Entry / Quick Save. | Reported working; **which format** is in the settings file |
| `SVC` | 37 preset + 10 custom values, 0/1 | Spec; reported working |
| `LCR` | `LCR,<lat>,<lon>,<range>` "degree format"; the program mirrors the decimal places read from the scanner and refuses to set if the format isn't plain numbers. | Spec; reported working |
| `MDL` / `VER` | `MDL,SDS100`, `VER,Version x.xx.xx` | Verified |

**Two programs on one port** corrupt each other's data (Linux lets two processes open a tty; each gets part of the stream) — see `tests/samples/corrupted/`. Since v1.1.17 the program refuses to connect in that case.

## 5. Files the program writes

| Path | Contents |
|---|---|
| `~/SDS100Monitor/history/reception_history_YYYY-MM-DD.csv` | one row per reception: `Start, End, Duration (s), System, Department, Channel, Frequency, Talkgroup, RSSI (dBm)` — **format fixed** |
| `~/SDS100Monitor/reception_history_v6.csv` | legacy history (read only) |
| `~/SDS100Monitor/unit_ids/unit_ids_YYYY-MM-DD.csv` | `Time, Unit ID, Unit Name, System, Site, Department, Channel, Talkgroup, Frequency` (since v1.1.20) |
| `~/.config/SDS100Monitor/Monitor110.conf` | Qt settings (shared by all 1.1.x versions, so layouts carry over) |

Settings keys: `port`, `baud`, `poll_ms`, `geometry`, `dock_state`, `floating/<dock>`, `reception_splitter`, `waterfall/geometry`, `waterfall/splitter`, `waterfall/open`, `waterfall/graph_on`, `waterfall/graph_ms`, `qsh_format` (`100hz` or `mhz`), `tools/places` (JSON list of saved locations), `alerts/rules` (JSON list of `{field, match, text, enabled}`), `alerts/notify`, `alerts/sound`, `alerts/cooldown`.

## 6. Testing

`bash tests/run_tests.sh` — see `tests/README.md`. PyQt6 and pyserial are replaced with stubs (`tests/harness.py`), so the tests run anywhere with Python 3.9+, but they only check logic: serial parsing, reply handling, scanner data parsing, history, alerts, charts, unit log. **Drawing, layouts and real widget behaviour are not tested** — check those by running the program. When adding a feature that depends on a scanner reply: capture a real sample first, add it to `tests/samples/` (replace unit IDs or other identifying values first), and add a test that feeds it through the real parsing code.

## 7. Samples (`tests/samples/`)

Real replies captured from an SDS100 in October 2026. Radio unit IDs have been replaced with fictitious values (UID:1000001–1000003).

| File | What it shows |
|---|---|
| `status_trunk-call_*.txt` | P25 trunked calls on Palmetto 800 (Mode "Trunk Scan Hold"), with unit IDs and site frequency |
| `status_trunk-call-unit_*.txt` | trunked call while scanning, unit reported |
| `status_trunk-scan-muted_*.txt`, `status_trunk-scan-id-scanning_*.txt` | between calls; ID scanning (no department name, `TGID: ---`) |
| `status_search-hit_*.txt` | Custom Search hits (52.000 and 411.650 MHz) |
| `status_closecall-muted_*.txt` | Close Call mode between hits |
| `status_waterfall_*.txt` | waterfall mode, 1.44 MHz span around 162.550 (NOAA) |
| `gwf_waterfall*.txt` | two GWF frames each (busy and quiet), carrier at bin 120 |
| `reply_fqk_*.txt` | FQK reply, quick keys 0–8 enabled |
| `corrupted/` | a status reply spliced by two programs reading at once (example of what the port lock prevents) |

## 8. Version history since 1.1.12 (summary — details in `CHANGELOG.md`)

| Version | Change |
|---|---|
| 1.1.13 | Bug fixes: replies dropped next to GSI; statistics reset on connect; crash on damaged CSV; queued commands/held keys lost on disconnect; REMOVE AVOID targeting; diagnostic log after reconnect; consistent durations. Live polling interval, model/firmware in status bar. |
| 1.1.14 | Search/Close Call hits logged; trunked frequency from SiteFrequency |
| 1.1.15 | Site and Unit ID display; cleanup keeps only the newest version (`--keep`) |
| 1.1.16 | Waterfall control panel (soft keys, tuning, marker entry, mode-gated) |
| 1.1.17 | Live waterfall graph (GWF), click-to-tune; serial port lock |
| 1.1.18 | Waterfall in its own maximizable window (View → Waterfall…) |
| 1.1.19 | Volume/squelch, battery (GCS), recording (URC), clock (DTM), Quick Search Hold (QSH) |
| 1.1.20 | Scanner Tools (Lists, Quick Keys, Service Types, Location, Alerts), Activity Charts, Unit ID Log |
| 1.1.21 | Fix: replies were truncated at 160 characters, breaking quick keys |
| **1.0-RC-Beta** | Public release candidate of 1.1.21: GPL-3.0-or-later, ABOUT.md, Help → About / License, uninstall.sh, docs and tests in the repository |

## 9. References

- SDS100/SDS200/SDS150 Remote Command Specification **V2.00** (Uniden, 2025-07-07): https://info.uniden.com/twiki/pub/UnidenMan4/SDS100FirmwareUpdate/SDS_Series_RemoteCommand_Specification_V2_00.pdf
- SDS100/SDS200 Remote Command Specification V1.02 (2023-12-22): https://info.uniden.com/twiki/pub/UnidenMan4/SDS200FirmwareUpdate/SDS200_RemoteCommand_Specification_V1_02.pdf
- SDS200 Waterfall manual (applies to SDS100): https://rigpix.com/bearcat/sds200_waterfall_manual.pdf
- Easier to Read SDS100/200 Manual, Key Operations (pp. 7–8) — source for the keypad reference text.
