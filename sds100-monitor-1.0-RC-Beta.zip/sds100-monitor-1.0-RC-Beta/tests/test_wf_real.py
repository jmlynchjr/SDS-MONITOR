# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob
import xml.etree.ElementTree as ET
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Label:
    def __init__(s): s.t=""; s.en=None
    def setText(s,t): s.t=t
    def text(s): return s.t
    def setEnabled(s,v): s.en=v
    def __getattr__(s,n): return lambda *a: None
class Check:
    def isChecked(s): return False
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness
mon = harness.monitor(m)
mon.waterfall_gated=[harness.Fake()]; mon.waterfall_entry=[harness.Fake()]
logged=[]; mon.finish_event=lambda: (logged.append(1) if mon.event else None, setattr(mon,"event",None))
t=open(sorted(glob.glob(sys.argv[2]+"/status_waterfall_*.txt"))[0]).read()
mon.process_xml(t[t.index("<ScannerInfo"):t.index("</ScannerInfo>")+14])
print(mon.waterfall_mode_label.t, "| controls enabled:", mon.waterfall_gated[0].en)
for k,v in mon.wf_fields.items(): print(f"  {k:11} {v.t}")
print("  live status:", mon.status.t, "| reception logged:", bool(mon.event))
