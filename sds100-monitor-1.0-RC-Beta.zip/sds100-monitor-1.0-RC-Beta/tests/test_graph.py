# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob, random
class Meta(type):
    def __getattr__(cls, n): return Dummy()
class Dummy(metaclass=Meta):
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Sig:
    def __init__(self): self.got=[]
    def emit(self,v): self.got.append(v)
# 1. real serial data through the thread parser, mixed with a GSI reply and a KEY reply
raw = b"".join(open(f,"rb").read() for f in sorted(glob.glob(sys.argv[2]+"/gwf_*.txt")))
gsi = open(glob.glob(sys.argv[2]+"/*status_waterfall*.txt")[0],"rb").read()
first = raw.index(b"\r") + 1
stream = raw[:first] + b"KEY,OK\r" + raw[first:] + gsi + b"GWF,NG\r"
t = object.__new__(m.ScannerThread); t.xml_received=Sig(); t.command_result=Sig(); t.graph_received=Sig()
buf=b""
for i in range(0, len(stream), 97): buf = t.consume(buf + stream[i:i+97])   # odd chunk sizes
print("frames parsed:", len(t.graph_received.got), "| replies:", t.command_result.got, "| GSI blocks:", len(t.xml_received.got))
frames = t.graph_received.got
# 2. graph widget logic
g = object.__new__(m.WaterfallGraph); m.WaterfallGraph.__init__.__wrapped__ if False else None
g.update=lambda: None; g.width=lambda: 480
m.WaterfallGraph.__init__(g)   # base QWidget is a stub, so this only runs our code
g.set_band(161.83, 163.27, 162.55, 0.025)
print("message before frames:", g.message)
random.seed(1)
for k in range(200):     # replay real frames with jitter, plus a burst at 162.400 for rows 60-120
    f = list(frames[k % len(frames)])
    f = [max(0,min(255,v+random.randint(-6,6))) for v in f]
    if 60 <= k < 120:
        b = round((162.400-161.83)/1.44*240); f[b-1:b+2] = [150,200,150]
    g.add_frame(f)
print("rows:", g.row_count, "floor:", round(g.floor,1))
print("mhz_at(240px of 480):", g.mhz_at(240), "| mhz_at(0):", g.mhz_at(0), "| mhz_at(480):", g.mhz_at(480))
g.set_band(150.0, 155.0, 152.0, None); print("after span change rows:", g.row_count, "msg:", g.message)
# render the buffer from before the span change
g2 = object.__new__(m.WaterfallGraph); g2.update=lambda: None; m.WaterfallGraph.__init__(g2); g2.set_band(161.83,163.27,162.55,0.025)
random.seed(1)
for k in range(200):
    f=[max(0,min(255,v+random.randint(-6,6))) for v in frames[k%len(frames)]]
    if 60<=k<120:
        b=round((162.400-161.83)/1.44*240); f[b-1:b+2]=[150,200,150]
    g2.add_frame(f)
from PIL import Image
img = Image.frombytes("RGBA",(240,200),bytes(g2.rows),"raw","BGRA").resize((720,400),Image.NEAREST)
img.save("waterfall_preview.png"); print("saved preview")
