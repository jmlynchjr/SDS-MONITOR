# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob, re
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Label:
    def __init__(s): s.t=""
    def setText(s,t): s.t=t
    def text(s): return s.t
    def __getattr__(s,n): return lambda *a: None
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness
mon = harness.monitor(m)
rows=[]; mon.finish_event=lambda: (rows.append(dict(mon.event["info"])) if mon.event else None, setattr(mon,"event",None))
samples = sorted(x for x in glob.glob(sys.argv[2]+"/status_*.txt") if "<ScannerInfo" in open(x).read())
alias = open([x for x in samples if "UID:1000002" in open(x).read()][0]).read().replace('UnitID Name="UID:1000002"','UnitID Name="Engine 12"')
for name, text in [(re.sub(r"^[0-9a-f]+-","",f.split("/")[-1]), open(f).read()) for f in samples] + [("trunk with unit alias (edited)", alias)]:
    mon.process_xml(text[text.index("<ScannerInfo"):text.index("</ScannerInfo>")+14])
    print(f"{name:32} Site={mon.fields['Site'].t!r:32} UnitID={mon.fields['Unit ID'].t!r}")
mon.finish_event(); print("CSV/event keys unchanged:", sorted(rows[-1]))
