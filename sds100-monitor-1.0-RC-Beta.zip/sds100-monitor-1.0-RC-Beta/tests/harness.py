# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
"""Shared test helpers: load sds100_monitor.py without PyQt6/pyserial, and build
a stand-in main window with every attribute the status-processing code uses.

PyQt6 and pyserial are replaced by stubs, so the program's logic can be
exercised on any machine. Real widgets are replaced by Fake objects that just
record what was set on them (text, style, enabled, value…).
"""
import importlib.util
import sys
import types


class _Meta(type):
    def __getattr__(cls, name):
        return Dummy()


class Dummy(metaclass=_Meta):
    """Stands in for any Qt class, enum or function."""
    def __init__(self, *a, **k): pass
    def __getattr__(self, name): return Dummy()
    def __call__(self, *a, **k): return Dummy()


def load(path):
    """Import the program with Qt and serial stubbed out; returns the module."""
    for name in ["PyQt6", "PyQt6.QtCore", "PyQt6.QtGui", "PyQt6.QtWidgets",
                 "serial", "serial.tools", "serial.tools.list_ports"]:
        mod = types.ModuleType(name)
        mod.__getattr__ = lambda n: Dummy
        sys.modules[name] = mod
    spec = importlib.util.spec_from_file_location("sds100_monitor", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Signal:
    """Collects emitted values (stands in for a pyqtSignal)."""
    def __init__(self): self.got = []
    def emit(self, value): self.got.append(value)


class Fake:
    """Records what the program sets on a widget."""
    def __init__(self, text=""):
        self.t, self.style, self.tip, self.en, self.vis, self.v, self.chk = text, "", "", None, None, 0, False
    def setText(self, t): self.t = t
    def text(self): return self.t
    def setStyleSheet(self, s): self.style = s
    def setToolTip(self, s): self.tip = s
    def setEnabled(self, v): self.en = v
    def isEnabled(self): return bool(self.en)
    def setVisible(self, v): self.vis = v
    def isVisible(self): return bool(self.vis)
    def setValue(self, v): self.v = v
    def setChecked(self, v): self.chk = v
    def isChecked(self): return self.chk
    def __getattr__(self, name): return lambda *a, **k: None


class Settings(dict):
    def value(self, key, default=None): return self.get(key, default)
    def setValue(self, key, value): self[key] = value


INFO_FIELDS = ("System", "Site", "Department", "Channel", "Frequency", "Talkgroup",
               "Unit ID", "Mode", "RSSI")
WATERFALL_FIELDS = ("Center", "Span", "Range", "Step", "Modulation", "Marker", "Gain")


def monitor(m):
    """A main window object with neutral state, ready for process_xml()."""
    mon = object.__new__(m.Monitor)
    mon.settings = Settings()
    mon.fields = {k: Fake() for k in INFO_FIELDS}
    mon.wf_fields = {k: Fake() for k in WATERFALL_FIELDS}
    for name in ("status", "signal", "waterfall_mode_label", "waterfall_freq", "command_status",
                 "keypad_feedback", "waterfall_feedback", "battery_label", "rec_indicator",
                 "rec_button", "rec_state_label", "clock_label", "scanner_label"):
        setattr(mon, name, Fake())
    mon.waterfall_override = Fake()
    mon.waterfall_graph = Fake()
    mon.waterfall_graph_on = Fake()
    mon.waterfall_window = Fake()
    mon.audio_sliders = {"VOL": Fake(), "SQL": Fake()}
    mon.audio_labels = {"VOL": Fake(), "SQL": Fake()}
    mon.waterfall_gated, mon.waterfall_entry = [], []
    mon.thread = None
    mon.event = None
    mon.connected = True
    mon.waterfall_active = False
    mon.active_poll_ms = 500
    mon.audio_hold_until = 0.0
    mon.recording = None
    mon.clock_step = mon.pending_qsh = mon.qsh_verify = None
    mon.last_unit_key = None
    mon.event_alerted = False
    mon.alert_rules, mon.alert_last = [], {}
    mon.scanner_tools = None
    mon.statusBar = lambda: Fake()
    mon.logged_units = []
    mon.log_unit = lambda values, uid, name: mon.logged_units.append((uid, values.get("Channel")))
    mon.notify = lambda title, text: None
    return mon
