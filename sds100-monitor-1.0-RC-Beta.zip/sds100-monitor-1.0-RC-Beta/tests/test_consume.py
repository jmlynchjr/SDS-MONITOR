# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
class Sig:
    def __init__(self): self.got=[]
    def emit(self,v): self.got.append(v)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
def run(chunks):
    t = object.__new__(m.ScannerThread); t.xml_received=Sig(); t.command_result=Sig()
    buf=b""
    for c in chunks: buf = t.consume(buf + c)
    return t.command_result.got, len(t.xml_received.got), buf
gsi = b'GSI,<XML>,\r<?xml version="1.0" encoding="utf-8"?>\r<ScannerInfo Mode="Trunk Scan">\r<System Name="X"/>\r</ScannerInfo>\r'
cases = {"reply alone":[b"KEY,OK\r"], "reply + GSI same read":[b"KEY,OK\r"+gsi],
 "GSI then reply":[gsi+b"KEY,OK\r"], "GSI, reply, partial GSI":[gsi+b"KEY,OK\r"+gsi[:60], gsi[60:]],
 "byte by byte":[bytes([b]) for b in b"MDL,SDS100\r"+gsi+b"VER,Version 1.23.06\r"]}
for k,v in cases.items(): print(f"{k:26}", run(v))
