# Tests

```
bash tests/run_tests.sh
```

Runs every test against `sds100_monitor.py` in the repository root, using the scanner captures in `tests/samples/` (real replies from an SDS100; radio unit IDs replaced with fictitious values). Needs only Python 3.9+: PyQt6 and pyserial are replaced by stubs (`harness.py`), and widgets by small fakes that record what the program sets on them. The script ends with "All tests ran without errors" or lists the tests that failed.

The tests print what they checked rather than asserting silently, so read the output against the expectations below. They cover **logic only**; window drawing, layout and real widget behaviour need checking in the running program.

| Test | Checks | Expected |
|---|---|---|
| `test_consume.py` | serial reader: command replies arriving with, before, after and inside GSI XML; byte-by-byte arrival | every `KEY,OK`, `MDL`, `VER` reply captured; correct number of GSI blocks; empty remainder |
| `test_drain.py` | commands queued at disconnect are still sent | writes end with `KEY,6,H`, `KEY,6,R`; messages `CONNECTED`, `DISCONNECTED` |
| `test_monitor.py` | history loading with a BOM file and a corrupt file; duration estimate | 3 receptions loaded; one warning naming the bad file; durations 3.5 and 0.5 |
| `test_samples.py` | each real status sample → what gets logged | trunk calls logged with site frequency (e.g. 859.962500MHz); search hits logged with mode/bank/frequency; muted, idle and waterfall samples not logged |
| `test_fields.py` | Site and Unit ID display | Greenville County Simulcast / Hogback Mountain; UIDs; alias shown as "Engine 12 (UID:1000002)"; CSV keys unchanged |
| `test_waterfall.py` | marker-frequency keypad sequences, mode gating, waterfall key actions | coverage limits enforced; controls only enabled in waterfall mode or with override; soft-key sequences as listed |
| `test_wf_real.py` | real waterfall status | "Waterfall mode: ACTIVE"; center 162.550000MHz, span 1.44MHz, step 25kHz; nothing logged |
| `test_graph.py` | real GWF frames through the serial reader and graph buffer | 4 frames parsed; `GWF,NG` passed through as a reply; frequency at mid-width 162.55; history clears on span change. Writes `waterfall_preview.png` (rendered waterfall) into the current folder |
| `test_v119.py` | battery, recording, audio, clock sync, Quick Search Hold (simulated replies) | battery text and low-battery colour; URC error text; slider not moved while dragging; DTM read → set (DST kept) → verify; QSH fallback, confirmation, mismatch handling |
| `test_v120.py` | GLT lists (spec example + guessed deeper levels), quick keys, service types, location, alerts, unit log, charts | lists expand to the right requests, long-list paging re-requests; quick-key colours and set commands (100 values); SVC keeps unused entries; LCR mirrors format, refuses unknown formats; rule matching; one unit log row per new unit; chart totals. (The "cooldown: 2 checks -> 2" line is two *different* rules firing, which is expected; one alert per reception is enforced in `process_xml`.) |
| `test_fqk_real.py` | the real FQK capture | 9 quick keys in use, 0–8 green; toggling key 3 sends 100 values with key 3 = 1 |

When adding a feature that depends on a scanner reply: capture it with `tools/gsi_capture.py`, save it in `tests/samples/` (replace any unit IDs or other identifying values first) (`status_…`, `gwf_…`, `reply_<command>_…`), write a test that feeds it through the real parsing code, and add it to `run_tests.sh`.
