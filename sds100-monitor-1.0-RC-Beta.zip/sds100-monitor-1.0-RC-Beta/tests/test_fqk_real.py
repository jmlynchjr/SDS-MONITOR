# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util
from collections import deque
class Meta(type):
    def __getattr__(cls, n): return Dummy()
class Dummy(metaclass=Meta):
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Sig:
    def __init__(self): self.got=[]
    def emit(self,v): self.got.append(v)
t = object.__new__(m.ScannerThread); t.xml_received=Sig(); t.command_result=Sig(); t.graph_received=Sig(); t.list_received=Sig()
raw = open(sys.argv[2],"rb").read()
t.consume(raw if raw.endswith((b"\r", b"\n")) else raw + b"\r")
reply = t.command_result.got[0]
class W:
    def __init__(s): s.style=""; s.en=None; s.tip=""; s.items=[]; s.cur=0; s.t=""
    def setStyleSheet(s,v): s.style=v
    def setEnabled(s,v): s.en=v
    def setToolTip(s,v): s.tip=v
    def setText(s,v): s.t=v
    def addItem(s,l,d=None): s.items.append((l,d))
    def clear(s): s.items=[]
    def currentData(s): return s.items[s.cur][1] if s.items else None
    def setCurrentIndex(s,i): s.cur=i
    def currentIndex(s): return s.cur
    def blockSignals(s,b): pass
    @property
    def currentIndexChanged(s): return types.SimpleNamespace(emit=lambda *a: None)
sent=[]
tools = object.__new__(m.ScannerTools)
tools.monitor = types.SimpleNamespace(connected=True, queue=lambda c: (sent.append(c), True)[1])
tools.status=W(); tools.fl_by_qk={0: "Greenville County", 2: "SC Highway Patrol"}
tools.qk_status={"FQK":None,"SQK":None,"DQK":None}
tools.qk_buttons={c:[W() for _ in range(100)] for c in ("FQK","SQK","DQK")}
tools.sqk_fav=W(); tools.dqk_sys=W()
print("routed:", tools.route(reply), "|", tools.status.t)
b = tools.qk_buttons["FQK"]
print("green (enabled):", [i for i in range(100) if "1b8a5a" in b[i].style], "| clickable:", [i for i in range(100) if b[i].en])
print("tooltip key 0:", b[0].tip.replace("\n", " / "))
print("system quick-key list choices:", tools.sqk_fav.items[:4], "…")
tools.toggle_quick_key("FQK", 3)
print("turning key 3 off would send:", sent[-1][:30] + "…", "| values:", len(sent[-1].split(",")) - 1, "| key 3 ->", sent[-1].split(",")[4])
