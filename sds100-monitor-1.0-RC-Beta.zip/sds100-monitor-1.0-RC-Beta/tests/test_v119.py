# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob, time
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
class Meta(type):
    def __getattr__(cls, n): return Dummy()
class Dummy(metaclass=Meta):
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Sig:
    def __init__(self): self.got=[]
    def emit(self,v): self.got.append(v)
print("== 1. serial: GCS reply ending in LF, then a GSI block")
gsi = open(glob.glob(sys.argv[2]+"/*status_waterfall*.txt")[0],"rb").read()
stream = b"GCS,CST=6,VOLT=3987mV:72%,CURR=+0412mA,TEMP= 27.65C\n" + gsi + b"VOL\rURC,ERR,0002\r"
t = object.__new__(m.ScannerThread); t.xml_received=Sig(); t.command_result=Sig(); t.graph_received=Sig()
buf=b""
for i in range(0,len(stream),50): buf=t.consume(buf+stream[i:i+50])
print("  replies:", t.command_result.got, "| GSI blocks:", len(t.xml_received.got))

class L:
    def __init__(s,t=""): s.t=t; s.vis=None; s.style=""; s.tip=""; s.v=0; s.max=15; s.blocked=False
    def setText(s,t): s.t=t
    def text(s): return s.t
    def setVisible(s,v): s.vis=v
    def setStyleSheet(s,v): s.style=v
    def setToolTip(s,v): s.tip=v
    def setValue(s,v): s.v=v
    def blockSignals(s,b): s.blocked=b
    def setMaximum(s,v): s.max=v
    def __getattr__(s,n): return lambda *a, **k: None
class Settings(dict):
    def value(s,k,d=None): return s.get(k,d)
    def setValue(s,k,v): s[k]=v
mon = object.__new__(m.Monitor)
sent=[]; status=[]
mon.queue=lambda c: (sent.append(c), True)[1]
mon.settings=Settings(); mon.connected=True; mon.scanner_tools=None
for a in ("command_status","keypad_feedback","waterfall_feedback","battery_label","rec_indicator","rec_button","rec_state_label","clock_label","scanner_label"): setattr(mon,a,L())
mon.statusBar=lambda: L()
mon.audio_sliders={"VOL":L(),"SQL":L()}; mon.audio_labels={"VOL":L(),"SQL":L()}
mon.recording=None; mon.clock_step=None; mon.pending_qsh=None; mon.qsh_verify=None; mon.audio_hold_until=0; mon.low_battery_warned=False
orig_reply = m.Monitor.command_reply
def reply(r): orig_reply(mon, r); status.append(mon.command_status.t)
mon.command_reply = reply

print("== 2. battery")
for r in t.command_result.got[:1] + ["REPLY: GCS,CST=0,VOLT=3550mV:12%,CURR=-0150mA,TEMP= 30.1C"]:
    before = mon.command_status.t; reply(r)
    print("  ", mon.battery_label.t, "|", mon.battery_label.tip, "| red:", "ff7b7b" in mon.battery_label.style, "| status line untouched:", mon.command_status.t == before)

print("== 3. recording")
prop = ET.fromstring('<Property Rec="On" VOL="8" SQL="3"/>'); m.Monitor.sync_recording(mon, prop)
print("  Rec=On ->", mon.rec_button.t, "| indicator:", mon.rec_indicator.vis)
mon.toggle_recording(); print("  toggle sends:", sent[-1])
reply("REPLY: URC,ERR,0002"); print("  error ->", mon.rec_state_label.t)

print("== 4. audio sync")
m.Monitor.sync_audio(mon, prop); print("  from GSI: VOL", mon.audio_sliders["VOL"].v, "SQL", mon.audio_sliders["SQL"].v)
mon.audio_timer = L(); mon.audio_pending = {}
mon.audio_changed("VOL", 12); m.Monitor.sync_audio(mon, prop)
print("  while dragging, GSI doesn't move slider:", mon.audio_sliders["VOL"].v == 8 and mon.audio_labels["VOL"].t == "12")
mon.send_audio(); print("  sends:", sent[-1])

print("== 5. clock sync")
sent.clear(); mon.sync_clock(); print("  step1 sends:", sent)
reply("REPLY: DTM,1,2026,10,26,21,40,00,1")
print("  step2 sends:", sent[-1][:5], "(keeps DST flag:", sent[-1].split(",")[1] == "1", ")")
reply("REPLY: DTM,OK"); print("  step3 sends:", sent[-1])
n = datetime.now(); reply(f"REPLY: DTM,1,{n:%Y,%m,%d,%H,%M,%S},1"); print("  result:", mon.clock_label.t)
mon.clock_step="verify"; n2 = n + timedelta(hours=1); reply(f"REPLY: DTM,1,{n2:%Y,%m,%d,%H,%M,%S},1"); print("  1h-off case:", mon.clock_label.t.splitlines()[-1][:60])
mon.read_clock(); reply("REPLY: DTM,0,2026,10,26,21,40,00,0"); print("  RTC NG:", "RTC NG" in mon.clock_label.t)

print("== 6. Quick Search Hold")
sent.clear(); mon.tune_frequency(162.4); print("  first try:", sent[-1])
reply("REPLY: QSH,NG"); print("  after NG:", sent[-1], "|", status[-1])
reply("REPLY: QSH,OK"); m.Monitor.check_qsh(mon, "162.400000MHz")
print("  confirmed:", status[-1], "| remembered format:", mon.settings.get("qsh_format"))
mon.tune_frequency(162.4); print("  next time starts with:", sent[-1])
reply("REPLY: QSH,OK"); mon.qsh_verify["deadline"] = 0; m.Monitor.check_qsh(mon, "16.240000MHz")
print("  mismatch:", status[-1][:70], "| format now:", mon.settings.get("qsh_format"))
mon.tune_frequency(162.4); reply("REPLY: QSH,NG"); reply("REPLY: QSH,NG"); print("  both rejected:", status[-1][:60])
for bad in ("600", "abc"):
    try: m.Monitor.validate_mhz(bad)
    except ValueError as e: print("  reject", bad, "->", str(e)[:50])
print("  history row freq 411.650000MHz ->", m.Monitor.validate_mhz("411.650000MHz"))
