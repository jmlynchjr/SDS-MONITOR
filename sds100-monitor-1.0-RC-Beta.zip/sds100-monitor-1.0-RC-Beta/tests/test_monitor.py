# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, tempfile, csv
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
warnings=[]
m.QMessageBox = type("QMB",(),{"warning":staticmethod(lambda *a: warnings.append(a[2]))})
tmp = Path(tempfile.mkdtemp()); m.DAILY_LOG_DIR = tmp/"history"; m.LEGACY_LOG_FILE = tmp/"legacy.csv"; m.DAILY_LOG_DIR.mkdir()
good = ["2026-10-01 10:00:00","2026-10-01 10:00:05","5.0","Sys","Dept","Chan","","100","-80"]
with open(m.DAILY_LOG_DIR/"reception_history_2026-10-01.csv","w",newline="",encoding="utf-8-sig") as f:  # BOM file
    w=csv.writer(f); w.writerow(m.HEADERS); w.writerow(good)
(m.DAILY_LOG_DIR/"reception_history_2026-10-02.csv").write_bytes(",".join(m.HEADERS).encode()+b"\r\n\xff\xfe bad bytes\r\n")
with open(m.DAILY_LOG_DIR/"reception_history_2026-10-03.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(m.HEADERS); w.writerow(good); w.writerow(good)
mon = object.__new__(m.Monitor)
mon.statistics=defaultdict(lambda:[0,0.0]); mon.total_receptions=0; mon.total_seconds=0.0
mon.filter_history=lambda *a: None; mon.refresh_stats=lambda *a: None
mon.load_history()
print("loaded receptions:", mon.total_receptions, "(expect 3: BOM file + 3rd file; bad file skipped)")
print("warnings:", [w.split("\n\n")[1] for w in warnings])
# duration
rows=[]; mon.add_row=lambda r: rows.append(r); mon.add_stat=lambda r: None; mon.csv_error_shown=False
mon.active_poll_ms=500; t=datetime(2026,10,26,12,0,0)
mon.event={"key":1,"start":t,"last":t+timedelta(seconds=3),"info":dict(System="S",Department="D",Channel="C",Frequency="",Talkgroup="",RSSI="")}
mon.finish_event(); print("duration:", rows[0][2], "(expect 3.5)")
mon.event={"key":1,"start":t,"last":t,"info":rows and mon.__dict__.get('x') or dict(System="S",Department="D",Channel="C",Frequency="",Talkgroup="",RSSI="")}
mon.finish_event(); print("single-poll duration:", rows[1][2], "(expect 0.5)")
