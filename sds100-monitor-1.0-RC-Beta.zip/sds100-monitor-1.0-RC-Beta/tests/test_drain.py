# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, queue
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Sig:
    def __init__(self): self.got=[]
    def emit(self,v): self.got.append(v)
written=[]
class FakePort:
    def __init__(s,*a,**k): pass
    def __enter__(s): return s
    def __exit__(s,*a): pass
    def write(s,b): written.append(b)
    def flush(s): pass
    def reset_input_buffer(s): pass
    def read(s,n): t.running=False; return b""   # stop after first loop
m.serial.Serial = FakePort; m.serial.SerialException = OSError; m.time.sleep=lambda s: None
t = object.__new__(m.ScannerThread); t.port="/dev/sds100-test-port-does-not-exist"; t.baud=115200; t.poll_ms=500; t.graph_enabled=False; t.graph_ms=250; t.running=True; t.commands=queue.Queue()
t.xml_received=Sig(); t.message=Sig(); t.command_result=Sig()
for c in ["KEY,F,P","KEY,6,H","KEY,6,R"]: t.commands.put(c)
t.run()
print(written); print(t.message.got)
