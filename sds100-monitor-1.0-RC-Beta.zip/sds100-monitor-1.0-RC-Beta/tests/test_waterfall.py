# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob
import xml.etree.ElementTree as ET
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
M = m.Monitor
print("== marker frequency key sequences")
for t in ["154.43", "154.4300 MHz", "462.5625", "851", "600", "abc", "1.2.3", ""]:
    try: print(f"  {t!r:16} ->", ",".join(M.waterfall_keys_for(t)))
    except ValueError as e: print(f"  {t!r:16} -> rejected: {e}")
class Label:
    def __init__(s): s.t=""; s.en=None
    def setText(s,t): s.t=t
    def text(s): return s.t
    def setEnabled(s,v): s.en=v
    def isEnabled(s): return s.en
    def __getattr__(s,n): return lambda *a: None
class Check:
    v=False
    def isChecked(s): return s.v
mon = object.__new__(M)
mon.wf_fields={k:Label() for k in ("Center","Span","Range","Step","Modulation","Marker","Gain")}
mon.waterfall_mode_label=Label(); mon.waterfall_freq=Label(); mon.waterfall_override=Check()
mon.waterfall_active=False; mon.connected=True
mon.waterfall_gated=[Label() for _ in range(3)]; mon.waterfall_entry=[Label()]
sent=[]; mon.send_key_sequence=lambda codes, d: sent.append((codes,d))
print("== status + gating")
mon.update_waterfall_controls(); print("  scan mode:     gated enabled =", mon.waterfall_gated[0].en, "| entry enabled =", mon.waterfall_entry[0].en)
xml='<ScannerInfo Mode="waterfall" V_Screen="waterfall"><WaterfallBand Lower=" 150.000000MHz" Center=" 155.000000MHz" Upper=" 160.000000MHz" Mod="NFM" Step="Auto" Span="10MHz" Limit="Off"/><WaterfallSettings MF=" 154.4300MHz" Gain="Auto"/></ScannerInfo>'
mon.update_waterfall_status(ET.fromstring(xml))
print("  waterfall:     gated enabled =", mon.waterfall_gated[0].en, "|", mon.waterfall_mode_label.t)
print("  fields:", {k:v.t for k,v in mon.wf_fields.items()})
for f in sorted(glob.glob(sys.argv[2]+"/*search-hit*.txt"))[:1]:
    t=open(f).read(); mon.update_waterfall_status(ET.fromstring(t[t.index("<ScannerInfo"):t.index("</ScannerInfo>")+14]))
print("  real search sample: gated enabled =", mon.waterfall_gated[0].en, "|", mon.waterfall_mode_label.t)
mon.waterfall_override.v=True; mon.update_waterfall_controls(); print("  override ticked: gated enabled =", mon.waterfall_gated[0].en)
mon.connected=False; mon.update_waterfall_controls(); print("  disconnected:  gated =", mon.waterfall_gated[0].en, "entry =", mon.waterfall_entry[0].en)
print("== actions")
for name in M.WATERFALL_ACTIONS: mon.waterfall_action(name)
for codes,d in sent: print("  KEY " + " then ".join(codes), "|", d)
