# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob, tempfile, csv, time
from pathlib import Path
from datetime import datetime, timedelta
from collections import deque, defaultdict
import xml.etree.ElementTree as ET
class Meta(type):
    def __getattr__(cls, n): return Dummy()
class Dummy(metaclass=Meta):
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
A = sys.argv[2]
class Sig:
    def __init__(self): self.got=[]
    def emit(self,v): self.got.append(v)
print("== 1. serial: GLT XML blocks")
glt_fl = (b'GLT,<XML>,\r<?xml version="1.0" encoding="utf-8"?>\r<GLT>\r'
          b'<FL Index="0" Name="Favorites List 1" Monitor="On" Q_Key="1" N_Tag="None" />\r'
          b'<FL Index="1" Name="Greenville County" Monitor="On" Q_Key="2" N_Tag="2" />\r</GLT>\r')
stream = glt_fl + b"KEY,OK\r" + b'GLT,<XML>,\r<?xml version="1.0" encoding="utf-8"?>\r<GLT />\rGLT,NG\r'
t = object.__new__(m.ScannerThread); t.xml_received=Sig(); t.command_result=Sig(); t.graph_received=Sig(); t.list_received=Sig()
buf=b""
for i in range(0,len(stream),23): buf=t.consume(buf+stream[i:i+23])
print("  lists:", len(t.list_received.got), [x[:12] for x in t.list_received.got], "| replies:", t.command_result.got)

# ---- fakes for widgets -------------------------------------------------
class W:
    def __init__(s,*a,**k): s.t=a[0] if a and isinstance(a[0],str) else ""; s.en=None; s.style=""; s.tip=""; s.chk=False; s.items=[]; s.cur=0
    def setText(s,t): s.t=t
    def text(s): return s.t
    def setEnabled(s,v): s.en=v
    def isEnabled(s): return bool(s.en)
    def setStyleSheet(s,v): s.style=v
    def setToolTip(s,v): s.tip=v
    def setChecked(s,v): s.chk=v
    def isChecked(s): return s.chk
    def addItem(s,label,data=None): s.items.append((label,data))
    def clear(s): s.items=[]
    def currentData(s): return s.items[s.cur][1] if s.items else None
    def setCurrentIndex(s,i): s.cur=i
    def currentIndex(s): return s.cur
    def blockSignals(s,b): pass
    @property
    def currentIndexChanged(s): return types.SimpleNamespace(emit=lambda *a: None)
    def __getattr__(s,n): return lambda *a, **k: None
class Item:
    def __init__(s, cols=None): s.cols=list(cols or [""]); s.kids=[]; s.par=None; s.d=None
    def addChild(s,c): c.par=s; s.kids.append(c)
    def child(s,i): return s.kids[i]
    def childCount(s): return len(s.kids)
    def takeChild(s,i): return s.kids.pop(i)
    def takeChildren(s): k=s.kids; s.kids=[]; return k
    def data(s,c,r): return s.d
    def setData(s,c,r,v): s.d=dict(v) if v is not None else None
    def text(s,c): return s.cols[c]
    def parent(s): return s.par
    def setExpanded(s,v): pass
class Tree:
    def __init__(s): s.top=[]
    def addTopLevelItem(s,i): s.top.append(i)
    def clear(s): s.top=[]
m.QTreeWidgetItem = Item
class Settings(dict):
    def value(s,k,d=None): return s.get(k,d)
    def setValue(s,k,v): s[k]=v
sent=[]
mon = types.SimpleNamespace(connected=True, settings=Settings(), queue=lambda c: (sent.append(c), True)[1],
                            command_reply=lambda r: None, add_alert_rule=lambda *a: None)
tools = object.__new__(m.ScannerTools); tools.monitor=mon; tools.status=W(); tools.tree=Tree()
tools.glt_pending=deque(); tools.fl_by_qk={}

print("== 2. lists")
tools.load_favorites(); print("  sends:", sent[-1])
tools.handle_list(t.list_received.got[0]); fl=tools.tree.top
print("  favorites lists:", [(i.text(0), i.text(4)) for i in fl], "| qk names:", tools.fl_by_qk)
tools.expand_item(fl[1]); print("  expand FL 1 sends:", sent[-1])
tools.handle_list('<GLT><SYS Index="60" MyId="1" Name="Palmetto 800" Avoid="Off" Type="P25 Trunk" Q_Key="None" N_Tag="None"/>'
                  '<SYS Index="61" Name="Greenville Conv" Avoid="Off" Type="Conventional" Q_Key="3"/></GLT>')
systems = fl[1].kids; print("  systems:", [(i.text(0), i.text(2)) for i in systems])
n=len(sent); tools.expand_item(systems[0]); print("  expand trunk system sends:", sent[n:])
tools.handle_list('<GLT><DEPT Index="111" Name="Greenville County" Avoid="Off" Q_Key="None"/></GLT>')
tools.handle_list_error("NG")   # SITE request refused
print("  trunk system children:", [i.text(0) for i in systems[0].kids])
n=len(sent); tools.expand_item(systems[0].kids[0]); print("  expand dept (trunk) sends:", sent[n:])
tools.handle_list('<GLT><TGID Index="245" Name="Sheriff East Dispatch" Avoid="Off" TGID="44002" SvcType="Law Dispatch"/>'
                  '<Footer No="1" EOT="0"/></GLT>')
print("  long list: asked again:", sent[-1], "| pending:", len(tools.glt_pending))
tools.handle_list('<GLT><TGID Index="199" Name="Greer Firecomm" Avoid="T-Avoid" TGID="44385" SvcType="Fire Dispatch"/><Footer No="2" EOT="1"/></GLT>')
print("  talkgroups:", [(i.text(0), i.text(2), i.text(3)) for i in systems[0].kids[0].kids], "| pending:", len(tools.glt_pending))
n=len(sent); tools.expand_item(systems[1]); print("  expand conventional system sends:", sent[n:])
tools.handle_list('<GLT />'); print("  empty:", [i.text(0) for i in systems[1].kids])
print("  route GLT,NG handled quietly:", tools.route("REPLY: GLT,NG"))

print("== 3. quick keys")
tools.qk_status={"FQK":None,"SQK":None,"DQK":None}
tools.qk_buttons={c:[W() for _ in range(100)] for c in ("FQK","SQK","DQK")}
tools.sqk_fav=W(); tools.dqk_sys=W()
fqk = ["0"]*100; fqk[1]="2"; fqk[2]="1"
n=len(sent); tools.route("REPLY: FQK," + ",".join(fqk))
b = tools.qk_buttons["FQK"]
print("  key1 enabled-green:", "1b8a5a" in b[1].style, "| key2 grey:", "414750" in b[2].style, "| key5 disabled:", b[5].en,
      "| tooltip:", b[2].tip.replace("\n"," / "), "| combo:", tools.sqk_fav.items)
tools.toggle_quick_key("FQK", 2); print("  toggle key 2 sends: FQK,...  key2 ->", sent[-1].split(",")[3], "key1 ->", sent[-1].split(",")[2])
tools.route("REPLY: FQK,OK"); print("  after OK re-reads:", sent[-1])
tools.sqk_fav.items=[("2",2)]
sqk = ["0"]*100; sqk[7]="2"; tools.route("REPLY: SQK,2,0," + ",".join(sqk))
print("  SQK parsed with prefix: key7 green:", "1b8a5a" in tools.qk_buttons["SQK"][7].style, "| dqk combo:", tools.dqk_sys.items)
tools.toggle_quick_key("SQK", 7); print("  SQK set starts:", sent[-1][:12], "| values:", len(sent[-1].split(","))-2)

print("== 4. service types")
tools.svc_boxes={i:W() for i,n in enumerate(m.SERVICE_TYPES) if n!="non"}
tools.svc_boxes.update({len(m.SERVICE_TYPES)+i:W() for i in range(10)})
vals = ["1"]*47; vals[2]="0"; vals[4]="0"
tools.route("REPLY: SVC," + ",".join(vals)); print("  ", tools.status.t, "| Fire Dispatch ticked:", tools.svc_boxes[2].chk)
tools.svc_boxes[1].chk=False; tools.apply_services(); out=sent[-1].split(",")[1:]
print("  apply: len", len(out), "| Law off:", out[1]=="0", "| unused 'non' kept as scanner had it:", out[4]=="0")

print("== 5. location")
tools.loc_fields={k:W() for k in ("Latitude","Longitude","Range")}; tools.loc_result=W(); tools.lcr_format=None; tools.lcr_expect=None
tools.route("REPLY: LCR,34.852600,-82.394000,25.0"); print("  read:", tools.loc_result.t, "| format:", tools.lcr_format)
tools.loc_fields["Latitude"].t="35.1"; tools.apply_location(); print("  set sends:", sent[-1])
tools.route("REPLY: LCR,OK"); print("  then re-reads:", sent[-1])
tools.route("REPLY: LCR,35.100000,-82.394000,25.0"); print("  verify:", tools.loc_result.t[:16])
tools.route("REPLY: LCR,34N51.156,82W23.640,25"); print("  unknown format ->", tools.lcr_format, "|", tools.loc_result.t.splitlines()[-1][:60])

print("== 6. alerts")
vals = {"Channel":"Sheriff East Dispatch","Talkgroup":"TGID:44002","Frequency":"859.962500MHz","System":"Palmetto 800",
        "Department":"Greenville County","Site":"Greenville County Simulcast","Unit ID":"UID:1000001"}
for rule in ({"field":"Channel","match":"is","text":"sheriff east dispatch"},{"field":"Channel","match":"contains","text":"Sheriff"},
             {"field":"Talkgroup","match":"is","text":"TGID:44002"},{"field":"Unit ID","match":"contains","text":"1000001"},
             {"field":"Any field","match":"contains","text":"Simulcast"},{"field":"Channel","match":"is","text":"Sheriff"},
             {"field":"Channel","match":"contains","text":"Sheriff","enabled":False}):
    print(f"   {rule['field']:9} {rule['match']:8} {rule['text']!r:26} -> {m.alert_matches(rule, vals)}")
alerts=[]
mon2 = object.__new__(m.Monitor); mon2.settings=Settings({"alerts/cooldown":60}); mon2.alert_last={}
mon2.alert_rules=[{"field":"Channel","match":"contains","text":"Sheriff","enabled":True},{"field":"Unit ID","match":"is","text":"UID:1000001","enabled":True}]
mon2.notify=lambda t,d: alerts.append((t,d))
mon2.check_alerts(vals); mon2.check_alerts(vals); print("  cooldown: 2 checks ->", len(alerts), "alert:", alerts[0])
mon2.check_alerts(vals, unit_only=True); print("  unit-only check fires unit rule:", len(alerts) == 2)

print("== 7. process_xml with real trunk samples: alerts + unit log")
tmp = Path(tempfile.mkdtemp()); m.UNIT_LOG_DIR = tmp / "unit_ids"
class Label(W): pass
mon3 = object.__new__(m.Monitor)
mon3.fields={k:Label() for k in ("System","Site","Department","Channel","Frequency","Talkgroup","Unit ID","Mode","RSSI")}
mon3.status=Label(); mon3.signal=Label(); mon3.event=None; mon3.active_poll_ms=500; mon3.last_unit_key=None
for name in ("update_waterfall_status","sync_audio","sync_recording","check_qsh","finish_event"): setattr(mon3,name,lambda *a, **k: None)
mon3.statusBar=lambda: W()
fired=[]; mon3.check_alerts=lambda v, unit_only=False: fired.append((v["Channel"], unit_only))
samples=sorted(glob.glob(A+"/status_trunk-call_*.txt"))
for f in samples + samples[:1]:
    x=open(f).read(); x=x[x.index("<ScannerInfo"):x.index("</ScannerInfo>")+14]
    for _ in range(3): mon3.process_xml(x)       # several polls of the same call
    mon3.process_xml('<ScannerInfo Mode="Trunk Scan"><Property Mute="Mute" Rssi="-999"/></ScannerInfo>')
print("  alert checks:", fired)
rows=list(csv.reader(open(next(m.UNIT_LOG_DIR.glob("*.csv")))))
print("  unit log header ok:", rows[0]==m.UNIT_HEADERS, "| rows:", len(rows)-1)
for r in rows[1:]: print("    ", r[1:4], r[6][:24], r[7], r[8])

print("== 8. unit log viewer + charts aggregation")
v = object.__new__(m.UnitIdLog); v.period=W(); v.period.items=[("all",None)]; v.search=W(); v.info=W()
class T:
    def __init__(s): s.cells={}; s.rows=0
    def setRowCount(s,n): s.rows=n
    def setItem(s,r,c,i): s.cells[(r,c)]=i
    def item(s,r,c): return s.cells.get((r,c))
    def __getattr__(s,n): return lambda *a, **k: None
v.units=T(); v.entries=T()
class TI:
    def __init__(s,t=""): s.t=t
    def setData(s,r,val): s.t=str(val)
    def text(s): return s.t
m.QTableWidgetItem = TI
v.reload(); print("  ", v.info.t, "| top unit:", v.units.item(0,0).text(), "heard", v.units.item(0,2).text(), "on", v.units.item(0,5).text())
c = object.__new__(m.ActivityCharts)
got={}
class Chart:
    def __init__(s,n): s.n=n; s.title=""
    def set_data(s,l,vals,u=""): got[s.n]=(list(l),list(vals))
c.by_hour, c.by_day, c.top = Chart("hour"), Chart("day"), Chart("top")
c.period=W(); c.period.items=[("30",30)]; c.system=W(); c.system.t="All systems"; c.measure=W(); c.measure.items=[("count","count")]; c.summary=W()
c.system.currentText=lambda: "All systems"
now=datetime.now().replace(hour=14, minute=5)
c.records=[(now, 10, "Palmetto 800", "Sheriff East Dispatch"), (now, 5, "Palmetto 800", "Sheriff East Dispatch"),
           (now - timedelta(days=2, hours=5), 60, "Palmetto 800", "Greer Fire"), (now - timedelta(days=40), 9, "X", "Old")]
c.redraw(); print("  ", c.summary.t, "| hour 14 =", got["hour"][1][14], "| days:", len(got["day"][0]), "| top:", list(zip(*got["top"])))
c.measure.items=[("min","min")]; c.redraw(); print("  air time top:", [(a, round(b,2)) for a,b in zip(*got["top"])])
