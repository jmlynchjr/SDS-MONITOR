#!/usr/bin/env bash
# Runs every test against ../sds100_monitor.py, using the scanner samples in
# ./samples (radio unit IDs replaced with fictitious values). PyQt6 and pyserial are NOT needed: the tests replace
# Qt and serial with small stand-ins and exercise the program's logic only
# (serial parsing, reply handling, parsing of scanner data, history, charts).
# Drawing and window layout are not covered — check those on the real program.
# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
set -u
cd "$(dirname "$(readlink -f "$0")")"
SRC=../sds100_monitor.py
SAMPLES=samples
echo "Testing $SRC"
fail=0
run() {
  local name=$1; shift
  printf '\n===== %s =====\n' "$name"
  if ! python3 -I "$@"; then echo "!!!!! $name FAILED"; fail=1; fi
}
run "serial parser: replies and status XML"   test_consume.py "$SRC"
run "queued commands sent before disconnect"  test_drain.py "$SRC"
run "history loading and durations"           test_monitor.py "$SRC"
run "real status samples -> logged fields"    test_samples.py "$SRC" "$SAMPLES"
run "site and unit ID display"                test_fields.py "$SRC" "$SAMPLES"
run "waterfall controls and detection"        test_waterfall.py "$SRC" "$SAMPLES"
run "real waterfall status sample"            test_wf_real.py "$SRC" "$SAMPLES"
run "waterfall graph data (GWF)"              test_graph.py "$SRC" "$SAMPLES"
run "audio, battery, recording, clock, tune"  test_v119.py "$SRC" "$SAMPLES"
run "lists, quick keys, services, location, alerts, unit log, charts" test_v120.py "$SRC" "$SAMPLES"
run "real FQK quick-key reply"                test_fqk_real.py "$SRC" "$SAMPLES/reply_fqk_20261026_213921.txt"
echo
if ((fail)); then echo "SOME TESTS FAILED"; exit 1; fi
echo "All tests ran without errors. Compare the printed results with the expectations in tests/README.md."
