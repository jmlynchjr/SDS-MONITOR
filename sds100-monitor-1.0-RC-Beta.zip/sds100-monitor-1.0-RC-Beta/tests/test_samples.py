# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Test for SDS100 Monitor; run with tests/run_tests.sh.
import sys, types, importlib.util, glob, re
from collections import defaultdict
class Dummy:
    def __init__(self,*a,**k): pass
    def __getattr__(self,n): return Dummy()
    def __call__(self,*a,**k): return Dummy()
def stubmod(name):
    m = types.ModuleType(name); m.__getattr__ = lambda n: Dummy; return m
for n in ["PyQt6","PyQt6.QtCore","PyQt6.QtGui","PyQt6.QtWidgets","serial","serial.tools","serial.tools.list_ports"]:
    sys.modules[n] = stubmod(n)
spec = importlib.util.spec_from_file_location("m", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class Label:
    def __init__(s): s.t=""
    def setText(s,t): s.t=t
    def text(s): return s.t
    def __getattr__(s,n): return lambda *a: None
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness
mon = harness.monitor(m)
rows=[]; mon.finish_event=lambda: (rows.append(dict(mon.event["info"])) if mon.event else None, setattr(mon,"event",None))
idle='<ScannerInfo Mode="Trunk Scan"><Property Mute="Mute" Rssi="-999"/></ScannerInfo>'
for f in sorted(x for x in glob.glob(sys.argv[2]+"/status_*.txt") if "<ScannerInfo" in open(x).read()):
    text=open(f,encoding="utf-8").read()
    xml=text[text.index("<ScannerInfo"):text.index("</ScannerInfo>")+14]
    before=len(rows); mon.process_xml(xml); mon.process_xml(idle)
    name=re.sub(r"^[0-9a-f]+-","",f.split("/")[-1])
    print(f"{name:34} logged={len(rows)>before}", {k:v for k,v in (rows[-1].items() if len(rows)>before else mon.fields and {}.items())} if len(rows)>before else "(muted, not logged)")
