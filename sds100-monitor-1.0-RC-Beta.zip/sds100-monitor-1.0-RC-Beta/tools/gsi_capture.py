#!/usr/bin/env python3
# Copyright (C) 2026 J. Lynch. SPDX-License-Identifier: GPL-3.0-or-later
# Part of SDS100 Monitor; see LICENSE and ABOUT.md.
"""Capture SDS100 status (GSI), waterfall graph data (GWF) and other read-only
replies to files, for adding features to SDS100 Monitor. Read-only: only
commands that request information are sent; no settings are changed.

Usage:  python3 gsi_capture.py [port]      (default port /dev/ttyACM0)
"""
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import serial

PORT = sys.argv[1] if len(sys.argv) > 1 else "/dev/ttyACM0"
OUT_DIR = Path.home() / "gsi_samples"


def port_users(port):
    """Other programs that have the serial port open (Linux /proc scan)."""
    try:
        target = os.path.realpath(port)
    except OSError:
        return []
    users = []
    for pid in filter(str.isdigit, os.listdir("/proc")):
        if int(pid) == os.getpid():
            continue
        try:
            for fd in os.listdir(f"/proc/{pid}/fd"):
                if os.path.realpath(f"/proc/{pid}/fd/{fd}") == target:
                    cmd = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ")
                    users.append(f"process {pid}: {cmd.decode(errors='replace').strip()}")
                    break
        except OSError:
            continue    # process ended, or belongs to another user
    return users


def capture_status(device):
    device.reset_input_buffer()
    device.write(b"GSI\r")
    device.flush()
    data = b""
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline and b"</ScannerInfo>" not in data:
        data += device.read(4096)
    return data.decode("utf-8", "replace")


def capture_waterfall(device):
    device.reset_input_buffer()
    device.write(b"GWF,1,ON\r")
    device.flush()
    data = b""
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        data += device.read(65536)
    # Turn the request off again in case ON starts a continuous stream.
    device.write(b"GWF,1,OFF\r")
    device.flush()
    time.sleep(0.5)
    data += device.read(65536)
    return data.decode("utf-8", "replace")


# Read-only commands that may be sent with the "r" option (a get, never a set).
READ_ONLY = re.compile(r"^(GLT,(FL|AFREQ|FTO|CS_BANK|UREC|IREC_FILE|TRN_DISCOV|CNV_DISCOV)"
                       r"|GLT,(SYS|DEPT|SITE|CFREQ|TGID|SFREQ|ATGID|UREC_FILE),\d+"
                       r"|FQK|SQK,\d+|DQK,\d+,\d+|SVC|LCR|DTM|GCS|URC|VOL|SQL|MDL|VER|GST|STS)$")


def capture_command(device, command):
    device.reset_input_buffer()
    device.write(command.encode("ascii") + b"\r")
    device.flush()
    data, idle_since = b"", time.monotonic()
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline and time.monotonic() - idle_since < 1.5:
        chunk = device.read(65536)
        if chunk:
            data += chunk
            idle_since = time.monotonic()
    return data.decode("utf-8", "replace")


def save(kind, text):
    mode = "unknown"
    if 'Mode="' in text:
        mode = text.split('Mode="', 1)[1].split('"', 1)[0]
    safe = "".join(c if c.isalnum() else "-" for c in mode).strip("-").lower() or "unknown"
    path = OUT_DIR / f"{kind}_{safe}_{datetime.now():%Y%m%d_%H%M%S}.txt"
    path.write_text(text, encoding="utf-8")
    shown = text if len(text) < 3000 else text[:3000] + "\n[... shortened on screen; full reply saved ...]"
    print(shown)
    print(f"Saved: {path}")
    if text.count("<ScannerInfo") > 1:
        print("Warning: this reply contains more than one status report, which usually "
              "means another program is reading the scanner at the same time.")


def main():
    users = port_users(PORT)
    if users:
        print(f"{PORT} is already open in another program:")
        for user in users:
            print("  " + user)
        print("Close it (for example SDS100 Monitor) and run this script again. "
              "Two programs reading the scanner at once corrupt the samples.")
        return
    OUT_DIR.mkdir(exist_ok=True)
    try:
        device = serial.Serial(PORT, 115200, timeout=0.2, write_timeout=1, exclusive=True)
    except serial.SerialException as exc:
        print(f"Could not open {PORT}: {exc}")
        print("Check the scanner is connected and in Serial Port mode.")
        return
    print(f"Connected to {PORT}. Samples are saved in {OUT_DIR}")
    with device:
        while True:
            choice = input("\nPress Enter for a status sample, w for waterfall graph data, "
                           "r to send a read-only command (e.g. GLT,FL or FQK), or q to quit: "
                           ).strip().lower()
            if choice == "q":
                break
            if choice == "r":
                command = input("Command: ").strip().upper()
                if not READ_ONLY.match(command):
                    print("Only read-only commands are allowed here, for example: GLT,FL  "
                          "GLT,SYS,0  GLT,DEPT,60  GLT,TGID,111  FQK  SQK,2  DQK,2,7  SVC  LCR")
                    continue
                text = capture_command(device, command)
                if not text.strip():
                    print("No reply.")
                    continue
                save(command.split(",")[0].lower() + "-" + command.replace(",", "-").lower(), text)
                continue
            if choice == "w":
                text = capture_waterfall(device)
                if not text.strip():
                    print("No reply. Is the waterfall on screen?")
                    continue
                save("graph", text)
            else:
                text = capture_status(device)
                if "</ScannerInfo>" not in text:
                    print("No complete reply received. Is the scanner connected and on?")
                    continue
                save("status", text)


if __name__ == "__main__":
    main()
