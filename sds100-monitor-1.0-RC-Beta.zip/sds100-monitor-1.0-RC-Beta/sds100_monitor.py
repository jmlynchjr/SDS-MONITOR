#!/usr/bin/env python3
# SDS100 Monitor — live monitoring and control for the Uniden SDS100 scanner
# Copyright (C) 2026 J. Lynch
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with this program. If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: GPL-3.0-or-later
# Developed with the assistance of AI tools; see ABOUT.md.
"""SDS100 Monitor: live GSI monitoring, scanner controls, keypad, reception
history and statistics for the Uniden SDS100.

Uses the previously verified GSI XML format. PSI is deliberately not enabled
until its exact periodic-response behavior is validated on the scanner.
"""
import csv
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from collections import defaultdict, deque
from pathlib import Path

VERSION = "1.0-RC-Beta"   # public release candidate; internal build 1.1.21

import serial
import serial.tools.list_ports
from PyQt6.QtCore import QThread, pyqtSignal, QSettings, Qt, QRectF, QPointF, QTimer, QUrl
from PyQt6.QtGui import (QPainter, QColor, QPen, QBrush, QFont, QIcon, QDesktopServices,
                         QImage, QPolygonF)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QVBoxLayout,
    QHBoxLayout, QGridLayout, QTableWidget, QTableWidgetItem, QHeaderView,
    QComboBox, QProgressBar, QSpinBox, QMessageBox, QGroupBox, QScrollArea,
    QDockWidget, QSizePolicy, QSplitter, QAbstractItemView, QLineEdit, QDialog,
    QFileDialog, QMenu, QTextEdit, QTabBar, QCheckBox, QToolTip, QSlider,
    QTabWidget, QTreeWidget, QTreeWidgetItem, QListWidget, QListWidgetItem,
    QInputDialog, QSystemTrayIcon
)

DATA_DIR = Path.home() / "SDS100Monitor"
LEGACY_LOG_FILE = DATA_DIR / "reception_history_v6.csv"
DAILY_LOG_DIR = DATA_DIR / "history"
def daily_log_path(timestamp):
    return DAILY_LOG_DIR / f"reception_history_{timestamp:%Y-%m-%d}.csv"
HEADERS = ["Start", "End", "Duration (s)", "System", "Department",
           "Channel", "Frequency", "Talkgroup", "RSSI (dBm)"]

def copy_text(text):
    QApplication.clipboard().setText(str(text))


def export_csv_rows(parent, rows, suggested="reception_selection.csv"):
    if not rows:
        return
    path, _ = QFileDialog.getSaveFileName(parent, "Export reception CSV", str(Path.home() / suggested), "CSV files (*.csv)")
    if path:
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(HEADERS)
                writer.writerows(rows)
        except OSError as exc:
            QMessageBox.warning(parent, "CSV export failed", str(exc))


def show_reception_details(parent, row, search_callback=None):
    dialog = QDialog(parent)
    dialog.setWindowTitle("Reception Details")
    dialog.resize(570, 390)
    layout = QVBoxLayout(dialog)
    details = QTextEdit()
    details.setReadOnly(True)
    details.setPlainText("\n".join(f"{key}: {value}" for key, value in zip(HEADERS, row)))
    layout.addWidget(details)
    buttons = QHBoxLayout()
    copy_btn = QPushButton("Copy Details")
    copy_btn.clicked.connect(lambda: copy_text(details.toPlainText()))
    buttons.addWidget(copy_btn)
    if search_callback and row[5]:
        similar = QPushButton("Find Similar Receptions")
        similar.clicked.connect(lambda: (search_callback(row[5]), dialog.accept()))
        buttons.addWidget(similar)
    close = QPushButton("Close")
    close.clicked.connect(dialog.accept)
    buttons.addWidget(close)
    layout.addLayout(buttons)
    dialog.exec()


def selected_record(table, point):
    item = table.itemAt(point)
    if item is None:
        return None
    row = item.row()
    return [table.item(row, c).text() if table.item(row, c) else "" for c in range(table.columnCount())]


def add_copy_actions(menu, row):
    for title, idx in (("Copy Channel Name", 5), ("Copy System Name", 3),
                       ("Copy Department", 4), ("Copy Frequency", 6),
                       ("Copy Talkgroup", 7)):
        menu.addAction(title, lambda checked=False, v=row[idx]: copy_text(v))
    menu.addAction("Copy Entire Record", lambda: copy_text("\t".join(row)))


class HistoryArchiveBrowser(QDialog):
    """Read-only browser for complete daily CSV archives and legacy history."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Reception History Archive Browser")
        self.resize(1050, 660)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.current_rows = []
        self.filtered_rows = []
        self.page = 0
        self.page_size = 250
        layout = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Archive:"))
        self.files = QComboBox()
        self.files.setMinimumWidth(260)
        row.addWidget(self.files, 1)
        reload_btn = QPushButton("Refresh files")
        reload_btn.clicked.connect(self.refresh_files)
        row.addWidget(reload_btn)
        layout.addLayout(row)
        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("Search entire selected file:"))
        self.search = QLineEdit()
        self.search.setPlaceholderText("Channel, system, department, date, frequency, talkgroup…")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.apply_filter)
        search_row.addWidget(self.search, 1)
        layout.addLayout(search_row)
        self.info = QLabel("")
        layout.addWidget(self.info)
        self.table = QTableWidget(0, len(HEADERS))
        self.table.setHorizontalHeaderLabels(HEADERS)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 160)
        self.table.setColumnWidth(1, 160)
        self.table.setColumnWidth(5, 220)
        layout.addWidget(self.table, 1)
        pager = QHBoxLayout()
        self.prev_btn = QPushButton("◀ Previous")
        self.prev_btn.clicked.connect(lambda: self.show_page(self.page - 1))
        pager.addWidget(self.prev_btn)
        self.page_label = QLabel("")
        pager.addWidget(self.page_label)
        self.next_btn = QPushButton("Next ▶")
        self.next_btn.clicked.connect(lambda: self.show_page(self.page + 1))
        pager.addWidget(self.next_btn)
        pager.addStretch()
        export_btn = QPushButton("Export matching rows…")
        export_btn.clicked.connect(self.export_matches)
        pager.addWidget(export_btn)
        layout.addLayout(pager)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.archive_context_menu)
        self.table.cellDoubleClicked.connect(self.archive_details)
        self.files.currentIndexChanged.connect(self.load_selected)
        self.refresh_files()

    def archive_details(self, row_index, _column):
        row = [self.table.item(row_index, c).text() if self.table.item(row_index, c) else ""
               for c in range(len(HEADERS))]
        show_reception_details(self, row, self.search.setText)

    def archive_context_menu(self, point):
        row = selected_record(self.table, point)
        menu = QMenu(self)
        if row:
            clicked = self.table.itemAt(point)
            menu.addAction("Copy Selected Cell", lambda: copy_text(clicked.text()))
            add_copy_actions(menu, row)
            menu.addSeparator()
            menu.addAction("View Reception Details…", lambda: show_reception_details(self, row, self.search.setText))
            menu.addAction("Find All Receptions on This Channel", lambda: self.search.setText(row[5]))
            menu.addAction("Find All Receptions on This System", lambda: self.search.setText(row[3]))
            menu.addAction("Export Selected Record…", lambda: export_csv_rows(self, [row]))
        menu.addSeparator()
        menu.addAction("Clear Search", self.search.clear).setEnabled(bool(self.search.text()))
        menu.addAction("Export Matching Records…", self.export_matches).setEnabled(bool(self.filtered_rows))
        menu.addSeparator()
        path = self.files.currentData()
        menu.addAction("Open CSV File", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(path))).setEnabled(bool(path))
        menu.addAction("Open History Folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(DAILY_LOG_DIR))))
        menu.exec(self.table.viewport().mapToGlobal(point))

    def refresh_files(self):
        previous = self.files.currentData()
        self.files.blockSignals(True)
        self.files.clear()
        for path in sorted(DAILY_LOG_DIR.glob("reception_history_????-??-??.csv"), reverse=True):
            if path.is_file() and not path.is_symlink():
                self.files.addItem(path.stem.replace("reception_history_", ""), str(path))
        if LEGACY_LOG_FILE.is_file() and not LEGACY_LOG_FILE.is_symlink():
            self.files.addItem("Legacy reception history", str(LEGACY_LOG_FILE))
        if previous:
            idx = self.files.findData(previous)
            if idx >= 0:
                self.files.setCurrentIndex(idx)
        self.files.blockSignals(False)
        self.load_selected()

    def load_selected(self, _index=None):
        self.current_rows = []
        path = self.files.currentData()
        if path:
            try:
                with open(path, newline="", encoding="utf-8-sig") as f:
                    reader = csv.reader(f)
                    header = next(reader, None)
                    if header != HEADERS:
                        QMessageBox.warning(self, "Unrecognized CSV", "Unexpected columns in archive:\n" + str(path))
                    else:
                        self.current_rows = [row for row in reader if len(row) == len(HEADERS)]
            except (OSError, csv.Error, UnicodeDecodeError) as exc:
                QMessageBox.warning(self, "Cannot open archive", f"{path}\n\n{exc}")
        self.apply_filter()

    def apply_filter(self, _text=None):
        term = self.search.text().strip().casefold()
        self.filtered_rows = [r for r in self.current_rows
                              if not term or any(term in cell.casefold() for cell in r)]
        self.page = 0
        self.show_page(0)

    def show_page(self, number):
        total = len(self.filtered_rows)
        pages = max(1, (total + self.page_size - 1) // self.page_size)
        self.page = max(0, min(number, pages - 1))
        start = self.page * self.page_size
        rows = self.filtered_rows[start:start + self.page_size]
        self.table.setSortingEnabled(False)
        self.table.setUpdatesEnabled(False)
        try:
            self.table.setRowCount(len(rows))
            for r, values in enumerate(rows):
                for c, value in enumerate(values):
                    self.table.setItem(r, c, QTableWidgetItem(value))
        finally:
            self.table.setUpdatesEnabled(True)
        self.info.setText(f"{total:,} matching receptions / {len(self.current_rows):,} in selected archive")
        self.page_label.setText(f"Page {self.page + 1} of {pages} (250 rows per page)")
        self.prev_btn.setEnabled(self.page > 0)
        self.next_btn.setEnabled(self.page + 1 < pages)
        self.table.verticalScrollBar().setValue(0)

    def export_matches(self):
        if not self.filtered_rows:
            QMessageBox.information(self, "No matching rows", "Nothing to export.")
            return
        suggested = str(Path.home() / "reception_history_filtered.csv")
        path, _ = QFileDialog.getSaveFileName(self, "Export matching receptions", suggested, "CSV files (*.csv)")
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(HEADERS)
                writer.writerows(self.filtered_rows)
        except OSError as exc:
            QMessageBox.warning(self, "Export failed", str(exc))
            return
        QMessageBox.information(self, "Export complete", f"Exported {len(self.filtered_rows):,} rows.")



def port_users(port):
    """Other processes that have the serial port open (Linux /proc scan).

    Two programs reading the scanner at once split its replies between them
    and corrupt both, so the monitor refuses to connect in that case.
    """
    try:
        target = os.path.realpath(port)
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return []
    users = []
    for pid in pids:
        if int(pid) == os.getpid():
            continue
        try:
            for fd in os.listdir(f"/proc/{pid}/fd"):
                if os.path.realpath(f"/proc/{pid}/fd/{fd}") == target:
                    cmd = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ")
                    users.append(f"process {pid}: {cmd.decode(errors='replace').strip()[:120]}")
                    break
        except OSError:
            continue    # process ended, or belongs to another user
    return users


GRAPH_BINS = 240    # GWF FFT type 1: the 240 displayed FFT points


class ScannerThread(QThread):
    xml_received = pyqtSignal(str)
    message = pyqtSignal(str)
    command_result = pyqtSignal(str)
    graph_received = pyqtSignal(list)
    list_received = pyqtSignal(str)     # GLT XML block

    def __init__(self, port, baud, poll_ms):
        super().__init__()
        self.port, self.baud, self.poll_ms = port, baud, poll_ms
        self.running = True
        self.commands = queue.Queue()
        # Waterfall graph polling, switched on by the GUI while the scanner is
        # in waterfall mode. The scanner returns one GWF frame per request
        # (verified on an SDS100, 2026-10-26), so frames are polled.
        self.graph_enabled = False
        self.graph_ms = 250

    def run(self):
        users = port_users(self.port)
        if users:
            self.message.emit(
                f"ERROR: {self.port} is already open in another program:\n"
                + "\n".join(users)
                + "\n\nClose it and connect again. Two programs reading the "
                  "scanner at once corrupt each other's data.")
            self.message.emit("DISCONNECTED")
            return
        try:
            # exclusive=True takes a lock so a second program using pyserial
            # (another SDS100 Monitor, the capture script) cannot open it too.
            with serial.Serial(self.port, self.baud, timeout=0.1,
                               write_timeout=1, exclusive=True) as device:
                self.message.emit("CONNECTED")
                time.sleep(0.35)
                device.reset_input_buffer()
                for cmd in (b"MDL\r", b"VER\r"):
                    device.write(cmd)
                device.flush()
                buf = b""
                last_poll = -1e9
                last_graph = -1e9
                graph_on = False
                while self.running:
                    try:
                        cmd = self.commands.get_nowait()
                    except queue.Empty:
                        cmd = None
                    if cmd is not None:
                        device.write((cmd + "\r").encode("ascii"))
                        device.flush()
                        self.command_result.emit("SENT: " + cmd)
                    now = time.monotonic()
                    if (now - last_poll) * 1000 >= self.poll_ms:
                        device.write(b"GSI\r")
                        device.flush()
                        last_poll = now
                    if self.graph_enabled:
                        if (now - last_graph) * 1000 >= self.graph_ms:
                            device.write(b"GWF,1,ON\r")
                            device.flush()
                            last_graph = now
                            graph_on = True
                    elif graph_on:
                        device.write(b"GWF,1,OFF\r")
                        device.flush()
                        graph_on = False
                    data = device.read(4096)
                    if data:
                        buf += data
                    buf = self.consume(buf)
                # Send anything still queued (for example a key release)
                # before the port closes, instead of silently dropping it.
                while True:
                    try:
                        cmd = self.commands.get_nowait()
                    except queue.Empty:
                        break
                    device.write((cmd + "\r").encode("ascii"))
                    self.command_result.emit("SENT: " + cmd)
                device.flush()
        except (serial.SerialException, OSError) as exc:
            self.message.emit("ERROR: " + str(exc))
        finally:
            self.message.emit("DISCONNECTED")

    def consume(self, buf):
        """Split the serial buffer into plain-text replies and GSI XML blocks.

        Data is handled strictly in arrival order, so a reply such as KEY,OK
        that arrives in the same read as a GSI response is no longer discarded.
        Returns the unconsumed remainder of the buffer.
        """
        while True:
            # XML replies: GSI status (<ScannerInfo>) and GLT lists (<GLT>).
            starts = [(i, tag) for tag in (b"<ScannerInfo", b"<GLT")
                      if (i := buf.find(tag)) >= 0]
            xml_start, tag = min(starts) if starts else (-1, None)
            # Lines normally end in CR; GCS replies end in LF (spec V2.00).
            ends = [i for i in (buf.find(b"\r"), buf.find(b"\n")) if i >= 0]
            cr = min(ends) if ends else -1
            if xml_start >= 0 and (cr < 0 or xml_start < cr):
                prefix = buf[:xml_start]
                if tag == b"<GLT":
                    head = buf[xml_start:xml_start + 8].replace(b" ", b"")
                    if head.startswith(b"<GLT/>"):           # empty list
                        end = buf.find(b">", xml_start) + 1
                    else:
                        end = buf.find(b"</GLT>", xml_start)
                        end = end + len(b"</GLT>") if end >= 0 else -1
                    limit, signal = 2_000_000, self.list_received
                else:
                    end = buf.find(b"</ScannerInfo>", xml_start)
                    end = end + len(b"</ScannerInfo>") if end >= 0 else -1
                    limit, signal = 131072, self.xml_received
                if end < 0:
                    if len(buf) - xml_start > limit:
                        return b""
                    return buf
                self.emit_reply(prefix)
                signal.emit(buf[xml_start:end].decode("utf-8", "replace"))
                buf = buf[end:]
                continue
            if cr < 0:
                return buf[-1024:] if len(buf) > 8192 else buf
            line, buf = buf[:cr], buf[cr + 1:]
            self.emit_reply(line)

    @staticmethod
    def parse_graph(response):
        """Return the 240 levels (0-255) of a GWF frame, or None.

        Verified format: GWF,<240 two-digit hex values, comma separated>,
        """
        parts = response[4:].strip().strip(",").split(",")
        if len(parts) != GRAPH_BINS:
            return None
        try:
            return [int(p, 16) for p in parts]
        except ValueError:
            return None

    def emit_reply(self, raw):
        response = raw.decode("utf-8", "replace").strip()
        if response.startswith("GWF,"):
            values = self.parse_graph(response)
            if values is not None:
                self.graph_received.emit(values)
                return
        # GSI framing lines are part of the XML response, not command replies.
        if response and not response.startswith(("GSI,", "GLT,<XML>", "<?xml")):
            # Pass the whole reply on: FQK/SQK/DQK replies carry 100 values
            # (about 200 characters). Only the on-screen text is shortened.
            self.command_result.emit("REPLY: " + response)

    def send_command(self, command):
        self.commands.put(command)

    def stop(self):
        self.running = False
        self.wait(2500)


class KeyProtocolDiagnostic(QDialog):
    """Manual, one-command-at-a-time KEY_MODE investigation tool."""
    def __init__(self, monitor):
        super().__init__(monitor)
        self.monitor = monitor
        self.setWindowTitle("SDS100 Keypress Protocol Diagnostic • experimental")
        self.resize(720, 550)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        layout = QVBoxLayout(self)
        note = QLabel("Experimental remote key modes are NOT documented in SDS100 spec v1.02. "
                      "Test only while watching the scanner. P is established; L/H/R are hypotheses. "
                      "A KEY,OK reply confirms receipt, not that the expected function occurred.")
        note.setWordWrap(True)
        layout.addWidget(note)
        line = QHBoxLayout()
        line.addWidget(QLabel("Key:"))
        self.key = QComboBox()
        for name, code in [("1","1"),("2","2"),("3","3"),("4 / ATT","4"),("5 / DIM","5"),
                           ("6 / WX","6"),("7 / IFX","7"),("8 / REV","8"),("9 / DISP","9"),
                           ("0 / LVL","0"),("FUNC","F"),("AVOID","L"),("REPLAY","Y"),
                           ("SYSTEM","A"),("DEPT","B"),("CHANNEL","C"),("MENU","M"),
                           ("E/YES","E"),("./NO","."),("BACKLIGHT","V"),("RANGE","R")]:
            self.key.addItem(name,code)
        self.key.setCurrentIndex(self.key.findData("6"))
        line.addWidget(self.key)
        line.addWidget(QLabel("KEY_MODE:"))
        self.mode = QComboBox()
        for mode, name in [("P","P — normal press (known)"),("L","L — possible long press"),
                           ("H","H — possible hold"),("R","R — possible release")]:
            self.mode.addItem(name,mode)
        line.addWidget(self.mode)
        layout.addLayout(line)
        self.preview = QLabel()
        layout.addWidget(self.preview)
        self.key.currentIndexChanged.connect(self.update_preview)
        self.mode.currentIndexChanged.connect(self.update_preview)
        self.update_preview()
        self.ack = QCheckBox("I understand this is an undocumented command and will observe the scanner.")
        layout.addWidget(self.ack)
        self.send_btn = QPushButton("Send exactly this command")
        self.send_btn.clicked.connect(self.send_test)
        layout.addWidget(self.send_btn)
        self.release_btn = QPushButton("Release selected key (KEY,<key>,R) — experimental")
        self.release_btn.clicked.connect(self.release_key)
        layout.addWidget(self.release_btn)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log,1)
        self.log.append("Only commands sent from this diagnostic window are logged below. "
                        "Incoming serial replies are shared with normal scanner polling; "
                        "they are not guaranteed to correspond to the preceding command.")
        # Subscribe through the main window, so the log keeps working after
        # a disconnect/reconnect creates a new serial thread.
        self.monitor.scanner_output.connect(self.log_reply)
        close = QPushButton("Close")
        close.clicked.connect(self.close)
        layout.addWidget(close)

    # The held key is stored on the main window, which outlives this dialog
    # and can release the key when the program closes or disconnects.
    @property
    def held_key(self):
        return self.monitor.diagnostic_held_key

    @held_key.setter
    def held_key(self, value):
        self.monitor.diagnostic_held_key = value

    def update_preview(self):
        self.preview.setText(f"Exact command: KEY,{self.key.currentData()},{self.mode.currentData()}\r")

    def ready(self):
        if not self.monitor.thread or not self.monitor.thread.isRunning():
            QMessageBox.warning(self,"Disconnected","Connect the SDS100 before sending test commands.")
            return False
        if not self.ack.isChecked():
            QMessageBox.information(self,"Confirmation required","Check the experimental-command acknowledgement first.")
            return False
        return True

    def send_test(self):
        if not self.ready():
            return
        key,mode = self.key.currentData(),self.mode.currentData()
        if mode in ("H","L"):
            result = QMessageBox.question(self,"Confirm experimental key mode",
                f"Send KEY,{key},{mode}?\nThis may change scanner settings or leave a key held. "
                "The program cannot guarantee release if the connection drops.")
            if result != QMessageBox.StandardButton.Yes:
                return
        self.monitor.thread.send_command(f"KEY,{key},{mode}")
        self.log.append(f"QUEUED: KEY,{key},{mode}")
        if mode == "H":
            self.held_key = key
            self.release_btn.setText(f"Release held key {key} (KEY,{key},R) — experimental")
        elif mode == "R" and self.held_key == key:
            self.held_key = None

    def release_key(self):
        if not self.ready():
            return
        key = self.held_key or self.key.currentData()
        self.monitor.thread.send_command(f"KEY,{key},R")
        self.log.append(f"QUEUED RELEASE: KEY,{key},R")
        self.held_key = None

    def log_reply(self, message):
        self.log.append(message)

    def closeEvent(self, event):
        key = self.monitor.release_diagnostic_key()
        if key:
            self.log.append(f"QUEUED AUTOMATIC RELEASE: KEY,{key},R")
        super().closeEvent(event)


class ResponsiveInfo(QWidget):
    """Scale information text to the available dock width and height."""
    def resizeEvent(self, event):
        super().resizeEvent(event)
        scale = min(self.width() / 560, self.height() / 420)
        size = max(10, min(24, round(15 * scale)))
        for label in self.findChildren(QLabel):
            if label.objectName() == "value":
                font = label.font()
                font.setPointSize(size)
                label.setFont(font)


def parse_mhz(text):
    """' 162.550000MHz' -> 162.55; returns None if not a frequency."""
    try:
        return float(str(text).strip().lower().removesuffix("mhz").strip())
    except ValueError:
        return None


def parse_step_mhz(text):
    """'25kHz' -> 0.025, '6.25kHz' -> 0.00625; 'Auto' or unknown -> None."""
    t = str(text).strip().lower()
    try:
        if t.endswith("khz"):
            return float(t[:-3]) / 1000
        if t.endswith("mhz"):
            return float(t[:-3])
    except ValueError:
        pass
    return None


class WaterfallGraph(QWidget):
    """Live FFT trace (top) and scrolling waterfall (bottom) from GWF frames.

    Bin i of the 240 is drawn at Lower + i x (Upper - Lower) / 240, which puts
    the center frequency at bin 120, as seen in SDS100 captures.
    """
    tune_requested = pyqtSignal(float)
    HISTORY = 200        # waterfall rows kept
    AXIS = 20            # pixels for the frequency labels

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self.setToolTip("Double-click to move the scanner's marker to that frequency")
        self.lower = self.upper = self.marker = self.step = None
        self.current = None
        self.floor = None
        self.rows = bytearray(GRAPH_BINS * 4 * self.HISTORY)
        self.row_count = 0
        self.message = "Waterfall not active"
        # Colour scale: black → blue → cyan → yellow → red → white.
        stops = [(0, (0, 0, 0)), (60, (10, 30, 140)), (120, (0, 170, 220)),
                 (175, (240, 230, 40)), (225, (235, 50, 20)), (255, (255, 255, 255))]
        self.lut = []
        for v in range(256):
            for (a, ca), (b, cb) in zip(stops, stops[1:]):
                if a <= v <= b:
                    f = (v - a) / (b - a)
                    r, g, bl = (round(ca[k] + (cb[k] - ca[k]) * f) for k in range(3))
                    # QImage Format_RGB32 is stored as B, G, R, 0xFF bytes.
                    self.lut.append(bytes((bl, g, r, 255)))
                    break

    def clear(self, message="Waterfall not active"):
        self.rows = bytearray(len(self.rows))
        self.row_count = 0
        self.current = None
        self.floor = None
        self.message = message
        self.update()

    def set_band(self, lower, upper, marker, step):
        if lower is None or upper is None or upper <= lower:
            self.lower = self.upper = None
            self.clear("Waterfall not active")
            return
        if (lower, upper) != (self.lower, self.upper):
            # New span or center: the old history no longer lines up.
            self.lower, self.upper = lower, upper
            self.clear("Waiting for graph data…")
        self.marker, self.step = marker, step
        self.update()

    def add_frame(self, values):
        if self.lower is None or len(values) != GRAPH_BINS:
            return
        self.current = values
        # Auto contrast: track the noise floor (25th percentile) smoothly.
        p25 = sorted(values)[GRAPH_BINS // 4]
        self.floor = p25 if self.floor is None else self.floor * 0.9 + p25 * 0.1
        low, span = self.floor - 8, 140
        row = b"".join(self.lut[max(0, min(255, int((v - low) * 255 / span)))] for v in values)
        self.rows[len(row):] = self.rows[:-len(row)]     # scroll down one row
        self.rows[:len(row)] = row
        self.row_count = min(self.HISTORY, self.row_count + 1)
        self.update()

    def x_for(self, mhz, width):
        return (mhz - self.lower) / (self.upper - self.lower) * width

    def mhz_at(self, x):
        if self.lower is None:
            return None
        mhz = self.lower + max(0.0, min(1.0, x / max(1, self.width()))) * (self.upper - self.lower)
        if self.step:
            mhz = round(mhz / self.step) * self.step
            # Snapping can land just outside the span at the edges; step back in.
            if mhz < self.lower:
                mhz += self.step
            elif mhz > self.upper:
                mhz -= self.step
        return round(mhz, 4)

    def paintEvent(self, event):
        p = QPainter(self)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor("#0d1117"))
        plot_h = h - self.AXIS
        fft_h = int(plot_h * 0.4)
        if self.lower is None or self.current is None:
            p.setPen(QColor("#a5bdd2"))
            p.setFont(QFont("Sans", 12))
            p.drawText(QRectF(0, 0, w, plot_h), Qt.AlignmentFlag.AlignCenter, self.message)
        else:
            # FFT trace with level grid (0-255 scale).
            p.setPen(QPen(QColor("#2a3a4d"), 1))
            for level in (64, 128, 192):
                y = fft_h - level / 255 * fft_h
                p.drawLine(QPointF(0, y), QPointF(w, y))
            points = [QPointF(i * w / (GRAPH_BINS - 1), fft_h - v / 255 * fft_h)
                      for i, v in enumerate(self.current)]
            p.setPen(QPen(QColor("#79d6bd"), 1.5))
            p.drawPolyline(QPolygonF(points))
            # Waterfall image, newest row at the top.
            pixels = bytes(self.rows)    # QImage uses this buffer; keep it alive
            image = QImage(pixels, GRAPH_BINS, self.HISTORY,
                           GRAPH_BINS * 4, QImage.Format.Format_RGB32)
            p.drawImage(QRectF(0, fft_h, w, plot_h - fft_h), image)
            # Marker line.
            if self.marker is not None and self.lower <= self.marker <= self.upper:
                x = self.x_for(self.marker, w)
                p.setPen(QPen(QColor("#52dc95"), 2))
                p.drawLine(QPointF(x, 0), QPointF(x, plot_h))
                p.setFont(QFont("Sans", 9, QFont.Weight.Bold))
                label = f"{self.marker:.4f}"
                lx = min(max(x + 4, 0), w - 70)
                p.drawText(QRectF(lx, 2, 70, 16), Qt.AlignmentFlag.AlignLeft, label)
        # Frequency axis.
        p.setPen(QColor("#c8d7e8"))
        p.setFont(QFont("Sans", 9))
        if self.lower is not None:
            mid = (self.lower + self.upper) / 2
            p.drawText(QRectF(2, plot_h, 120, self.AXIS), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, f"{self.lower:.4f}")
            p.drawText(QRectF(w / 2 - 60, plot_h, 120, self.AXIS), Qt.AlignmentFlag.AlignCenter, f"{mid:.4f} MHz")
            p.drawText(QRectF(w - 122, plot_h, 120, self.AXIS), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, f"{self.upper:.4f}")

    def mouseMoveEvent(self, event):
        mhz = self.mhz_at(event.position().x())
        if mhz is not None:
            QToolTip.showText(event.globalPosition().toPoint(),
                              f"{mhz:.4f} MHz — double-click to tune", self)

    def mouseDoubleClickEvent(self, event):
        mhz = self.mhz_at(event.position().x())
        if mhz is not None:
            self.tune_requested.emit(mhz)


class WaterfallWindow(QWidget):
    """Top-level waterfall window. Reports when it is shown or hidden."""
    visibility_changed = pyqtSignal(bool)

    def __init__(self, parent):
        super().__init__(parent, Qt.WindowType.Window)

    def showEvent(self, event):
        super().showEvent(event)
        self.visibility_changed.emit(True)

    def hideEvent(self, event):
        super().hideEvent(event)
        self.visibility_changed.emit(False)


class RotaryDial(QWidget):
    """Clickable rotary dial: left/right sectors rotate, center presses."""
    activated = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.setMinimumSize(150, 126)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setToolTip("Click left to rotate backward, right to rotate forward, center to push")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        factor = min(self.width() / 260, self.height() / 218)
        painter.translate((self.width() - 260 * factor) / 2,
                          (self.height() - 218 * factor) / 2)
        painter.scale(factor, factor)
        painter.setPen(QPen(QColor("#7388a0"), 3))
        painter.setBrush(QBrush(QColor("#263849")))
        painter.drawEllipse(41, 15, 178, 178)
        painter.setPen(QPen(QColor("#8ec9e9"), 3))
        painter.setBrush(QBrush(QColor("#435c77")))
        painter.drawEllipse(82, 56, 96, 96)
        painter.setPen(QColor("#ffffff"))
        painter.setFont(QFont("Sans", 13, QFont.Weight.Bold))
        painter.drawText(QRectF(88, 82, 84, 44),
                         Qt.AlignmentFlag.AlignCenter, "PUSH")
        painter.setFont(QFont("Sans", 22, QFont.Weight.Bold))
        painter.drawText(QRectF(40, 77, 42, 45),
                         Qt.AlignmentFlag.AlignCenter, "‹")
        painter.drawText(QRectF(177, 77, 42, 45),
                         Qt.AlignmentFlag.AlignCenter, "›")
        painter.setFont(QFont("Sans", 10))
        painter.drawText(QRectF(0, 195, 260, 20),
                         Qt.AlignmentFlag.AlignCenter, "ROTATE  •  PRESS")

    def mousePressEvent(self, event):
        if not self.isEnabled():
            return
        factor = min(self.width() / 260, self.height() / 218)
        x = (event.position().x() - (self.width() - 260 * factor) / 2) / factor
        y = (event.position().y() - (self.height() - 218 * factor) / 2) / factor
        if 82 <= x <= 178 and 56 <= y <= 152:
            self.activated.emit("^")
        elif 35 <= x < 82 and 55 <= y <= 160:
            self.activated.emit("<")
        elif 178 < x <= 225 and 55 <= y <= 160:
            self.activated.emit(">")


SERVICE_TYPES = [
    # PST1-PST37 in order, from Remote Command Specification V2.00 ("non" = unused).
    "Multi-Dispatch", "Law Dispatch", "Fire Dispatch", "EMS Dispatch", "non",
    "Multi-Tac", "Law Tac", "Fire-Tac", "EMS-Tac", "non", "Interop", "Hospital",
    "Ham", "Public Works", "Aircraft", "Federal", "Business", "non", "non",
    "Railroad", "Other", "Multi-Talk", "Law Talk", "Fire-Talk", "EMS-Talk",
    "Transportation", "non", "non", "Emergency Ops", "Military", "Media",
    "Schools", "Security", "Utilities", "non", "non", "Corrections",
]
CUSTOM_SERVICE_TYPES = ["Custom 1", "Custom 2", "Custom 3", "Custom 4", "Custom 5",
                        "Custom 6", "Custom 7", "Custom 8", "Racing Officials", "Racing Teams"]

LIST_KINDS = {
    # GLT list type -> (display name, child lists to request when expanded)
    "FL": ("Favorites List", ("SYS",)),
    "SYS": ("System", ("DEPT", "SITE")),
    "DEPT": ("Department", ("CFREQ", "TGID")),
    "SITE": ("Site", ("SFREQ",)),
    "CFREQ": ("Channel", ()),
    "TGID": ("Talkgroup", ()),
    "SFREQ": ("Site frequency", ()),
}
HOLDABLE = ("SYS", "DEPT", "SITE", "CFREQ", "TGID")


class ScannerTools(QWidget):
    """View → Scanner Tools…: lists, quick keys, service types, location, alerts.

    Reads and changes the scanner's live configuration over the serial link
    (GLT, HLD, AVD, FQK/SQK/DQK, SVC, LCR from spec V2.00).
    """

    def __init__(self, monitor):
        super().__init__(monitor, Qt.WindowType.Window)
        self.monitor = monitor
        self.setWindowTitle(f"SDS100 Scanner Tools — SDS100 Monitor v{VERSION}")
        icon_file = Path(__file__).with_name("sds100-monitor.svg")
        if icon_file.exists():
            self.setWindowIcon(QIcon(str(icon_file)))
        self.resize(1000, 720)
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        self.status = QLabel("Connect to the scanner to use these tools.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.glt_pending = deque()      # (command, parent item) in request order
        self.fl_by_qk = {}              # favorites list quick key -> name
        self.build_lists_tab()
        self.build_quickkeys_tab()
        self.build_service_tab()
        self.build_location_tab()

    def send(self, command):
        if self.monitor.queue(command):
            return True
        self.status.setText("Not connected — nothing was sent.")
        return False

    # ---- Lists ---------------------------------------------------------------
    def build_lists_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        row = QHBoxLayout()
        load = QPushButton("LOAD FAVORITES LISTS")
        load.clicked.connect(self.load_favorites)
        row.addWidget(load)
        row.addWidget(QLabel("Expand an item to load what's inside it. Right-click to hold or avoid."))
        row.addStretch(1)
        layout.addLayout(row)
        self.tree = QTreeWidget()
        self.tree.setColumnCount(6)
        self.tree.setHeaderLabels(["Name", "Type", "Details", "Avoid", "Quick key", "Index"])
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.tree.setColumnWidth(0, 330)
        self.tree.setColumnWidth(1, 120)
        self.tree.setColumnWidth(2, 230)
        self.tree.itemExpanded.connect(self.expand_item)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self.tree_menu)
        layout.addWidget(self.tree, 1)
        self.tabs.addTab(tab, "Lists")

    def load_favorites(self):
        self.tree.clear()
        self.glt_pending.clear()
        self.request_list("GLT,FL", None)

    def request_list(self, command, parent):
        if self.send(command):
            self.glt_pending.append((command, parent))
            self.status.setText(f"Requested {command}…")

    def make_item(self, element, parent):
        kind = element.tag
        a = element.attrib
        name = a.get("Name") or a.get("Freq") or a.get("TGID") or "(unnamed)"
        details = {
            "FL": f"Monitor {a.get('Monitor', '—')}",
            "SYS": a.get("Type", ""),
            "CFREQ": " • ".join(x for x in (a.get("Freq", "").strip(), a.get("Mod", ""),
                                             a.get("SvcType", "")) if x),
            "TGID": " • ".join(x for x in (a.get("TGID", ""), a.get("SvcType", "")) if x),
            "SFREQ": a.get("Freq", "").strip(),
        }.get(kind, "")
        item = QTreeWidgetItem([name.strip(), LIST_KINDS.get(kind, (kind,))[0], details,
                                a.get("Avoid", ""), a.get("Q_Key", ""), a.get("Index", "")])
        item.setData(0, Qt.ItemDataRole.UserRole, {"kind": kind, "attrs": dict(a),
                                                    "loaded": False})
        if LIST_KINDS.get(kind, ("", ()))[1]:
            item.addChild(QTreeWidgetItem(["(expand to load)"]))
        if parent is None:
            self.tree.addTopLevelItem(item)
        else:
            parent.addChild(item)
        if kind == "FL" and a.get("Q_Key", "None").isdigit():
            self.fl_by_qk[int(a["Q_Key"])] = name.strip()
        return item

    def item_info(self, item):
        return item.data(0, Qt.ItemDataRole.UserRole) if item else None

    def expand_item(self, item):
        info = self.item_info(item)
        if not info or info["loaded"]:
            return
        info["loaded"] = True
        item.setData(0, Qt.ItemDataRole.UserRole, info)
        item.takeChildren()
        item.addChild(QTreeWidgetItem(["Loading…"]))
        index = info["attrs"].get("Index", "")
        children = LIST_KINDS[info["kind"]][1]
        if info["kind"] == "SYS":
            sys_type = info["attrs"].get("Type", "").lower()
            if "conv" in sys_type:
                children = ("DEPT",)             # conventional systems have no sites
        if info["kind"] == "DEPT":
            parent_info = self.item_info(item.parent())
            sys_type = (parent_info or {}).get("attrs", {}).get("Type", "").lower()
            if "conv" in sys_type:
                children = ("CFREQ",)
            elif sys_type:
                children = ("TGID",)
        for child in children:
            self.request_list(f"GLT,{child},{index}", item)

    def handle_list(self, xml):
        if not self.glt_pending:
            return
        command, parent = self.glt_pending.popleft()
        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            self.status.setText(f"{command}: the scanner's list could not be read.")
            return
        footer = root.find("Footer")
        if parent is not None:
            # Remove the "Loading…" placeholder on the first part received.
            for i in reversed(range(parent.childCount())):
                if parent.child(i).data(0, Qt.ItemDataRole.UserRole) is None:
                    parent.takeChild(i)
        count = 0
        for element in root:
            if element.tag == "Footer":
                continue
            self.make_item(element, parent)
            count += 1
        if footer is not None and footer.attrib.get("EOT", "1") == "0":
            # Long lists arrive in parts: ask again for the next part.
            self.send(command)
            self.glt_pending.appendleft((command, parent))
        self.status.setText(f"{command}: {count} item(s) received.")
        if parent is not None and parent.childCount() == 0 and not any(
                cmd for cmd, p in self.glt_pending if p is parent):
            parent.addChild(QTreeWidgetItem(["(empty)"]))

    def handle_list_error(self, body):
        if not self.glt_pending:
            return
        command, parent = self.glt_pending.popleft()
        self.status.setText(f"{command}: scanner replied {body}.")
        if parent is not None and not any(p is parent for _, p in self.glt_pending):
            for i in reversed(range(parent.childCount())):
                if parent.child(i).data(0, Qt.ItemDataRole.UserRole) is None:
                    parent.takeChild(i)
            if parent.childCount() == 0:
                parent.addChild(QTreeWidgetItem(["(nothing to show)"]))

    def tree_menu(self, point):
        item = self.tree.itemAt(point)
        info = self.item_info(item)
        if not info:
            return
        kind, attrs = info["kind"], info["attrs"]
        index = attrs.get("Index", "")
        name = item.text(0)
        menu = QMenu(self)
        connected = self.monitor.connected
        if kind in HOLDABLE and index.isdigit():
            menu.addAction(f"Hold on {LIST_KINDS[kind][0]}",
                           lambda: self.list_command(f"HLD,{kind},{index},", name)).setEnabled(connected)
            menu.addSeparator()
            menu.addAction("Temporary Avoid",
                           lambda: self.avoid(item, kind, index, 2)).setEnabled(connected)
            menu.addAction("Permanent Avoid…",
                           lambda: self.avoid(item, kind, index, 1)).setEnabled(connected)
            menu.addAction("Remove Avoid",
                           lambda: self.avoid(item, kind, index, 3)).setEnabled(connected)
        if kind in ("CFREQ", "TGID"):
            menu.addSeparator()
            menu.addAction("Alert When This Is Active",
                           lambda: self.monitor.add_alert_rule("Channel", "is", name))
        menu.addSeparator()
        menu.addAction("Copy Name", lambda: copy_text(name))
        if item.parent() is not None or kind == "FL":
            menu.addAction("Refresh", lambda: self.refresh_item(item))
        menu.exec(self.tree.viewport().mapToGlobal(point))

    def list_command(self, command, name):
        if self.send(command):
            self.monitor.command_reply(f"QUEUED: {command} ({name})")
            self.status.setText(f"Sent {command} for {name}.")

    def avoid(self, item, kind, index, status):
        name = item.text(0)
        if status == 1:
            reply = QMessageBox.question(
                self, "Permanent avoid",
                f"Permanently avoid {name}?\n\nIt stays avoided until you remove the avoid, "
                "including after the scanner is turned off.")
            if reply != QMessageBox.StandardButton.Yes:
                return
        self.list_command(f"AVD,{kind},{index},,{status}", name)
        parent = item.parent()
        QTimer.singleShot(900, lambda: self.refresh_item(parent) if parent else self.load_favorites())

    def refresh_item(self, item):
        if item is None:
            return
        info = self.item_info(item)
        if info is None:
            return
        info["loaded"] = False
        item.setData(0, Qt.ItemDataRole.UserRole, info)
        item.setExpanded(True)
        self.expand_item(item)

    # ---- Quick keys ------------------------------------------------------------
    def build_quickkeys_tab(self):
        tab = QWidget()
        outer = QVBoxLayout(tab)
        note = QLabel("Green = enabled, grey = disabled, blank = no quick key assigned. "
                      "Click a key to turn it on or off on the scanner.")
        note.setWordWrap(True)
        outer.addWidget(note)
        row = QHBoxLayout()
        read = QPushButton("READ QUICK KEYS")
        read.clicked.connect(lambda: self.send("FQK"))
        row.addWidget(read)
        row.addStretch(1)
        outer.addLayout(row)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        layout = QVBoxLayout(content)
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)
        self.qk_status = {"FQK": None, "SQK": None, "DQK": None}
        self.qk_buttons = {}
        for code, title in (("FQK", "FAVORITES LIST QUICK KEYS"),
                            ("SQK", "SYSTEM QUICK KEYS"), ("DQK", "DEPARTMENT QUICK KEYS")):
            box = QGroupBox(title)
            box_layout = QVBoxLayout(box)
            if code == "SQK":
                pick = QHBoxLayout()
                pick.addWidget(QLabel("In favorites list quick key:"))
                self.sqk_fav = QComboBox()
                self.sqk_fav.currentIndexChanged.connect(self.request_sqk)
                pick.addWidget(self.sqk_fav)
                pick.addStretch(1)
                box_layout.addLayout(pick)
            if code == "DQK":
                pick = QHBoxLayout()
                pick.addWidget(QLabel("In system quick key:"))
                self.dqk_sys = QComboBox()
                self.dqk_sys.currentIndexChanged.connect(self.request_dqk)
                pick.addWidget(self.dqk_sys)
                pick.addStretch(1)
                box_layout.addLayout(pick)
            grid = QGridLayout()
            grid.setSpacing(3)
            buttons = []
            for n in range(100):
                b = QPushButton(str(n))
                b.setFixedSize(44, 30)
                b.setEnabled(False)
                b.clicked.connect(lambda checked=False, c=code, k=n: self.toggle_quick_key(c, k))
                grid.addWidget(b, n // 10, n % 10)
                buttons.append(b)
            box_layout.addLayout(grid)
            self.qk_buttons[code] = buttons
            layout.addWidget(box)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Quick Keys")

    QK_STYLES = {
        0: "QPushButton {background:#1c2530; color:#4b5563; border:1px solid #2a3442;}",
        1: "QPushButton {background:#414750; color:#d7dde5; border:1px solid #6b7684; font-weight:700;}",
        2: "QPushButton {background:#1b8a5a; color:white; border:1px solid #5fd49d; font-weight:700;}",
    }

    def handle_quick_keys(self, code, body):
        values = [v.strip() for v in body.split(",")]
        if body.strip() == "OK":
            # A change was accepted: read back the current state.
            self.request_qk(code)
            return
        if len(values) < 100 or not all(v.isdigit() for v in values[-100:]):
            self.status.setText(f"{code}: unexpected reply {body[:60]}")
            return
        statuses = [int(v) for v in values[-100:]]
        self.qk_status[code] = statuses
        for n, (b, st) in enumerate(zip(self.qk_buttons[code], statuses)):
            b.setStyleSheet(self.QK_STYLES.get(st, self.QK_STYLES[0]))
            b.setEnabled(st in (1, 2) and self.monitor.connected)
            label = self.fl_by_qk.get(n) if code == "FQK" else None
            b.setToolTip((f"{n}: {label}\n" if label else f"Quick key {n}\n")
                         + {0: "not assigned", 1: "disabled", 2: "enabled"}.get(st, "?"))
        existing = [n for n, st in enumerate(statuses) if st in (1, 2)]
        if code == "FQK":
            self.fill_combo(self.sqk_fav, existing, self.fl_by_qk)
        elif code == "SQK":
            self.fill_combo(self.dqk_sys, existing, {})
        self.status.setText(f"{code}: {len(existing)} quick key(s) in use.")

    @staticmethod
    def fill_combo(combo, keys, names):
        current = combo.currentData()
        combo.blockSignals(True)
        combo.clear()
        for k in keys:
            combo.addItem(f"{k} — {names[k]}" if k in names else str(k), k)
        if current in keys:
            combo.setCurrentIndex(keys.index(current))
        combo.blockSignals(False)
        combo.currentIndexChanged.emit(combo.currentIndex())

    def request_qk(self, code):
        if code == "FQK":
            self.send("FQK")
        elif code == "SQK":
            self.request_sqk()
        else:
            self.request_dqk()

    def request_sqk(self, *_):
        fav = self.sqk_fav.currentData()
        if fav is not None:
            self.send(f"SQK,{fav}")

    def request_dqk(self, *_):
        fav, sys_qk = self.sqk_fav.currentData(), self.dqk_sys.currentData()
        if fav is not None and sys_qk is not None:
            self.send(f"DQK,{fav},{sys_qk}")

    def toggle_quick_key(self, code, key):
        statuses = self.qk_status.get(code)
        if not statuses or statuses[key] not in (1, 2):
            return
        new = list(statuses)
        new[key] = 1 if statuses[key] == 2 else 2
        values = ",".join(str(v) for v in new)
        if code == "FQK":
            command = f"FQK,{values}"
        elif code == "SQK":
            command = f"SQK,{self.sqk_fav.currentData()},{values}"
        else:
            command = f"DQK,{self.sqk_fav.currentData()},{self.dqk_sys.currentData()},{values}"
        if self.send(command):
            state = "on" if new[key] == 2 else "off"
            self.status.setText(f"Turning quick key {key} {state}…")

    # ---- Service types ---------------------------------------------------------
    def build_service_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        note = QLabel("Ticked service types are scanned. Read them from the scanner, change them, "
                      "then press APPLY.")
        note.setWordWrap(True)
        layout.addWidget(note)
        row = QHBoxLayout()
        for label, slot in (("READ FROM SCANNER", lambda: self.send("SVC")),
                            ("ALL ON", lambda: self.set_all_services(True)),
                            ("ALL OFF", lambda: self.set_all_services(False)),
                            ("APPLY TO SCANNER", self.apply_services)):
            b = QPushButton(label)
            b.clicked.connect(slot)
            row.addWidget(b)
        row.addStretch(1)
        layout.addLayout(row)
        self.svc_values = None
        self.svc_boxes = {}
        grid_box = QGroupBox("PRESET SERVICE TYPES")
        grid = QGridLayout(grid_box)
        shown = [(i, n) for i, n in enumerate(SERVICE_TYPES) if n != "non"]
        for pos, (i, name) in enumerate(shown):
            box = QCheckBox(name)
            box.setEnabled(False)
            grid.addWidget(box, pos // 4, pos % 4)
            self.svc_boxes[i] = box
        layout.addWidget(grid_box)
        custom_box = QGroupBox("CUSTOM SERVICE TYPES")
        custom = QGridLayout(custom_box)
        for pos, name in enumerate(CUSTOM_SERVICE_TYPES):
            box = QCheckBox(name)
            box.setEnabled(False)
            custom.addWidget(box, pos // 5, pos % 5)
            self.svc_boxes[len(SERVICE_TYPES) + pos] = box
        layout.addWidget(custom_box)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Service Types")

    def handle_services(self, body):
        if body.strip() == "OK":
            self.status.setText("Service types applied.")
            self.send("SVC")
            return
        values = [v.strip() for v in body.split(",")]
        total = len(SERVICE_TYPES) + len(CUSTOM_SERVICE_TYPES)
        if len(values) < total or not all(v.isdigit() for v in values[:total]):
            self.status.setText(f"SVC: unexpected reply {body[:60]}")
            return
        self.svc_values = values[:total]
        for i, box in self.svc_boxes.items():
            box.setChecked(self.svc_values[i] == "1")
            box.setEnabled(True)
        on = sum(1 for i in self.svc_boxes if self.svc_values[i] == "1")
        self.status.setText(f"Service types read: {on} of {len(self.svc_boxes)} on.")

    def set_all_services(self, on):
        for box in self.svc_boxes.values():
            if box.isEnabled():
                box.setChecked(on)

    def apply_services(self):
        if self.svc_values is None:
            QMessageBox.information(self, "Service types", "Read the service types from the scanner first.")
            return
        values = list(self.svc_values)          # unused ("non") entries keep their value
        for i, box in self.svc_boxes.items():
            values[i] = "1" if box.isChecked() else "0"
        self.send("SVC," + ",".join(values))

    # ---- Location --------------------------------------------------------------
    def build_location_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        note = QLabel("The scanner uses its location and range for location-based scanning. "
                      "READ first: changes are sent in the same number format the scanner uses.")
        note.setWordWrap(True)
        layout.addWidget(note)
        current = QGroupBox("SCANNER LOCATION")
        grid = QGridLayout(current)
        self.loc_fields = {}
        for row, name in enumerate(("Latitude", "Longitude", "Range")):
            grid.addWidget(QLabel(name.upper()), row, 0)
            field = QLineEdit()
            grid.addWidget(field, row, 1)
            self.loc_fields[name] = field
        read = QPushButton("READ FROM SCANNER")
        read.clicked.connect(lambda: self.send("LCR"))
        apply = QPushButton("SET ON SCANNER")
        apply.clicked.connect(self.apply_location)
        grid.addWidget(read, 3, 0)
        grid.addWidget(apply, 3, 1)
        self.loc_result = QLabel("Location: not read yet")
        self.loc_result.setWordWrap(True)
        grid.addWidget(self.loc_result, 4, 0, 1, 2)
        layout.addWidget(current)
        places = QGroupBox("SAVED PLACES")
        places_layout = QVBoxLayout(places)
        self.places = QListWidget()
        self.places.itemDoubleClicked.connect(lambda _item: self.use_place())
        places_layout.addWidget(self.places, 1)
        prow = QHBoxLayout()
        for label, slot in (("SAVE CURRENT AS…", self.save_place), ("USE SELECTED", self.use_place),
                            ("DELETE", self.delete_place)):
            b = QPushButton(label)
            b.clicked.connect(slot)
            prow.addWidget(b)
        places_layout.addLayout(prow)
        layout.addWidget(places, 1)
        self.lcr_format = None
        self.lcr_expect = None
        self.load_places()
        self.tabs.addTab(tab, "Location")

    @staticmethod
    def number_format(text):
        """Decimal places of a plain number like '34.852600' or '-82.39', else None."""
        t = text.strip()
        body = t[1:] if t[:1] in "+-" else t
        if not body or body.count(".") > 1 or not body.replace(".", "").isdigit():
            return None
        return len(body.split(".")[1]) if "." in body else 0

    def handle_location(self, body):
        if body.strip() == "OK":
            self.send("LCR")
            return
        parts = [p.strip() for p in body.split(",")]
        if len(parts) < 3:
            self.loc_result.setText(f"Location: unexpected reply LCR,{body}")
            return
        lat, lon, rng = parts[:3]
        formats = [self.number_format(v) for v in (lat, lon, rng)]
        self.lcr_format = formats if all(f is not None for f in formats) else None
        for name, value in zip(("Latitude", "Longitude", "Range"), (lat, lon, rng)):
            self.loc_fields[name].setText(value)
        text = f"Scanner location: {lat}, {lon} • range {rng}"
        if self.lcr_expect is not None:
            if [lat, lon, rng] == self.lcr_expect:
                text = "✓ Location set. " + text
            else:
                text = "⚠ The scanner reports different values from those sent. " + text
            self.lcr_expect = None
        if self.lcr_format is None:
            text += ("\n⚠ This number format isn't recognised, so SET ON SCANNER is disabled. "
                     "Please send me this reply.")
        self.loc_result.setText(text)

    def apply_location(self):
        if self.lcr_format is None:
            QMessageBox.information(self, "Location",
                                    "Read the location from the scanner first, so changes can be "
                                    "sent in the same format.")
            return
        try:
            lat = float(self.loc_fields["Latitude"].text())
            lon = float(self.loc_fields["Longitude"].text())
            rng = float(self.loc_fields["Range"].text())
        except ValueError:
            QMessageBox.warning(self, "Location", "Latitude, longitude and range must be numbers.")
            return
        if not (-90 <= lat <= 90 and -180 <= lon <= 180 and rng >= 0):
            QMessageBox.warning(self, "Location",
                                "Latitude must be −90 to 90, longitude −180 to 180, range 0 or more.")
            return
        values = [f"{v:.{d}f}" for v, d in zip((lat, lon, rng), self.lcr_format)]
        self.lcr_expect = values
        if self.send("LCR," + ",".join(values)):
            self.loc_result.setText("Setting location…")

    def load_places(self):
        self.places.clear()
        try:
            saved = json.loads(str(self.monitor.settings.value("tools/places", "[]")))
        except ValueError:
            saved = []
        for place in saved:
            item = QListWidgetItem(f"{place['name']} — {place['lat']}, {place['lon']} • range {place['range']}")
            item.setData(Qt.ItemDataRole.UserRole, place)
            self.places.addItem(item)

    def store_places(self):
        places = [self.places.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.places.count())]
        self.monitor.settings.setValue("tools/places", json.dumps(places))

    def save_place(self):
        values = {k: self.loc_fields[k].text().strip() for k in ("Latitude", "Longitude", "Range")}
        if not all(values.values()):
            QMessageBox.information(self, "Save place", "Read or type a location first.")
            return
        name, ok = QInputDialog.getText(self, "Save place", "Name for this place:")
        if not ok or not name.strip():
            return
        place = {"name": name.strip(), "lat": values["Latitude"], "lon": values["Longitude"],
                 "range": values["Range"]}
        item = QListWidgetItem(f"{place['name']} — {place['lat']}, {place['lon']} • range {place['range']}")
        item.setData(Qt.ItemDataRole.UserRole, place)
        self.places.addItem(item)
        self.store_places()

    def use_place(self):
        item = self.places.currentItem()
        if item is None:
            return
        place = item.data(Qt.ItemDataRole.UserRole)
        self.loc_fields["Latitude"].setText(place["lat"])
        self.loc_fields["Longitude"].setText(place["lon"])
        self.loc_fields["Range"].setText(place["range"])
        self.apply_location()

    def delete_place(self):
        row = self.places.currentRow()
        if row >= 0:
            self.places.takeItem(row)
            self.store_places()

    # ---- Reply routing -----------------------------------------------------------
    def route(self, reply):
        """Called by the main window for every reply. Returns True if handled."""
        for code, handler in (("FQK", None), ("SQK", None), ("DQK", None)):
            if reply.startswith(f"REPLY: {code},"):
                self.handle_quick_keys(code, reply[len(f"REPLY: {code},"):])
                return True
        if reply.startswith("REPLY: SVC,"):
            self.handle_services(reply[len("REPLY: SVC,"):])
            return True
        if reply.startswith("REPLY: LCR,"):
            self.handle_location(reply[len("REPLY: LCR,"):])
            return True
        if reply.startswith("REPLY: GLT,") and not reply.startswith("REPLY: GLT,<XML>"):
            self.handle_list_error(reply[len("REPLY: GLT,"):])
            return True
        if reply.startswith("SENT: GLT") or reply[6:9] in ("FQK", "SQK", "DQK", "SVC", "LCR"):
            return True          # keep the main status line quiet
        return False


ALERT_FIELDS = ["Channel", "Talkgroup", "Frequency", "System", "Department", "Site",
                "Unit ID", "Any field"]
ALERT_MATCHES = {"contains": "contains", "is": "is exactly"}


def alert_matches(rule, values):
    """True if a rule matches the current reception's displayed values."""
    text = str(rule.get("text", "")).strip().casefold()
    if not text or not rule.get("enabled", True):
        return False
    field = rule.get("field", "Channel")
    candidates = values.values() if field == "Any field" else [values.get(field, "")]
    for value in candidates:
        value = str(value).strip().casefold()
        if value in ("", "—"):
            continue
        if rule.get("match") == "is" and value == text:
            return True
        if rule.get("match") != "is" and text in value:
            return True
    return False


class AlertsPanel(QWidget):
    """Scanner Tools → Alerts: watch rules and recent alerts."""

    def __init__(self, monitor):
        super().__init__()
        self.monitor = monitor
        layout = QVBoxLayout(self)
        note = QLabel("Get a desktop notification when a reception matches a rule. Tip: right-click a "
                      "reception in history → Alert When This Channel Is Active.")
        note.setWordWrap(True)
        layout.addWidget(note)
        add = QHBoxLayout()
        self.field = QComboBox()
        self.field.addItems(ALERT_FIELDS)
        self.match = QComboBox()
        for key, label in ALERT_MATCHES.items():
            self.match.addItem(label, key)
        self.text = QLineEdit()
        self.text.setPlaceholderText("e.g. Sheriff East Dispatch, TGID:44002, 162.5500, UID:1000001")
        self.text.returnPressed.connect(self.add_rule)
        add_btn = QPushButton("ADD RULE")
        add_btn.clicked.connect(self.add_rule)
        for w in (self.field, self.match):
            add.addWidget(w)
        add.addWidget(self.text, 1)
        add.addWidget(add_btn)
        layout.addLayout(add)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["On", "Field", "Match", "Text"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.itemChanged.connect(self.rule_toggled)
        layout.addWidget(self.table, 1)
        row = QHBoxLayout()
        remove = QPushButton("REMOVE SELECTED")
        remove.clicked.connect(self.remove_rules)
        row.addWidget(remove)
        self.notify_box = QCheckBox("Desktop notification")
        self.sound_box = QCheckBox("Sound")
        row.addWidget(self.notify_box)
        row.addWidget(self.sound_box)
        row.addWidget(QLabel("Repeat no more than every"))
        self.cooldown = QSpinBox()
        self.cooldown.setRange(0, 3600)
        self.cooldown.setSuffix(" s")
        row.addWidget(self.cooldown)
        test = QPushButton("TEST")
        test.clicked.connect(lambda: self.monitor.notify("SDS100 alert test",
                                                         "Alerts are working."))
        row.addWidget(test)
        row.addStretch(1)
        layout.addLayout(row)
        s = monitor.settings
        self.notify_box.setChecked(str(s.value("alerts/notify", "true")).lower() == "true")
        self.sound_box.setChecked(str(s.value("alerts/sound", "true")).lower() == "true")
        self.cooldown.setValue(int(s.value("alerts/cooldown", 60)))
        self.notify_box.toggled.connect(lambda v: s.setValue("alerts/notify", v))
        self.sound_box.toggled.connect(lambda v: s.setValue("alerts/sound", v))
        self.cooldown.valueChanged.connect(lambda v: s.setValue("alerts/cooldown", v))
        layout.addWidget(QLabel("RECENT ALERTS"))
        self.recent = QListWidget()
        self.recent.setMaximumHeight(170)
        layout.addWidget(self.recent)
        self.refresh()

    def add_rule(self):
        text = self.text.text().strip()
        if text:
            self.monitor.add_alert_rule(self.field.currentText(), self.match.currentData(), text)
            self.text.clear()

    def refresh(self):
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.monitor.alert_rules))
        for r, rule in enumerate(self.monitor.alert_rules):
            on = QTableWidgetItem()
            on.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled
                        | Qt.ItemFlag.ItemIsSelectable)
            on.setCheckState(Qt.CheckState.Checked if rule.get("enabled", True)
                             else Qt.CheckState.Unchecked)
            self.table.setItem(r, 0, on)
            self.table.setItem(r, 1, QTableWidgetItem(rule["field"]))
            self.table.setItem(r, 2, QTableWidgetItem(ALERT_MATCHES.get(rule["match"], rule["match"])))
            self.table.setItem(r, 3, QTableWidgetItem(rule["text"]))
        self.table.resizeColumnsToContents()
        self.table.blockSignals(False)

    def rule_toggled(self, item):
        if item.column() == 0 and item.row() < len(self.monitor.alert_rules):
            self.monitor.alert_rules[item.row()]["enabled"] = item.checkState() == Qt.CheckState.Checked
            self.monitor.save_alert_rules()

    def remove_rules(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        for r in rows:
            del self.monitor.alert_rules[r]
        self.monitor.save_alert_rules()
        self.refresh()

    def log(self, text):
        self.recent.insertItem(0, text)
        while self.recent.count() > 50:
            self.recent.takeItem(self.recent.count() - 1)


def load_reception_rows():
    """All saved receptions (daily CSVs plus legacy file) as lists of fields."""
    paths = sorted(DAILY_LOG_DIR.glob("reception_history_????-??-??.csv"))
    if LEGACY_LOG_FILE.exists():
        paths.insert(0, LEGACY_LOG_FILE)
    rows = []
    for path in paths:
        try:
            with path.open(newline="", encoding="utf-8-sig") as f:
                reader = csv.reader(f)
                if next(reader, None) != HEADERS:
                    continue
                rows.extend(r for r in reader if len(r) == len(HEADERS))
        except (OSError, csv.Error, UnicodeDecodeError):
            continue
    return rows


class BarChart(QWidget):
    """Simple vertical or horizontal bar chart drawn with QPainter."""

    def __init__(self, title, horizontal=False):
        super().__init__()
        self.title, self.horizontal = title, horizontal
        self.labels, self.values, self.unit = [], [], ""
        self.setMinimumHeight(230)
        self.setMouseTracking(True)
        self.bars = []

    def set_data(self, labels, values, unit=""):
        self.labels, self.values, self.unit = list(labels), list(values), unit
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor("#1c2530"))
        p.setPen(QColor("#e9eef5"))
        p.setFont(QFont("Sans", 11, QFont.Weight.Bold))
        p.drawText(QRectF(10, 4, w - 20, 22), Qt.AlignmentFlag.AlignLeft, self.title)
        self.bars = []
        if not self.values or max(self.values) <= 0:
            p.setFont(QFont("Sans", 10))
            p.setPen(QColor("#a5bdd2"))
            p.drawText(QRectF(0, 0, w, h), Qt.AlignmentFlag.AlignCenter, "No receptions in this period")
            return
        top = max(self.values)
        p.setFont(QFont("Sans", 8))
        bar_color = QColor("#3d8fd6")
        if self.horizontal:
            label_w = min(260, int(w * 0.42))
            area_top, row_h = 32, (h - 40) / len(self.values)
            for i, (label, value) in enumerate(zip(self.labels, self.values)):
                y = area_top + i * row_h
                length = (w - label_w - 70) * value / top
                rect = QRectF(label_w, y + 2, max(1, length), row_h - 4)
                p.fillRect(rect, bar_color)
                p.setPen(QColor("#c8d7e8"))
                p.drawText(QRectF(6, y, label_w - 10, row_h),
                           Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                           p.fontMetrics().elidedText(label, Qt.TextElideMode.ElideRight, label_w - 12))
                p.drawText(QRectF(label_w + length + 4, y, 70, row_h),
                           Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self.fmt(value))
                self.bars.append((rect.adjusted(-label_w, 0, 70, 0), label, value))
        else:
            left, bottom, area_top = 40, h - 34, 32
            n = len(self.values)
            slot = (w - left - 10) / n
            p.setPen(QPen(QColor("#2a3a4d"), 1))
            for frac in (0.25, 0.5, 0.75, 1.0):
                y = bottom - (bottom - area_top) * frac
                p.drawLine(QPointF(left, y), QPointF(w - 10, y))
            p.setPen(QColor("#8fa3b8"))
            p.drawText(QRectF(0, area_top - 6, left - 4, 14), Qt.AlignmentFlag.AlignRight, self.fmt(top))
            every = max(1, round(n / max(1, (w - left) / 45)))
            for i, (label, value) in enumerate(zip(self.labels, self.values)):
                x = left + i * slot
                bh = (bottom - area_top) * value / top
                rect = QRectF(x + slot * 0.12, bottom - bh, max(1, slot * 0.76), bh)
                p.fillRect(rect, bar_color)
                if i % every == 0:
                    p.setPen(QColor("#c8d7e8"))
                    p.drawText(QRectF(x - 20, bottom + 2, slot + 40, 16), Qt.AlignmentFlag.AlignCenter, label)
                self.bars.append((QRectF(x, area_top, slot, bottom - area_top), label, value))

    def fmt(self, value):
        if self.unit == "min":
            return f"{value:,.1f} min"
        return f"{value:,.0f}"

    def mouseMoveEvent(self, event):
        for rect, label, value in self.bars:
            if rect.contains(event.position()):
                QToolTip.showText(event.globalPosition().toPoint(), f"{label}: {self.fmt(value)}", self)
                return
        QToolTip.hideText()


class ActivityCharts(QWidget):
    """History → Activity Charts…: when and where the scanner was busy."""
    PERIODS = (("Last 7 days", 7), ("Last 30 days", 30), ("Last 90 days", 90),
               ("Last 365 days", 365), ("All history", None))

    def __init__(self, parent):
        super().__init__(parent, Qt.WindowType.Window)
        self.setWindowTitle(f"Activity Charts — SDS100 Monitor v{VERSION}")
        self.resize(1100, 820)
        layout = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Period:"))
        self.period = QComboBox()
        for label, days in self.PERIODS:
            self.period.addItem(label, days)
        self.period.setCurrentIndex(1)
        row.addWidget(self.period)
        row.addWidget(QLabel("System:"))
        self.system = QComboBox()
        row.addWidget(self.system)
        row.addWidget(QLabel("Measure:"))
        self.measure = QComboBox()
        self.measure.addItem("Number of receptions", "count")
        self.measure.addItem("Air time (minutes)", "min")
        row.addWidget(self.measure)
        reload_btn = QPushButton("RELOAD HISTORY")
        reload_btn.clicked.connect(self.reload)
        row.addWidget(reload_btn)
        row.addStretch(1)
        layout.addLayout(row)
        self.summary = QLabel("")
        self.summary.setObjectName("summary")
        layout.addWidget(self.summary)
        self.by_hour = BarChart("BY HOUR OF DAY")
        self.by_day = BarChart("PER DAY")
        self.top = BarChart("TOP 15 CHANNELS / TALKGROUPS", horizontal=True)
        self.top.setMinimumHeight(330)
        layout.addWidget(self.by_hour, 1)
        layout.addWidget(self.by_day, 1)
        layout.addWidget(self.top, 2)
        for combo in (self.period, self.system, self.measure):
            combo.currentIndexChanged.connect(self.redraw)
        self.records = []
        self.reload()

    def reload(self):
        self.records = []
        for row in load_reception_rows():
            try:
                start = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
                duration = max(0.0, float(row[2]))
            except ValueError:
                continue
            self.records.append((start, duration, row[3], row[5]))
        systems = sorted({r[2] for r in self.records})
        current = self.system.currentText()
        self.system.blockSignals(True)
        self.system.clear()
        self.system.addItem("All systems")
        self.system.addItems(systems)
        if current in systems:
            self.system.setCurrentText(current)
        self.system.blockSignals(False)
        self.redraw()

    def redraw(self, *_):
        days = self.period.currentData()
        system = self.system.currentText()
        unit = self.measure.currentData()
        today = datetime.now().date()
        since = today - timedelta(days=days - 1) if days else None
        chosen = [r for r in self.records
                  if (since is None or r[0].date() >= since)
                  and (system in ("", "All systems") or r[2] == system)]
        weight = (lambda r: r[1] / 60) if unit == "min" else (lambda r: 1)
        hours = [0.0] * 24
        per_day = defaultdict(float)
        per_channel = defaultdict(float)
        for r in chosen:
            hours[r[0].hour] += weight(r)
            per_day[r[0].date()] += weight(r)
            per_channel[f"{r[3]} ({r[2]})"] += weight(r)
        self.by_hour.set_data([f"{h:02d}" for h in range(24)], hours, unit)
        if chosen:
            first = since or min(per_day)
            span = (today - first).days + 1
            if span <= 120:
                labels = [first + timedelta(days=i) for i in range(span)]
                self.by_day.title = "PER DAY"
                self.by_day.set_data([d.strftime("%m-%d") for d in labels],
                                     [per_day.get(d, 0) for d in labels], unit)
            else:
                months = defaultdict(float)
                for d, v in per_day.items():
                    months[d.strftime("%Y-%m")] += v
                keys = sorted(months)
                self.by_day.title = "PER MONTH"
                self.by_day.set_data(keys, [months[k] for k in keys], unit)
        else:
            self.by_day.set_data([], [], unit)
        ranked = sorted(per_channel.items(), key=lambda kv: -kv[1])[:15]
        self.top.set_data([k for k, _ in ranked], [v for _, v in ranked], unit)
        total_min = sum(r[1] for r in chosen) / 60
        busiest = max(range(24), key=hours.__getitem__) if chosen else None
        self.summary.setText(
            f"{len(chosen):,} receptions • {total_min:,.1f} minutes of air time"
            + (f" • busiest hour {busiest:02d}:00–{busiest:02d}:59" if busiest is not None else ""))


UNIT_LOG_DIR = DATA_DIR / "unit_ids"
UNIT_HEADERS = ["Time", "Unit ID", "Unit Name", "System", "Site", "Department",
                "Channel", "Talkgroup", "Frequency"]


def unit_log_path(timestamp):
    return UNIT_LOG_DIR / f"unit_ids_{timestamp:%Y-%m-%d}.csv"


class UnitIdLog(QWidget):
    """History → Unit ID Log…: which radios were heard, when and where."""

    def __init__(self, parent):
        super().__init__(parent, Qt.WindowType.Window)
        self.setWindowTitle(f"Unit ID Log — SDS100 Monitor v{VERSION}")
        self.resize(1100, 700)
        layout = QVBoxLayout(self)
        row = QHBoxLayout()
        row.addWidget(QLabel("Period:"))
        self.period = QComboBox()
        for label, days in ActivityCharts.PERIODS:
            self.period.addItem(label, days)
        self.period.setCurrentIndex(1)
        row.addWidget(self.period)
        row.addWidget(QLabel("Search:"))
        self.search = QLineEdit()
        self.search.setClearButtonEnabled(True)
        self.search.setPlaceholderText("Unit ID, name, talkgroup, system…")
        row.addWidget(self.search, 1)
        reload_btn = QPushButton("RELOAD")
        reload_btn.clicked.connect(self.reload)
        row.addWidget(reload_btn)
        folder = QPushButton("OPEN FOLDER")
        folder.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(UNIT_LOG_DIR))))
        row.addWidget(folder)
        layout.addLayout(row)
        self.info = QLabel("")
        layout.addWidget(self.info)
        tabs = QTabWidget()
        self.units = QTableWidget(0, 6)
        self.units.setHorizontalHeaderLabels(["Unit ID", "Name", "Times heard", "First heard",
                                              "Last heard", "Talkgroups / channels"])
        self.entries = QTableWidget(0, len(UNIT_HEADERS))
        self.entries.setHorizontalHeaderLabels(UNIT_HEADERS)
        for table in (self.units, self.entries):
            table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            table.setAlternatingRowColors(True)
            table.horizontalHeader().setStretchLastSection(True)
            table.setSortingEnabled(True)
        self.units.cellDoubleClicked.connect(
            lambda r, _c: self.search.setText(self.units.item(r, 0).text()))
        tabs.addTab(self.units, "Units")
        tabs.addTab(self.entries, "All entries")
        layout.addWidget(tabs, 1)
        self.period.currentIndexChanged.connect(self.redraw)
        self.search.textChanged.connect(self.redraw)
        self.rows = []
        self.reload()

    def reload(self):
        self.rows = []
        for path in sorted(UNIT_LOG_DIR.glob("unit_ids_????-??-??.csv")):
            try:
                with path.open(newline="", encoding="utf-8-sig") as f:
                    reader = csv.reader(f)
                    if next(reader, None) != UNIT_HEADERS:
                        continue
                    self.rows.extend(r for r in reader if len(r) == len(UNIT_HEADERS))
            except (OSError, csv.Error, UnicodeDecodeError):
                continue
        self.redraw()

    def redraw(self, *_):
        days = self.period.currentData()
        since = (datetime.now().date() - timedelta(days=days - 1)).isoformat() if days else ""
        term = self.search.text().strip().casefold()
        chosen = [r for r in self.rows if r[0][:10] >= since
                  and (not term or any(term in c.casefold() for c in r))]
        summary = {}
        for r in chosen:
            s = summary.setdefault(r[1], {"name": "", "count": 0, "first": r[0], "last": r[0],
                                          "where": defaultdict(int)})
            s["count"] += 1
            s["first"], s["last"] = min(s["first"], r[0]), max(s["last"], r[0])
            if r[2] and r[2] != r[1]:
                s["name"] = r[2]
            s["where"][r[6] if r[6] != "—" else r[8]] += 1
        for table in (self.units, self.entries):
            table.setSortingEnabled(False)
        self.units.setRowCount(len(summary))
        for i, (uid, s) in enumerate(sorted(summary.items(), key=lambda kv: -kv[1]["count"])):
            where = ", ".join(f"{k} ({v})" for k, v in
                              sorted(s["where"].items(), key=lambda kv: -kv[1])[:3])
            count = QTableWidgetItem()
            count.setData(Qt.ItemDataRole.DisplayRole, s["count"])
            for c, item in enumerate((QTableWidgetItem(uid), QTableWidgetItem(s["name"]), count,
                                      QTableWidgetItem(s["first"]), QTableWidgetItem(s["last"]),
                                      QTableWidgetItem(where))):
                self.units.setItem(i, c, item)
        shown = list(reversed(chosen))[:5000]
        self.entries.setRowCount(len(shown))
        for i, r in enumerate(shown):
            for c, value in enumerate(r):
                self.entries.setItem(i, c, QTableWidgetItem(value))
        for table in (self.units, self.entries):
            table.setSortingEnabled(True)
            table.resizeColumnsToContents()
        more = " (newest 5,000 shown)" if len(chosen) > 5000 else ""
        self.info.setText(f"{len(summary):,} units • {len(chosen):,} transmissions{more}")


class Monitor(QMainWindow):
    # Re-emits every reply from whichever serial thread is current.
    scanner_output = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        # Same settings key as v1.1.x, so the saved window layout carries over.
        self.settings = QSettings("SDS100Monitor", "Monitor110")
        self.archive_browser = None
        self.thread = None
        self.event = None
        self.last_seen = None
        self.active_poll_ms = 500
        self.diagnostic_held_key = None
        self.last_avoided = None
        self.csv_error_shown = False
        self.statistics = defaultdict(lambda: [0, 0.0])
        self.total_receptions = 0
        self.total_seconds = 0.0
        self.scanner_tools = self.activity_charts = self.unit_id_log = None
        self.tray = None
        self.last_unit_key = None
        self.event_alerted = False
        self.alert_last = {}
        try:
            self.alert_rules = json.loads(str(self.settings.value("alerts/rules", "[]")))
        except ValueError:
            self.alert_rules = []
        self.setWindowTitle(f"SDS100 Monitor v{VERSION}")
        icon_file = Path(__file__).with_name("sds100-monitor.svg")
        if icon_file.exists():
            self.setWindowIcon(QIcon(str(icon_file)))
        self.resize(1150, 850)
        self.build_ui()
        self.scanner_label = QLabel("Scanner: not connected")
        self.statusBar().addPermanentWidget(self.scanner_label)
        self.restoreGeometry(self.settings.value("geometry", b""))
        dock_state = self.settings.value("dock_state")
        if dock_state is not None:
            self.restoreState(dock_state)
        self.history_rows = []
        self.load_history()
        splitter_state = self.settings.value("reception_splitter")
        if splitter_state is not None:
            self.reception_splitter.restoreState(splitter_state)
        QTimer.singleShot(0, self.restore_floating_geometry)
        QTimer.singleShot(100, self.install_tab_context_menus)
        if str(self.settings.value("waterfall/open", "false")).lower() == "true":
            QTimer.singleShot(200, self.open_waterfall_window)

    def release_diagnostic_key(self):
        """Queue KEY,<key>,R for a key the diagnostic left held. Returns the key."""
        key = self.diagnostic_held_key
        if key and self.thread and self.thread.isRunning():
            self.thread.send_command(f"KEY,{key},R")
            self.diagnostic_held_key = None
            return key
        return None

    # ---- Scanner Tools, charts, unit log, alerts --------------------------
    def open_window(self, attr, factory):
        window = getattr(self, attr)
        if window is None:
            window = factory()
            setattr(self, attr, window)
        window.show()
        window.raise_()
        window.activateWindow()
        return window

    def open_scanner_tools(self):
        first = self.scanner_tools is None
        tools = self.open_window("scanner_tools", lambda: ScannerTools(self))
        if first:
            self.alerts_panel = AlertsPanel(self)
            tools.tabs.addTab(self.alerts_panel, "Alerts")
            if self.connected:
                tools.status.setText("Connected. Press LOAD FAVORITES LISTS to start.")

    def open_activity_charts(self):
        charts = self.open_window("activity_charts", lambda: ActivityCharts(self))
        charts.reload()

    def open_unit_id_log(self):
        log = self.open_window("unit_id_log", lambda: UnitIdLog(self))
        log.reload()

    def handle_list_xml(self, xml):
        if self.scanner_tools is not None:
            self.scanner_tools.handle_list(xml)

    def save_alert_rules(self):
        self.settings.setValue("alerts/rules", json.dumps(self.alert_rules))

    def add_alert_rule(self, field, match, text):
        text = str(text).strip()
        if not text or text == "—":
            return
        rule = {"field": field, "match": match, "text": text, "enabled": True}
        if any(r["field"] == field and r["match"] == match and r["text"] == text
               for r in self.alert_rules):
            self.statusBar().showMessage(f"An alert for {text} already exists.", 6000)
            return
        self.alert_rules.append(rule)
        self.save_alert_rules()
        if getattr(self, "alerts_panel", None) is not None:
            self.alerts_panel.refresh()
        self.statusBar().showMessage(
            f"Alert added: {field} {ALERT_MATCHES.get(match, match)} '{text}'. "
            "Manage alerts in View → Scanner Tools → Alerts.", 8000)

    def check_alerts(self, values, unit_only=False):
        """Notify for the first matching rule. Returns True if an alert was raised."""
        now = time.monotonic()
        cooldown = int(self.settings.value("alerts/cooldown", 60))
        for rule in self.alert_rules:
            if unit_only and rule.get("field") not in ("Unit ID", "Any field"):
                continue
            if not alert_matches(rule, values):
                continue
            rule_key = (rule["field"], rule["match"], rule["text"])
            if now - self.alert_last.get(rule_key, -1e9) < cooldown:
                continue
            self.alert_last[rule_key] = now
            title = f"Active: {values.get('Channel', '—')}"
            detail = " • ".join(v for v in (values.get("System"), values.get("Talkgroup"),
                                            values.get("Frequency"), values.get("Unit ID"))
                                if v and v != "—")
            self.notify(title, detail)
            return True     # one notification per reception
        return False

    def notify(self, title, text):
        stamp = datetime.now().strftime("%H:%M:%S")
        if getattr(self, "alerts_panel", None) is not None:
            self.alerts_panel.log(f"{stamp}  {title} — {text}")
        self.statusBar().showMessage(f"🔔 {title} — {text}", 10000)
        s = self.settings
        if str(s.value("alerts/notify", "true")).lower() == "true":
            if shutil.which("notify-send"):
                subprocess.Popen(["notify-send", "-a", "SDS100 Monitor", "-i",
                                  str(Path(__file__).with_name("sds100-monitor.svg")), title, text],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif QSystemTrayIcon.isSystemTrayAvailable():
                if self.tray is None:
                    self.tray = QSystemTrayIcon(self.windowIcon(), self)
                    self.tray.show()
                self.tray.showMessage(title, text, QSystemTrayIcon.MessageIcon.Information, 8000)
        if str(s.value("alerts/sound", "true")).lower() == "true":
            sound = Path("/usr/share/sounds/freedesktop/stereo/message-new-instant.oga")
            if sound.exists() and shutil.which("paplay"):
                subprocess.Popen(["paplay", str(sound)],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                QApplication.beep()

    def log_unit(self, values, unit_id, unit_name):
        now = datetime.now()
        row = [now.strftime("%Y-%m-%d %H:%M:%S"), unit_id,
               unit_name if unit_name not in ("—", unit_id) else "",
               values.get("System", ""), values.get("Site", ""), values.get("Department", ""),
               values.get("Channel", ""), values.get("Talkgroup", ""), values.get("Frequency", "")]
        try:
            UNIT_LOG_DIR.mkdir(parents=True, exist_ok=True)
            path = unit_log_path(now)
            fresh = not path.exists() or path.stat().st_size == 0
            with path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if fresh:
                    writer.writerow(UNIT_HEADERS)
                writer.writerow(row)
        except OSError as exc:
            self.statusBar().showMessage(f"Unit ID log save failed: {exc}", 10000)

    # ---- Help menu ---------------------------------------------------------
    ABOUT_FALLBACK = (
        "# SDS100 Monitor\n\n"
        "Copyright © 2026 J. Lynch. Licensed under the GNU General Public License, "
        "version 3 or later (GPL-3.0-or-later). This program comes with ABSOLUTELY NO "
        "WARRANTY. Developed with the assistance of AI tools. Not affiliated with or "
        "endorsed by Uniden America Corporation.\n\n"
        "ABOUT.md was not found next to the program; see "
        "<https://www.gnu.org/licenses/gpl-3.0.html> for the license.")

    def show_text_window(self, title, filename, markdown):
        path = Path(__file__).with_name(filename)
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            text, markdown = self.ABOUT_FALLBACK, True
        dialog = QDialog(self)
        dialog.setWindowTitle(title)
        dialog.resize(760, 640)
        layout = QVBoxLayout(dialog)
        if markdown:
            heading = QLabel(f"SDS100 Monitor v{VERSION}")
            heading.setStyleSheet("font-size:20px;font-weight:700;color:#8bd6f2;")
            layout.addWidget(heading)
        view = QTextEdit()
        view.setReadOnly(True)
        if markdown:
            view.setMarkdown(text)
        else:
            view.setPlainText(text)
            view.setFont(QFont("Monospace", 10))
        layout.addWidget(view, 1)
        close = QPushButton("Close")
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.exec()

    def show_about(self):
        self.show_text_window("About SDS100 Monitor", "ABOUT.md", True)

    def show_license(self):
        self.show_text_window("SDS100 Monitor — License (GNU GPL v3)", "LICENSE", False)

    def restore_floating_geometry(self):
        for dock in self.docks:
            if dock.isFloating():
                geometry = self.settings.value("floating/" + dock.objectName())
                if geometry:
                    dock.restoreGeometry(geometry)

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        root.setMaximumHeight(160)
        layout = QVBoxLayout(root)
        controls = QHBoxLayout()
        self.port = QComboBox()
        self.port.setEditable(True)
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port.addItems(ports or ["/dev/ttyACM0"])
        self.port.setCurrentText(self.settings.value("port", "/dev/ttyACM0"))
        self.baud = QComboBox()
        self.baud.addItems(["115200", "57600", "38400", "19200", "9600"])
        self.baud.setCurrentText(self.settings.value("baud", "115200"))
        self.interval = QSpinBox()
        self.interval.setRange(250, 5000)
        self.interval.setSingleStep(250)
        self.interval.setSuffix(" ms")
        self.interval.setValue(int(self.settings.value("poll_ms", 500)))
        self.interval.valueChanged.connect(self.change_poll_interval)
        self.connect_btn = QPushButton("CONNECT")
        self.connect_btn.clicked.connect(self.toggle)
        for label, widget in (("Port", self.port), ("Baud", self.baud),
                              ("Polling", self.interval)):
            controls.addWidget(QLabel(label))
            controls.addWidget(widget)
        controls.addWidget(self.connect_btn)
        layout.addLayout(controls)

        info_tab = ResponsiveInfo()
        info_layout = QVBoxLayout(info_tab)
        self.status = QLabel("DISCONNECTED")
        self.status.setObjectName("status")
        info_layout.addWidget(self.status)
        self.status.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.status.customContextMenuRequested.connect(
            lambda pos: self.live_context_menu(self.status.mapToGlobal(pos)))
        grid = QGridLayout()
        self.fields = {}
        # Site and Unit ID are display-only; they are not written to the CSV,
        # so the history file format stays unchanged.
        info_fields = ("System", "Site", "Department", "Channel", "Frequency",
                       "Talkgroup", "Unit ID", "Mode", "RSSI")
        for row, key in enumerate(info_fields):
            grid.addWidget(QLabel(key.upper()), row, 0)
            val = QLabel("—")
            val.setObjectName("value")
            val.setWordWrap(True)
            grid.addWidget(val, row, 1)
            val.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            val.customContextMenuRequested.connect(
                lambda pos, w=val: self.live_context_menu(w.mapToGlobal(pos)))
            self.fields[key] = val
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 4)
        for row in range(len(info_fields)):
            grid.setRowStretch(row, 1)
        info_layout.addLayout(grid, 1)
        self.signal = QProgressBar()
        self.signal.setRange(0, 100)
        self.signal.setFormat("Signal strength: unavailable")
        info_layout.addWidget(self.signal)
        # Native Qt docks: tabbed while attached; draggable into standalone windows.
        self.setDockOptions(
            QMainWindow.DockOption.AllowTabbedDocks
            | QMainWindow.DockOption.AllowNestedDocks
            | QMainWindow.DockOption.AnimatedDocks
        )
        live_tab = QWidget()
        live_layout = QVBoxLayout(live_tab)
        control_tab = QWidget()
        control_outer = QVBoxLayout(control_tab)
        control_scroll = QScrollArea()
        control_scroll.setWidgetResizable(True)
        control_content = QWidget()
        control_layout = QVBoxLayout(control_content)
        self.build_control_panel(control_layout)
        control_layout.addStretch(1)
        control_scroll.setWidget(control_content)
        control_outer.addWidget(control_scroll)
        keypad_tab = QWidget()
        keypad_outer = QVBoxLayout(keypad_tab)
        keypad_scroll = QScrollArea()
        keypad_scroll.setWidgetResizable(True)
        keypad_content = QWidget()
        keypad_layout = QVBoxLayout(keypad_content)
        self.build_keypad(keypad_layout)
        keypad_scroll.setWidget(keypad_content)
        keypad_outer.addWidget(keypad_scroll)
        self.build_waterfall_window()

        self.docks = []
        for name, object_name, widget in (
            ("LIVE MONITOR", "dockLive", live_tab),
            ("SCANNER CONTROL", "dockControl", control_tab),
            ("SDS100 KEYPAD", "dockKeypad", keypad_tab),
            ("SCANNER INFORMATION", "dockInfo", info_tab),
        ):
            dock = QDockWidget(name, self)
            dock.setObjectName(object_name)
            dock.setWidget(widget)
            dock.setFeatures(
                QDockWidget.DockWidgetFeature.DockWidgetMovable
                | QDockWidget.DockWidgetFeature.DockWidgetFloatable
                | QDockWidget.DockWidgetFeature.DockWidgetClosable
            )
            self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
            dock.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            dock.customContextMenuRequested.connect(
                lambda point, d=dock: self.dock_context_menu(d, d.mapToGlobal(point)))
            # Qt creates new tab bars when panels are dragged into new groups;
            # bind right-click menus to them whenever a panel moves.
            dock.topLevelChanged.connect(
                lambda _floating: QTimer.singleShot(0, self.install_tab_context_menus))
            dock.dockLocationChanged.connect(
                lambda _area: QTimer.singleShot(0, self.install_tab_context_menus))
            self.docks.append(dock)
        for dock in self.docks[1:]:
            self.tabifyDockWidget(self.docks[0], dock)
        self.docks[3].raise_()

        history_menu = self.menuBar().addMenu("History")
        history_menu.addAction("Browse CSV archives…", self.open_archive_browser)
        history_menu.addAction("Activity Charts…", self.open_activity_charts)
        history_menu.addAction("Unit ID Log…", self.open_unit_id_log)
        view_menu = self.menuBar().addMenu("View")
        for dock in self.docks:
            view_menu.addAction(dock.toggleViewAction())
        view_menu.addSeparator()
        for dock in self.docks:
            detach_action = view_menu.addAction("Detach " + dock.windowTitle())
            detach_action.triggered.connect(
                lambda checked=False, d=dock: self.detach_dock(d))
            attach_action = view_menu.addAction("Dock " + dock.windowTitle())
            attach_action.triggered.connect(
                lambda checked=False, d=dock: self.attach_dock(d))
        # One panel selector and two actions replace ten dock buttons.
        dock_bar = QHBoxLayout()
        dock_bar.setSpacing(7)
        dock_bar.addWidget(QLabel("PANEL"))
        self.panel_choice = QComboBox()
        self.panel_choice.addItems(["Live", "Control", "Keypad", "Info"])
        self.panel_choice.setToolTip("Choose a panel to detach or dock")
        dock_bar.addWidget(self.panel_choice)
        pop = QPushButton("Detach ↗")
        pop.setToolTip("Open the selected panel in its own window")
        pop.clicked.connect(lambda: self.detach_dock(self.docks[self.panel_choice.currentIndex()]))
        dock_bar.addWidget(pop)
        put = QPushButton("Dock ↙")
        put.setToolTip("Return the selected panel to the tab area")
        put.clicked.connect(lambda: self.attach_dock(self.docks[self.panel_choice.currentIndex()]))
        dock_bar.addWidget(put)
        dock_bar.addStretch(1)
        layout.addLayout(dock_bar)
        view_menu.addSeparator()
        waterfall_action = view_menu.addAction("Waterfall…")
        waterfall_action.setToolTip("Open the waterfall in its own window")
        waterfall_action.triggered.connect(self.open_waterfall_window)
        tools_action = view_menu.addAction("Scanner Tools…")
        tools_action.setToolTip("Lists, quick keys, service types, location and alerts")
        tools_action.triggered.connect(self.open_scanner_tools)
        view_menu.addSeparator()
        reset_action = view_menu.addAction("Return all panels to tabs")
        reset_action.triggered.connect(self.reset_docks)
        help_menu = self.menuBar().addMenu("Help")
        help_menu.addAction("About SDS100 Monitor…", self.show_about)
        help_menu.addAction("License…", self.show_license)
        hint = QLabel("Choose a panel, then Detach or Dock. "
                      "View → Return all panels to tabs resets the layout.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#a5bdd2;padding:4px;")
        layout.addWidget(hint)
        layout.addStretch(1)
        # A vertical splitter lets the user drag the boundary between statistics
        # and history; both tables retain their own independent scrollbars.
        self.reception_splitter = QSplitter(Qt.Orientation.Vertical)
        self.reception_splitter.setObjectName("receptionSplitter")
        self.reception_splitter.setChildrenCollapsible(False)
        self.reception_splitter.setHandleWidth(9)
        stats_panel = QWidget()
        stats_layout = QVBoxLayout(stats_panel)
        stats_layout.setContentsMargins(0, 0, 0, 0)
        stats_layout.addWidget(QLabel("RECEPTION STATISTICS — saved history"))
        self.summary = QLabel("0 receptions • 0.0 seconds")
        self.summary.setObjectName("summary")
        stats_layout.addWidget(self.summary)
        self.stats_table = QTableWidget(0, 4)
        self.stats_table.setHorizontalHeaderLabels(
            ["Channel", "System", "Receptions", "Total time (s)"])
        self.stats_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch)
        self.stats_table.setSortingEnabled(True)
        self.stats_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.stats_table.customContextMenuRequested.connect(self.stats_context_menu)
        stats_layout.addWidget(self.stats_table, 1)
        history_panel = QWidget()
        history_layout = QVBoxLayout(history_panel)
        history_layout.setContentsMargins(0, 0, 0, 0)
        history_layout.addWidget(QLabel("RECEPTION HISTORY — searchable (latest 500 events)"))
        self.table = QTableWidget(0, len(HEADERS))
        self.table.setHorizontalHeaderLabels(HEADERS)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.history_context_menu)
        self.table.cellDoubleClicked.connect(self.history_details)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 155)
        self.table.setColumnWidth(1, 155)
        self.table.setColumnWidth(5, 210)
        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("Search reception history:"))
        self.history_search = QLineEdit()
        self.history_search.setPlaceholderText("Type to filter recent receptions…")
        self.history_search.setClearButtonEnabled(True)
        self.history_search.textChanged.connect(self.filter_history)
        search_row.addWidget(self.history_search, 1)
        self.history_match_count = QLabel("0 / 0")
        search_row.addWidget(self.history_match_count)
        history_layout.addLayout(search_row)
        history_layout.addWidget(self.table, 1)
        archive_button = QPushButton("BROWSE HISTORY ARCHIVES…")
        archive_button.setToolTip("Search any daily CSV file or the original legacy reception log")
        archive_button.clicked.connect(self.open_archive_browser)
        history_layout.addWidget(archive_button)
        clear = QPushButton("CLEAR DISPLAY (CSV is preserved)")
        clear.clicked.connect(self.clear_history_display)
        history_layout.addWidget(clear)
        self.reception_splitter.addWidget(stats_panel)
        self.reception_splitter.addWidget(history_panel)
        self.reception_splitter.setStretchFactor(0, 1)
        self.reception_splitter.setStretchFactor(1, 3)
        self.reception_splitter.setSizes([220, 460])
        live_layout.addWidget(self.reception_splitter, 1)
        self.setStyleSheet("""
            QWidget { background:#171b22; color:#e9eef5; font-size:14px; }
            QLabel#status { font-size:21px; font-weight:700; color:#e6a65a; padding:8px; }
            QLabel#value { font-size:21px; font-weight:650; padding:2px; }
            QLabel#summary { font-size:17px; font-weight:650; color:#79d6bd; }
            QPushButton { background:#293544; border:1px solid #53647a;
                          border-radius:5px; padding:9px; }
            QPushButton:hover { background:#3d536b; }
            QComboBox, QSpinBox { background:#293544; padding:5px; }
            QTableWidget { background:#1c2530; alternate-background-color:#253140;
                           gridline-color:#405066; }
            QHeaderView::section { background:#35445a; padding:6px; }
            QProgressBar { background:#283341; border:1px solid #53647a; height:19px; }
            QProgressBar::chunk { background:#55b98b; }
            /* Decorated dock tabs: distinct selected, hover and inactive states */
            QTabBar { background:#171b22; qproperty-drawBase: 0; }
            QTabBar::tab {
                background:#263448;
                color:#c8d7e8;
                border:1px solid #465c75;
                border-bottom:3px solid #465c75;
                border-top-left-radius:8px;
                border-top-right-radius:8px;
                min-width:125px;
                padding:11px 20px;
                margin:3px 3px 0 0;
                font-size:13px;
                font-weight:600;
            }
            QTabBar::tab:hover:!selected {
                background:#364e69;
                color:#ffffff;
                border-color:#6d9fc6;
                border-bottom-color:#6d9fc6;
            }
            QTabBar::tab:selected {
                background:#245b91;
                color:#ffffff;
                border:1px solid #69b8ef;
                border-bottom:3px solid #76d5f4;
                font-weight:700;
            }
            QTabBar::tab:disabled { color:#718094; background:#202832; }
            QSplitter::handle:vertical {
                background:#426789;
                border-top:2px solid #83c3e9;
                border-bottom:2px solid #263c53;
                margin:1px 12px;
            }
            QSplitter::handle:vertical:hover { background:#69a8d6; }
            QMenu {
                background-color:#202d3d;
                color:#edf5ff;
                border:2px solid #567c9f;
                border-radius:7px;
                padding:6px;
                font-size:14px;
            }
            QMenu::item {
                background:transparent;
                padding:8px 32px 8px 14px;
                margin:2px 3px;
                border-radius:5px;
                min-height:21px;
            }
            QMenu::item:selected:enabled {
                background:#2975b8;
                color:#ffffff;
                border-left:4px solid #85dcff;
                padding-left:10px;
                font-weight:700;
            }
            QMenu::item:disabled { color:#8392a6; }
            QMenu::separator {
                height:1px;
                background:#51637a;
                margin:6px 10px;
            }
            QDockWidget { border:1px solid #40536b; }
            QDockWidget::title {
                background:#25354a;
                color:#eaf4ff;
                padding:7px 10px;
                font-weight:700;
            }
        """)

    def history_details(self, row_index, _column):
        row = [self.table.item(row_index, c).text() if self.table.item(row_index, c) else ""
               for c in range(len(HEADERS))]
        show_reception_details(self, row, self.history_search.setText)

    def history_context_menu(self, point):
        row = selected_record(self.table, point)
        menu = QMenu(self)
        if row:
            clicked = self.table.itemAt(point)
            menu.addAction("Copy Selected Cell", lambda: copy_text(clicked.text()))
            add_copy_actions(menu, row)
            menu.addSeparator()
            menu.addAction("Search for This Channel", lambda: self.history_search.setText(row[5]))
            menu.addAction("Search for This System", lambda: self.history_search.setText(row[3]))
            try:
                row_mhz = self.validate_mhz(row[6])
            except ValueError:
                row_mhz = None
            hold_freq = menu.addAction(
                f"Hold on This Frequency ({row_mhz:.4f} MHz)" if row_mhz else "Hold on This Frequency",
                lambda: self.tune_frequency(row_mhz))
            hold_freq.setEnabled(bool(row_mhz and self.connected))
            menu.addAction("Alert When This Channel Is Active",
                           lambda: self.add_alert_rule("Channel", "is", row[5]))
            if row[7] not in ("", "—"):
                menu.addAction("Alert When This Talkgroup Is Active",
                               lambda: self.add_alert_rule("Talkgroup", "is", row[7]))
            menu.addAction("View Reception Details…", lambda: show_reception_details(self, row, self.history_search.setText))
            menu.addAction("Export Selected Record…", lambda: export_csv_rows(self, [row]))
        menu.addSeparator()
        menu.addAction("Show All Records", self.history_search.clear).setEnabled(bool(self.history_search.text()))
        menu.addAction("Export Search Results…", lambda: export_csv_rows(self, self.visible_history_rows()))
        menu.addAction("Open History Archive Browser…", self.open_archive_browser)
        menu.addAction("Open Today's CSV File", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(daily_log_path(datetime.now()))))).setEnabled(daily_log_path(datetime.now()).exists())
        menu.addAction("Open History Folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(DAILY_LOG_DIR))))
        menu.exec(self.table.viewport().mapToGlobal(point))

    def visible_history_rows(self):
        return [[self.table.item(r, c).text() if self.table.item(r, c) else ""
                 for c in range(len(HEADERS))] for r in range(self.table.rowCount())]

    def stats_context_menu(self, point):
        item = self.stats_table.itemAt(point)
        menu = QMenu(self)
        if item:
            r = item.row()
            values = [self.stats_table.item(r, c).text() if self.stats_table.item(r, c) else "" for c in range(4)]
            menu.addAction("Copy Selected Statistic", lambda: copy_text(item.text()))
            menu.addAction("Copy Statistics Row", lambda: copy_text("\t".join(values)))
            menu.addAction("Show Reception History for Channel", lambda: self.history_search.setText(values[0]))
            menu.addAction("Sort by Reception Count", lambda: self.stats_table.sortItems(2, Qt.SortOrder.DescendingOrder))
            menu.addAction("Sort by Total Duration", lambda: self.stats_table.sortItems(3, Qt.SortOrder.DescendingOrder))
            menu.addAction("Sort Alphabetically", lambda: self.stats_table.sortItems(0, Qt.SortOrder.AscendingOrder))
            menu.addSeparator()
        menu.addAction("Copy Statistics Table", lambda: copy_text("\n".join(
            "\t".join(self.stats_table.item(r, c).text() if self.stats_table.item(r, c) else ""
                       for c in range(4)) for r in range(self.stats_table.rowCount()))))
        menu.addAction("Export Statistics to CSV…", self.export_statistics)
        menu.addAction("Refresh Statistics", self.refresh_stats)
        menu.exec(self.stats_table.viewport().mapToGlobal(point))

    def export_statistics(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export reception statistics", str(Path.home() / "reception_statistics.csv"), "CSV files (*.csv)")
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Channel", "System", "Receptions", "Total time (s)"])
                for (channel, system), (count, duration) in sorted(self.statistics.items()):
                    writer.writerow([channel, system, count, f"{duration:.1f}"])
        except OSError as exc:
            QMessageBox.warning(self, "Export failed", str(exc))

    def open_archive_browser(self):
        if self.archive_browser is None or not self.archive_browser.isVisible():
            self.archive_browser = HistoryArchiveBrowser(self)
            self.archive_browser.show()
        else:
            self.archive_browser.refresh_files()
            self.archive_browser.raise_()
            self.archive_browser.activateWindow()

    def live_context_menu(self, global_point):
        """Read-only copying plus existing, connection-gated scanner commands."""
        menu = QMenu(self)
        for field in ("Channel", "Frequency", "System", "Site", "Department",
                      "Talkgroup", "Unit ID"):
            value = self.fields[field].text().strip()
            action = menu.addAction(f"Copy {field}",
                                    lambda checked=False, v=value: copy_text(v))
            action.setEnabled(bool(value and value != "—"))
        menu.addSeparator()
        connected = bool(self.thread and self.thread.isRunning() and
                         self.status.text() != "DISCONNECTED")
        hold = menu.addAction("Hold on Current Channel",
                              lambda: self.control("channel_hold"))
        hold.setEnabled(connected and bool(getattr(self, "current_channel_index", None))
                        and bool(getattr(self, "current_channel_type", None)))
        scan = menu.addAction("Resume Scanning", lambda: self.control("scan"))
        scan.setEnabled(connected)
        menu.addSeparator()
        menu.addAction("Show Reception History", lambda: self.docks[0].raise_())
        menu.addAction("Browse History Archives…", self.open_archive_browser)
        menu.exec(global_point)

    def install_tab_context_menus(self):
        """Bind Qt's internal dock tab bars without replacing native docking."""
        for bar in self.findChildren(QTabBar):
            if bar.property("sds100_menu_bound"):
                continue
            bar.setProperty("sds100_menu_bound", True)
            bar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            bar.customContextMenuRequested.connect(
                lambda point, b=bar: self.tab_context_menu(b, point))

    def tab_context_menu(self, bar, point):
        index = bar.tabAt(point)
        if index < 0:
            return
        title = bar.tabText(index).replace("&", "").strip()
        dock = next((d for d in self.docks if d.windowTitle() == title), None)
        if dock:
            self.dock_context_menu(dock, bar.mapToGlobal(point))

    def dock_context_menu(self, dock, global_point):
        menu = QMenu(self)
        if dock.isFloating():
            menu.addAction("Reattach Panel", lambda: self.attach_dock(dock))
        else:
            menu.addAction("Detach Panel", lambda: self.detach_dock(dock))
        menu.addAction("Hide This Panel", dock.hide)
        menu.addSeparator()
        menu.addAction("Show All Panels", self.show_all_docks)
        menu.addAction("Reset Panel Layout", self.reset_docks)
        menu.addAction("Save Current Layout", self.save_settings)
        menu.exec(global_point)

    def show_all_docks(self):
        for dock in self.docks:
            dock.show()
        QTimer.singleShot(0, self.install_tab_context_menus)

    def detach_dock(self, dock):
        dock.show()
        dock.setFloating(True)
        geometry = self.settings.value("floating/" + dock.objectName())
        if geometry:
            dock.restoreGeometry(geometry)
        else:
            dock.resize(max(520, dock.width()), max(500, dock.height()))
        dock.raise_()
        dock.activateWindow()
        QTimer.singleShot(0, self.install_tab_context_menus)

    def attach_dock(self, dock):
        if dock.isFloating():
            self.settings.setValue("floating/" + dock.objectName(),
                                   dock.saveGeometry())
        dock.setFloating(False)
        dock.show()
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
        anchor = next((d for d in self.docks if d is not dock and not d.isFloating()),
                      None)
        if anchor is not None:
            self.tabifyDockWidget(anchor, dock)
        dock.raise_()
        QTimer.singleShot(0, self.install_tab_context_menus)

    def reset_docks(self):
        for dock in self.docks:
            if dock.isFloating():
                self.settings.setValue("floating/" + dock.objectName(),
                                       dock.saveGeometry())
            dock.setFloating(False)
            dock.show()
            self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
        for other in self.docks[1:]:
            self.tabifyDockWidget(self.docks[0], other)
        self.docks[3].raise_()
        QTimer.singleShot(0, self.install_tab_context_menus)

    @staticmethod
    def valid_index(node):
        if node is None:
            return None
        raw = node.attrib.get("Index", "")
        return raw if raw.isdigit() and int(raw) != 4294967295 else None

    def build_control_panel(self, layout):
        group = QGroupBox("SCANNER CONTROL • click only when connected")
        grid = QGridLayout(group)
        buttons = [
            ("RESUME SCAN", "scan", "#1b8a5a", 0, 0),
            ("CHANNEL HOLD", "channel_hold", "#a87d15", 0, 1),
            ("SYSTEM HOLD", "system_hold", "#2167b1", 1, 0),
            ("DEPARTMENT HOLD", "dept_hold", "#2167b1", 1, 1),
            ("◀ PREVIOUS CHANNEL", "previous", "#566476", 2, 0),
            ("NEXT CHANNEL ▶", "next", "#566476", 2, 1),
            ("TEMPORARY AVOID", "avoid", "#bd6b23", 3, 0),
            ("REMOVE AVOID", "unavoid", "#7654a6", 3, 1),
        ]
        self.control_buttons = []
        self.unavoid_btn = None
        for label, action, color, row, col in buttons:
            btn = QPushButton(label)
            btn.setStyleSheet(
                f"QPushButton {{ background:{color}; color:white;"
                " font-weight:700; padding:10px; border-radius:6px; }}"
                "QPushButton:disabled { background:#414750; color:#a4a9b0; }"
            )
            btn.clicked.connect(lambda checked=False, a=action: self.control(a))
            btn.setEnabled(False)
            grid.addWidget(btn, row, col)
            self.control_buttons.append(btn)
            if action == "unavoid":
                self.unavoid_btn = btn
                btn.setToolTip("Removes the avoid from the channel most recently "
                               "avoided with TEMPORARY AVOID")
        self.command_status = QLabel("Connect to enable controls.")
        grid.addWidget(self.command_status, 4, 0, 1, 2)
        layout.addWidget(group)
        self.build_scanner_settings(layout)

    # ---- Audio, recording, clock, tuning and battery ---------------------
    # Commands from Remote Command Specification V2.00: VOL, SQL, URC, DTM,
    # QSH and GCS.
    URC_ERRORS = {
        "0001": "file access error (check the SD card)",
        "0002": "battery too low to record",
        "0003": "recording session limit reached",
        "0004": "the scanner's clock was lost; set the clock, then try again",
    }
    CHARGE_STATES = {
        "0": "no external power", "1": "battery gauge starting",
        "2": "battery temperature abnormal", "3": "power supply abnormal",
        "4": "fully charged", "5": "recharging", "6": "charging",
    }
    GCS_PATTERN = re.compile(
        r"GCS,CST=(\d+),VOLT=(\d+)mV:(\d+)%,CURR=([+-]?\d+)mA,TEMP=\s*([-+]?[\d.]+)C")

    def build_scanner_settings(self, layout):
        self.settings_controls = []
        self.recording = None
        self.clock_step = None
        self.pending_qsh = None
        self.qsh_verify = None
        self.audio_pending = {}
        self.audio_hold_until = 0.0
        self.low_battery_warned = False

        audio = QGroupBox("AUDIO")
        audio_grid = QGridLayout(audio)
        self.audio_sliders, self.audio_labels = {}, {}
        for row, (name, cmd) in enumerate((("Volume", "VOL"), ("Squelch", "SQL"))):
            audio_grid.addWidget(QLabel(name.upper()), row, 0)
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(0, 15)          # SDS100 range (SDS200: set on connect)
            slider.setPageStep(1)
            slider.setTickPosition(QSlider.TickPosition.TicksBelow)
            slider.setTickInterval(1)
            slider.setEnabled(False)
            slider.valueChanged.connect(lambda value, c=cmd: self.audio_changed(c, value))
            value_label = QLabel("—")
            value_label.setMinimumWidth(30)
            audio_grid.addWidget(slider, row, 1)
            audio_grid.addWidget(value_label, row, 2)
            self.audio_sliders[cmd], self.audio_labels[cmd] = slider, value_label
            self.settings_controls.append(slider)
        audio_grid.setColumnStretch(1, 1)
        # Send after the slider stops moving, not on every step.
        self.audio_timer = QTimer(self)
        self.audio_timer.setSingleShot(True)
        self.audio_timer.setInterval(300)
        self.audio_timer.timeout.connect(self.send_audio)
        layout.addWidget(audio)

        rec = QGroupBox("RECORDING")
        rec_row = QHBoxLayout(rec)
        self.rec_button = QPushButton("● START RECORDING")
        self.rec_button.setStyleSheet(
            "QPushButton {background:#a83232; color:white; font-weight:700; padding:9px; border-radius:6px;}"
            "QPushButton:disabled {background:#414750; color:#a4a9b0;}")
        self.rec_button.setEnabled(False)
        self.rec_button.clicked.connect(self.toggle_recording)
        self.settings_controls.append(self.rec_button)
        rec_row.addWidget(self.rec_button)
        self.rec_state_label = QLabel("Recording: —")
        self.rec_state_label.setWordWrap(True)
        rec_row.addWidget(self.rec_state_label, 1)
        layout.addWidget(rec)

        clock = QGroupBox("SCANNER CLOCK")
        clock_grid = QGridLayout(clock)
        read_btn = QPushButton("READ CLOCK")
        read_btn.clicked.connect(self.read_clock)
        sync_btn = QPushButton("SET CLOCK FROM PC")
        sync_btn.setToolTip("Sets the scanner's date and time to this computer's, keeping "
                            "the scanner's daylight-saving setting, then reads it back to check")
        sync_btn.clicked.connect(self.sync_clock)
        for b in (read_btn, sync_btn):
            b.setEnabled(False)
            self.settings_controls.append(b)
        clock_grid.addWidget(read_btn, 0, 0)
        clock_grid.addWidget(sync_btn, 0, 1)
        self.clock_label = QLabel("Scanner clock: —")
        self.clock_label.setWordWrap(True)
        clock_grid.addWidget(self.clock_label, 1, 0, 1, 2)
        layout.addWidget(clock)

        tune = QGroupBox("TUNE TO FREQUENCY • Quick Search Hold")
        tune_grid = QGridLayout(tune)
        self.tune_entry = QLineEdit()
        self.tune_entry.setPlaceholderText("Frequency in MHz, e.g. 162.5500")
        self.tune_entry.returnPressed.connect(lambda: self.tune_frequency())
        self.tune_entry.setEnabled(False)
        tune_btn = QPushButton("HOLD ON FREQUENCY")
        tune_btn.clicked.connect(lambda: self.tune_frequency())
        tune_btn.setEnabled(False)
        self.settings_controls += [self.tune_entry, tune_btn]
        tune_grid.addWidget(self.tune_entry, 0, 0)
        tune_grid.addWidget(tune_btn, 0, 1)
        tune_note = QLabel("Also: right-click a reception in history → Hold on This Frequency. "
                           "The scanner ignores this while it is in a menu.")
        tune_note.setWordWrap(True)
        tune_note.setStyleSheet("color:#a5bdd2;")
        tune_grid.addWidget(tune_note, 1, 0, 1, 2)
        layout.addWidget(tune)

        self.rec_indicator = QLabel("● REC")
        self.rec_indicator.setStyleSheet("color:#ff5c5c; font-weight:700; padding:0 8px;")
        self.rec_indicator.setVisible(False)
        self.statusBar().addPermanentWidget(self.rec_indicator)
        self.battery_label = QLabel("Battery: —")
        self.battery_label.setStyleSheet("padding:0 8px;")
        self.statusBar().addPermanentWidget(self.battery_label)
        self.battery_timer = QTimer(self)
        self.battery_timer.setInterval(30000)
        self.battery_timer.timeout.connect(self.poll_battery)

    def set_settings_enabled(self, enabled):
        for widget in self.settings_controls:
            widget.setEnabled(enabled)
        if enabled:
            QTimer.singleShot(1500, self.poll_battery)
            self.battery_timer.start()
        else:
            self.battery_timer.stop()
            self.battery_label.setText("Battery: —")
            self.battery_label.setStyleSheet("padding:0 8px;")
            self.rec_indicator.setVisible(False)
            self.recording = None
            self.rec_state_label.setText("Recording: —")
            self.clock_step = self.pending_qsh = self.qsh_verify = None

    def queue(self, command):
        if self.thread and self.thread.isRunning():
            self.thread.send_command(command)
            return True
        return False

    # Audio --------------------------------------------------------------
    def audio_changed(self, cmd, value):
        self.audio_labels[cmd].setText(str(value))
        self.audio_pending[cmd] = value
        # Don't let status updates move the slider back while it is in use.
        self.audio_hold_until = time.monotonic() + 2.5
        self.audio_timer.start()

    def send_audio(self):
        for cmd, value in self.audio_pending.items():
            if self.queue(f"{cmd},{value}"):
                self.command_reply(f"QUEUED: {cmd},{value}")
        self.audio_pending.clear()

    def sync_audio(self, prop):
        if prop is None or time.monotonic() < self.audio_hold_until:
            return
        for cmd in ("VOL", "SQL"):
            raw = prop.attrib.get(cmd, "").strip()
            if raw.isdigit():
                slider = self.audio_sliders[cmd]
                slider.blockSignals(True)
                slider.setValue(int(raw))
                slider.blockSignals(False)
                self.audio_labels[cmd].setText(raw)

    # Recording ------------------------------------------------------------
    def toggle_recording(self):
        start = not self.recording
        if self.queue(f"URC,{1 if start else 0}"):
            self.rec_state_label.setText("Starting recording…" if start else "Stopping recording…")

    def sync_recording(self, prop):
        if prop is None:
            return
        state = prop.attrib.get("Rec", "").strip().lower()
        if state not in ("on", "off"):
            return
        recording = state == "on"
        if recording == self.recording:
            return
        self.recording = recording
        self.rec_indicator.setVisible(recording)
        self.rec_button.setText("■ STOP RECORDING" if recording else "● START RECORDING")
        self.rec_state_label.setText("Recording: ON (saving to the scanner's SD card)"
                                     if recording else "Recording: off")

    # Clock ---------------------------------------------------------------
    def read_clock(self):
        if self.queue("DTM"):
            self.clock_step = "read"
            self.clock_label.setText("Reading scanner clock…")

    def sync_clock(self):
        # Read first, so the scanner's own daylight-saving setting is kept.
        if self.queue("DTM"):
            self.clock_step = "sync-read"
            self.clock_label.setText("Reading scanner clock before setting it…")

    def handle_clock_reply(self, body):
        if body == "OK":
            if self.clock_step == "sync-set":
                self.clock_step = "verify"
                self.queue("DTM")
            return
        # DTM,[DST],[YYYY],[MM],[DD],[hh],[mm],[ss],[RTC Status]
        parts = [p.strip() for p in body.split(",")]
        if len(parts) < 7 or not all(p.lstrip("-").isdigit() for p in parts[:7]):
            self.clock_label.setText(f"Scanner clock: the scanner replied DTM,{body}")
            self.clock_step = None
            return
        dst = parts[0]
        try:
            scanner_time = datetime(*(int(p) for p in parts[1:7]))
        except ValueError:
            self.clock_label.setText(f"Scanner clock: unreadable reply DTM,{body}")
            self.clock_step = None
            return
        rtc_ok = len(parts) < 8 or parts[7] == "1"
        if self.clock_step == "sync-read":
            now = datetime.now()
            self.queue(f"DTM,{dst},{now:%Y},{now:%m},{now:%d},{now:%H},{now:%M},{now:%S}")
            self.clock_step = "sync-set"
            self.clock_label.setText("Setting scanner clock…")
            return
        diff = (scanner_time - datetime.now()).total_seconds()
        text = (f"Scanner clock: {scanner_time:%Y-%m-%d %H:%M:%S} • "
                f"difference from PC: {diff:+.0f} s • daylight-saving setting: {dst}")
        if not rtc_ok:
            text += " • ⚠ scanner reports its clock is not valid (RTC NG)"
        if self.clock_step == "verify":
            if abs(abs(diff) - 3600) < 120:
                text += ("\n⚠ Exactly about one hour off after setting. The scanner may be "
                         "applying daylight saving on top of the time sent. Please report this.")
            elif abs(diff) <= 5:
                text = "✓ Scanner clock set. " + text
        self.clock_label.setText(text)
        self.clock_step = None

    # Quick Search Hold ------------------------------------------------------
    QSH_FORMATS = ("100hz", "mhz")

    @staticmethod
    def qsh_command(mhz, fmt):
        # The spec does not define QSH's frequency format. "100hz" is the
        # BCD536HP/436HP convention the SDS spec was derived from (8 digits in
        # 100 Hz units, 162.4 MHz -> 01624000); "mhz" matches GSI (162.400000).
        return "QSH," + (f"{round(mhz * 10000):08d}" if fmt == "100hz" else f"{mhz:.6f}")

    def tune_frequency(self, mhz=None):
        if mhz is None:
            try:
                mhz = self.validate_mhz(self.tune_entry.text())
            except ValueError as exc:
                QMessageBox.warning(self, "Tune to frequency", str(exc))
                return
        preferred = str(self.settings.value("qsh_format", "100hz"))
        if preferred not in self.QSH_FORMATS:
            preferred = "100hz"
        order = [preferred] + [f for f in self.QSH_FORMATS if f != preferred]
        self.pending_qsh = {"mhz": mhz, "formats": order[1:], "format": order[0]}
        if self.queue(self.qsh_command(mhz, order[0])):
            self.command_reply(f"QUEUED: Quick Search Hold on {mhz:.4f} MHz")

    def handle_qsh_reply(self, body):
        pending = self.pending_qsh
        if pending is None:
            return False
        if body == "OK":
            self.pending_qsh = None
            self.qsh_verify = {"mhz": pending["mhz"], "format": pending["format"],
                               "deadline": time.monotonic() + 4}
            self.command_reply(f"Quick Search Hold accepted: {pending['mhz']:.4f} MHz — checking…")
        elif pending["formats"]:
            fmt = pending["formats"].pop(0)
            pending["format"] = fmt
            self.queue(self.qsh_command(pending["mhz"], fmt))
            self.command_reply("Scanner rejected the first frequency format; trying the other one…")
        else:
            self.pending_qsh = None
            self.command_reply(f"Quick Search Hold rejected (QSH,{body}). The scanner does not "
                               "accept it in a menu, during Direct Entry or Quick Save.")
        return True

    def check_qsh(self, frequency):
        """Confirm from GSI that the scanner really went to the requested frequency."""
        verify = self.qsh_verify
        if verify is None:
            return
        reported = parse_mhz(frequency)
        if reported is not None and abs(reported - verify["mhz"]) < 0.0005:
            self.settings.setValue("qsh_format", verify["format"])
            self.command_reply(f"✓ Holding on {reported:.4f} MHz")
            self.qsh_verify = None
        elif time.monotonic() > verify["deadline"]:
            self.qsh_verify = None
            if reported is not None:
                other = [f for f in self.QSH_FORMATS if f != verify["format"]][0]
                self.settings.setValue("qsh_format", other)
                self.command_reply(
                    f"⚠ Scanner reports {reported:.4f} MHz, not {verify['mhz']:.4f} MHz. "
                    "Switched to the other frequency format; please try again.")
            else:
                self.command_reply("Quick Search Hold accepted, but the scanner's frequency "
                                   "could not be confirmed.")

    # Battery ---------------------------------------------------------------
    def poll_battery(self):
        if self.connected:
            self.queue("GCS")

    def handle_battery_reply(self, reply):
        match = self.GCS_PATTERN.search(reply)
        if not match:
            return
        cst, mv, pct, ma, temp = match.groups()
        pct = int(pct)
        state = self.CHARGE_STATES.get(cst, f"state {cst}")
        self.battery_label.setText(f"Battery {pct}% • {state}")
        self.battery_label.setToolTip(
            f"{int(mv) / 1000:.2f} V • {int(ma):+d} mA • {float(temp):.1f} °C")
        low = pct <= 15 and cst not in ("4", "5", "6")
        self.battery_label.setStyleSheet(
            "padding:0 8px;" + ("color:#ff7b7b;font-weight:700;" if low or cst in ("2", "3") else ""))
        if low and not self.low_battery_warned:
            self.low_battery_warned = True
            self.statusBar().showMessage(f"Scanner battery low: {pct}%", 30000)
        elif pct > 20:
            self.low_battery_warned = False

    def route_reply(self, reply):
        """Handle replies for the features above. Returns True to keep the
        reply out of the command status line (background battery polling)."""
        if self.scanner_tools is not None and self.scanner_tools.route(reply):
            return True
        if reply == "SENT: GCS":
            return True
        if reply.startswith("REPLY: GCS,"):
            self.handle_battery_reply(reply)
            return True
        if reply.startswith("REPLY: DTM,") and self.clock_step:
            # Shown in the clock section instead of the status line.
            self.handle_clock_reply(reply[len("REPLY: DTM,"):])
            return True
        if reply.startswith("REPLY: QSH,"):
            # Handled replies get their own explanatory message.
            return self.handle_qsh_reply(reply[len("REPLY: QSH,"):])
        if reply.startswith("REPLY: URC,ERR"):
            code = reply.rsplit(",", 1)[-1].strip()
            message = self.URC_ERRORS.get(code, f"error {code}")
            self.rec_state_label.setText(f"Recording not started: {message}")
        elif reply == "REPLY: URC,OK" and self.recording is None:
            self.rec_state_label.setText("Recording command accepted")
        return False

    def scanner_identity(self, reply):
        """Show the model and firmware replies to the MDL/VER sent on connect."""
        if reply.startswith("REPLY: MDL,"):
            model = reply[len("REPLY: MDL,"):].strip()
            self.scanner_model = model
            if model.upper().startswith("SDS200"):
                self.audio_sliders["VOL"].setMaximum(29)
                self.audio_sliders["SQL"].setMaximum(19)
            if model.upper().startswith("SDS100"):
                self.scanner_label.setText(f"Scanner: {model}")
            else:
                self.scanner_label.setText(f"Scanner: {model} (not an SDS100?)")
                self.statusBar().showMessage(
                    f"Connected device reports model '{model}'; this program is written for the SDS100.", 15000)
        elif reply.startswith("REPLY: VER,"):
            version = reply[len("REPLY: VER,"):].strip()
            self.scanner_label.setText(
                f"Scanner: {getattr(self, 'scanner_model', 'SDS100')} • firmware {version}")

    def command_reply(self, reply):
        if self.route_reply(reply):
            return
        if len(reply) > 160:
            reply = reply[:160] + "…"
        self.command_status.setText(reply)
        self.keypad_feedback.setText(reply)
        self.waterfall_feedback.setText(reply)
        if ",NG" in reply or ",ERR" in reply:
            self.command_status.setStyleSheet("color:#ff9e91;")
        elif ",OK" in reply:
            self.command_status.setStyleSheet("color:#7ee3a5;")
        else:
            self.command_status.setStyleSheet("color:#c9d6e6;")

    def control(self, action):
        if not self.thread or not self.thread.isRunning():
            return
        channel = getattr(self, "current_channel_index", None)
        kind = getattr(self, "current_channel_type", None)
        system = getattr(self, "current_system_index", None)
        dept = getattr(self, "current_dept_index", None)
        cmd = None
        if action == "scan":
            # Documented: 0xFFFFFFFF restarts scanning from the first channel.
            cmd = "JPM,SCN_MODE,4294967295"
        elif action == "system_hold" and system:
            cmd = f"HLD,SYS,{system},"
        elif action == "dept_hold" and dept:
            cmd = f"HLD,DEPT,{dept},"
        elif action == "channel_hold" and channel and kind:
            cmd = f"HLD,{kind},{channel},"
        elif action in ("previous", "next") and channel and kind:
            verb = "PRV" if action == "previous" else "NXT"
            cmd = f"{verb},{kind},{channel},,1"
        elif action == "avoid" and channel and kind:
            name = self.fields["Channel"].text()
            reply = QMessageBox.question(
                self, "Confirm temporary avoid",
                f"Temporarily avoid the currently displayed channel?\n\n{name}"
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
            cmd = f"AVD,{kind},{channel},,2"
            # The scanner moves off an avoided channel, so remember it for
            # REMOVE AVOID rather than targeting whatever is displayed next.
            self.last_avoided = (kind, channel, name)
            self.unavoid_btn.setText(f"REMOVE AVOID: {name}"[:40])
        elif action == "unavoid":
            if self.last_avoided:
                kind, channel, name = self.last_avoided
                question = f"Remove the avoid from the last avoided channel?\n\n{name}"
            elif channel and kind:
                name = self.fields["Channel"].text()
                question = ("No channel has been avoided this session.\n"
                            f"Remove any avoid from the currently displayed channel?\n\n{name}")
            else:
                kind = None
            if kind:
                reply = QMessageBox.question(self, "Confirm remove avoid", question)
                if reply != QMessageBox.StandardButton.Yes:
                    return
                cmd = f"AVD,{kind},{channel},,3"
                self.last_avoided = None
                self.unavoid_btn.setText("REMOVE AVOID")
        if not cmd:
            self.command_reply("No compatible channel/system index available.")
            return
        self.thread.send_command(cmd)
        self.command_reply("QUEUED: " + cmd)

    # ---- Waterfall ------------------------------------------------------
    # Key sequences from the SDS100/SDS200 Waterfall manual. Key codes are from
    # Remote Command Specification V2.00: A/B/C are Soft Keys 1/2/3.
    WATERFALL_ACTIONS = {
        "exit": (("A",), "To Scan: exit waterfall and resume scanning (Soft Key 1)"),
        "span": (("B",), "Change span (Soft Key 2)"),
        "hold": (("C",), "Hold / Sweep: freeze or resume the display (Soft Key 3)"),
        "step": (("F", "A"), "Change step size (FUNC + Soft Key 1)"),
        "maxhold": (("F", "B"), "Max Hold on/off (FUNC + Soft Key 2)"),
        "center": (("F", "C"), "Move marker to center frequency, MF→CF (FUNC + Soft Key 3)"),
        "tune_down": (("<",), "Marker down one step (knob left)"),
        "tune_up": ((">",), "Marker up one step (knob right)"),
        "fast_down": (("F", "<"), "Marker down fast (FUNC + knob left)"),
        "fast_up": (("F", ">"), "Marker up fast (FUNC + knob right)"),
        "display": (("F", "9"), "Open FFT / waterfall split setting (FUNC + 9)"),
        "gain": (("F", "0"), "Open RF gain setting (FUNC + 0)"),
        "confirm": (("E",), "E / YES: confirm a setting (on the waterfall screen, E quick-saves the frequency)"),
    }
    # SDS100 receive coverage in MHz (from the SDS100 specifications).
    SDS100_BANDS = ((25, 512), (758, 824), (849, 869), (894, 960), (1240, 1300))

    def build_waterfall_window(self):
        """The waterfall is a separate, maximizable window (View → Waterfall…).

        Graph on the left, which takes all extra space when the window is
        enlarged; controls on the right in a scrollable column.
        """
        window = WaterfallWindow(self)
        window.setObjectName("waterfallWindow")
        window.setWindowTitle(f"SDS100 Waterfall — SDS100 Monitor v{VERSION}")
        icon_file = Path(__file__).with_name("sds100-monitor.svg")
        if icon_file.exists():
            window.setWindowIcon(QIcon(str(icon_file)))
        window.resize(1250, 760)
        outer = QHBoxLayout(window)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        graph_side_widget = QWidget()
        graph_side = QVBoxLayout(graph_side_widget)
        graph_side.setContentsMargins(0, 0, 0, 0)
        controls_scroll = QScrollArea()
        controls_scroll.setWidgetResizable(True)
        controls_scroll.setMinimumWidth(430)
        controls = QWidget()
        controls_scroll.setWidget(controls)
        splitter.addWidget(graph_side_widget)
        splitter.addWidget(controls_scroll)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 0)
        splitter.setSizes([800, 450])
        outer.addWidget(splitter)
        self.waterfall_window = window
        self.waterfall_splitter = splitter
        self.build_waterfall_panel(QVBoxLayout(controls), graph_side)
        # Re-evaluate graph polling when the window is shown or hidden, so the
        # scanner is only asked for graph data while the graph is visible.
        window.visibility_changed.connect(lambda _visible: self.update_graph_polling())

    def open_waterfall_window(self):
        window = self.waterfall_window
        if not window.isVisible():
            if not getattr(self, "waterfall_geometry_restored", False):
                self.waterfall_geometry_restored = True
                geometry = self.settings.value("waterfall/geometry")
                if geometry:
                    window.restoreGeometry(geometry)
                splitter_state = self.settings.value("waterfall/splitter")
                if splitter_state:
                    self.waterfall_splitter.restoreState(splitter_state)
            window.show()
        window.raise_()
        window.activateWindow()

    def build_waterfall_panel(self, layout, graph_side):
        self.waterfall_active = False
        self.connected = False
        self.waterfall_gated = []     # buttons that need waterfall mode
        self.waterfall_entry = []     # buttons that need only a connection
        heading = QLabel("WATERFALL CONTROL")
        heading.setStyleSheet("font-size:20px;font-weight:700;color:#8bd6f2;")
        layout.addWidget(heading)
        note = QLabel("Controls send the same key presses as the scanner's waterfall screen. "
                      "Most are enabled only while the scanner reports waterfall mode, "
                      "because the same keys do other things (such as holds) in scan mode.")
        note.setWordWrap(True)
        layout.addWidget(note)
        self.waterfall_mode_label = QLabel("Waterfall mode: not detected")
        self.waterfall_mode_label.setStyleSheet("font-weight:700;color:#e6a65a;padding:4px;")
        graph_side.addWidget(self.waterfall_mode_label)

        graph_box = QGroupBox("LIVE WATERFALL")
        graph_layout = QVBoxLayout(graph_box)
        self.waterfall_graph = WaterfallGraph()
        self.waterfall_graph.tune_requested.connect(self.tune_waterfall)
        graph_layout.addWidget(self.waterfall_graph, 1)
        graph_row = QHBoxLayout()
        self.waterfall_graph_on = QCheckBox("Show live graph")
        self.waterfall_graph_on.setChecked(
            str(self.settings.value("waterfall/graph_on", "true")).lower() == "true")
        self.waterfall_graph_on.setToolTip(
            "Requests the scanner's graph data (GWF) while waterfall mode is active")
        self.waterfall_graph_on.toggled.connect(self.update_graph_polling)
        graph_row.addWidget(self.waterfall_graph_on)
        graph_row.addWidget(QLabel("Update rate:"))
        self.waterfall_graph_rate = QComboBox()
        for label, ms in (("4 per second", 250), ("2 per second", 500), ("1 per second", 1000)):
            self.waterfall_graph_rate.addItem(label, ms)
        saved_rate = self.waterfall_graph_rate.findData(
            int(self.settings.value("waterfall/graph_ms", 250)))
        self.waterfall_graph_rate.setCurrentIndex(max(0, saved_rate))
        self.waterfall_graph_rate.currentIndexChanged.connect(self.update_graph_polling)
        graph_row.addWidget(self.waterfall_graph_rate)
        graph_row.addStretch(1)
        graph_hint = QLabel("Hover for frequency • double-click to tune")
        graph_hint.setStyleSheet("color:#a5bdd2;")
        graph_row.addWidget(graph_hint)
        graph_layout.addLayout(graph_row)
        graph_side.addWidget(graph_box, 1)

        status = QGroupBox("WATERFALL STATUS (from scanner)")
        status_grid = QGridLayout(status)
        self.wf_fields = {}
        for row, key in enumerate(("Center", "Span", "Range", "Step",
                                   "Modulation", "Marker", "Gain")):
            status_grid.addWidget(QLabel(key.upper()), row, 0)
            value = QLabel("—")
            value.setStyleSheet("font-size:16px;font-weight:650;")
            value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            status_grid.addWidget(value, row, 1)
            self.wf_fields[key] = value
        status_grid.setColumnStretch(1, 1)
        layout.addWidget(status)

        def make(label, tooltip, slot, gated=True, color="#344d71"):
            b = QPushButton(label)
            b.setToolTip(tooltip)
            b.setMinimumHeight(38)
            b.setStyleSheet(
                f"QPushButton {{background:{color}; color:white; font-weight:700;"
                " border-radius:6px; padding:8px;}}"
                "QPushButton:hover {border:2px solid #dceeff;}"
                "QPushButton:disabled {background:#414750;color:#9ca4b0;}")
            b.clicked.connect(slot)
            b.setEnabled(False)
            (self.waterfall_gated if gated else self.waterfall_entry).append(b)
            return b

        def action(name, label, color="#344d71"):
            codes, desc = self.WATERFALL_ACTIONS[name]
            return make(label, desc, lambda checked=False: self.waterfall_action(name), True, color)

        enter = QGroupBox("START WATERFALL")
        enter_grid = QGridLayout(enter)
        enter_grid.addWidget(make(
            "START WATERFALL (JPM)",
            "Sends JPM,WF_MODE,0. The spec lists WF_MODE but marks its index "
            "'Reserve', so this is untested. The reply (OK or NG) appears below.",
            self.enter_waterfall_jpm, gated=False, color="#1b8a5a"), 0, 0, 1, 3)
        enter_grid.addWidget(QLabel("Or via search key:"), 1, 0)
        self.waterfall_search_key = QComboBox()
        self.waterfall_search_key.addItems(["SRCH 1", "SRCH 2", "SRCH 3"])
        self.waterfall_search_key.setToolTip(
            "Documented method: assign Waterfall to a search key on the scanner "
            "(Menu → Search for → Set Search Key → Search Key n → Waterfall).")
        enter_grid.addWidget(self.waterfall_search_key, 1, 1)
        enter_grid.addWidget(make(
            "START (FUNC + key)",
            "Sends FUNC then 1, 2 or 3. Works when that search key is set to Waterfall "
            "and the scanner is on a channel.",
            self.enter_waterfall_search_key, gated=False, color="#1b8a5a"), 1, 2)
        layout.addWidget(enter)

        display = QGroupBox("DISPLAY")
        display_grid = QGridLayout(display)
        display_grid.addWidget(action("span", "SPAN"), 0, 0)
        display_grid.addWidget(action("step", "STEP"), 0, 1)
        display_grid.addWidget(action("hold", "HOLD / SWEEP", "#a87d15"), 0, 2)
        display_grid.addWidget(action("maxhold", "MAX HOLD"), 1, 0)
        display_grid.addWidget(action("display", "FFT / WF SPLIT…"), 1, 1)
        display_grid.addWidget(action("gain", "RF GAIN…"), 1, 2)
        display_grid.addWidget(action("exit", "EXIT TO SCAN", "#bd6b23"), 2, 0, 1, 3)
        hint = QLabel("FFT / WF SPLIT and RF GAIN open a setting on the scanner: "
                      "choose with the ◀ / ▶ marker buttons, then press CONFIRM (E).")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#a5bdd2;")
        display_grid.addWidget(hint, 3, 0, 1, 3)
        layout.addWidget(display)

        marker = QGroupBox("MARKER / TUNING")
        marker_grid = QGridLayout(marker)
        marker_grid.addWidget(action("fast_down", "◀◀ FAST"), 0, 0)
        marker_grid.addWidget(action("tune_down", "◀ STEP"), 0, 1)
        marker_grid.addWidget(action("tune_up", "STEP ▶"), 0, 2)
        marker_grid.addWidget(action("fast_up", "FAST ▶▶"), 0, 3)
        marker_grid.addWidget(action("center", "MARKER TO CENTER (MF→CF)"), 1, 0, 1, 2)
        marker_grid.addWidget(action("confirm", "CONFIRM (E)", "#1b8a5a"), 1, 2, 1, 2)
        marker_grid.addWidget(QLabel("Marker frequency (MHz):"), 2, 0, 1, 2)
        self.waterfall_freq = QLineEdit()
        self.waterfall_freq.setPlaceholderText("e.g. 154.4300")
        self.waterfall_freq.returnPressed.connect(self.set_waterfall_marker)
        marker_grid.addWidget(self.waterfall_freq, 2, 2)
        marker_grid.addWidget(make(
            "SET", "Types the frequency on the keypad and presses E, which moves the marker.",
            self.set_waterfall_marker), 2, 3)
        layout.addWidget(marker)

        self.waterfall_override = QCheckBox(
            "Allow waterfall keys even when waterfall mode isn't detected")
        self.waterfall_override.setToolTip(
            "Detection relies on the scanner's status report. If the controls stay "
            "disabled while the waterfall is on screen, tick this. In scan mode these "
            "keys act as System / Department / Channel hold.")
        self.waterfall_override.toggled.connect(self.update_waterfall_controls)
        layout.addWidget(self.waterfall_override)
        self.waterfall_feedback = QLabel("Connect to enable waterfall controls.")
        self.waterfall_feedback.setWordWrap(True)
        layout.addWidget(self.waterfall_feedback)
        layout.addStretch(1)

    def update_waterfall_controls(self, *_):
        for b in self.waterfall_entry:
            b.setEnabled(self.connected)
        allowed = self.connected and (self.waterfall_active or self.waterfall_override.isChecked())
        for b in self.waterfall_gated:
            b.setEnabled(allowed)
        self.waterfall_freq.setEnabled(allowed)

    def update_waterfall_status(self, root):
        """Read waterfall details from GSI (elements per spec V2.00)."""
        band = root.find("WaterfallBand")
        settings = root.find("WaterfallSettings")
        mode_text = (root.attrib.get("Mode", "") + " " + root.attrib.get("V_Screen", "")).lower()
        active = band is not None or "waterfall" in mode_text
        lower, upper = self.attr(band, "Lower"), self.attr(band, "Upper")
        values = {
            "Center": self.attr(band, "Center"),
            "Span": self.attr(band, "Span"),
            "Range": f"{lower} – {upper}" if band is not None else "—",
            "Step": self.attr(band, "Step"),
            "Modulation": self.attr(band, "Mod"),
            "Marker": self.attr(settings, "MF"),
            "Gain": self.attr(settings, "Gain"),
        }
        for key, value in values.items():
            self.wf_fields[key].setText(value or "—")
        if active and band is not None:
            self.waterfall_graph.set_band(parse_mhz(lower), parse_mhz(upper),
                                          parse_mhz(self.attr(settings, "MF")),
                                          parse_step_mhz(self.attr(band, "Step")))
        else:
            self.waterfall_graph.set_band(None, None, None, None)
        if active != self.waterfall_active:
            self.waterfall_active = active
            if active:
                self.waterfall_mode_label.setText("Waterfall mode: ACTIVE")
                self.waterfall_mode_label.setStyleSheet("font-weight:700;color:#52dc95;padding:4px;")
            else:
                self.waterfall_mode_label.setText("Waterfall mode: not detected")
                self.waterfall_mode_label.setStyleSheet("font-weight:700;color:#e6a65a;padding:4px;")
            self.update_waterfall_controls()
            self.update_graph_polling()

    def update_graph_polling(self, *_):
        """Poll GWF only while connected, in waterfall mode, with the graph on."""
        self.settings.setValue("waterfall/graph_on", self.waterfall_graph_on.isChecked())
        self.settings.setValue("waterfall/graph_ms", self.waterfall_graph_rate.currentData())
        wanted = bool(self.connected and self.waterfall_active
                      and self.waterfall_graph_on.isChecked()
                      and self.waterfall_window.isVisible())
        if self.thread and self.thread.isRunning():
            self.thread.graph_ms = self.waterfall_graph_rate.currentData()
            self.thread.graph_enabled = wanted
        if not self.waterfall_graph_on.isChecked() and self.waterfall_active:
            self.waterfall_graph.clear("Live graph is off")

    def tune_waterfall(self, mhz):
        """Double-click on the graph: type the frequency and press E."""
        if not self.waterfall_freq.isEnabled():
            return
        try:
            codes = self.waterfall_keys_for(f"{mhz:.4f}")
        except ValueError as exc:
            self.command_reply(str(exc))
            return
        self.waterfall_freq.setText(f"{mhz:.4f}")
        self.send_key_sequence(codes, "Waterfall marker → " + "".join(codes[:-1]) + " MHz")

    def waterfall_action(self, name):
        codes, desc = self.WATERFALL_ACTIONS[name]
        self.send_key_sequence(codes, f"Waterfall: {desc}")

    def enter_waterfall_jpm(self):
        if not self.thread or not self.thread.isRunning():
            return
        self.thread.send_command("JPM,WF_MODE,0")
        self.command_reply("QUEUED: JPM,WF_MODE,0 (untested; watch for OK or NG)")

    def enter_waterfall_search_key(self):
        key = str(self.waterfall_search_key.currentIndex() + 1)
        self.send_key_sequence(("F", key), f"Start waterfall via FUNC + SRCH {key}")

    @classmethod
    def validate_mhz(cls, text):
        """Return a frequency in MHz within SDS100 coverage, or raise ValueError."""
        text = str(text).strip().lower().removesuffix("mhz").strip()
        if not text or text.count(".") > 1 or not all(c.isdigit() or c == "." for c in text):
            raise ValueError("Enter a frequency in MHz, for example 154.4300.")
        mhz = float(text)
        if not any(low <= mhz <= high for low, high in cls.SDS100_BANDS):
            bands = ", ".join(f"{a}–{b}" for a, b in cls.SDS100_BANDS)
            raise ValueError(f"{mhz:g} MHz is outside SDS100 coverage ({bands} MHz).")
        return mhz

    @classmethod
    def waterfall_keys_for(cls, text):
        """Return keypad codes for a marker frequency, or raise ValueError."""
        mhz = cls.validate_mhz(text)
        digits = f"{mhz:.4f}".rstrip("0").rstrip(".")
        return tuple(digits) + ("E",)

    def set_waterfall_marker(self):
        try:
            codes = self.waterfall_keys_for(self.waterfall_freq.text())
        except ValueError as exc:
            QMessageBox.warning(self, "Marker frequency", str(exc))
            return
        if not self.waterfall_freq.isEnabled():
            return
        self.send_key_sequence(codes, "Waterfall marker → " + "".join(codes[:-1]) + " MHz")

    def build_keypad(self, layout):
        heading = QLabel("SDS100 KEYPAD • REMOTE KEY PRESSES")
        heading.setStyleSheet("font-size:20px;font-weight:700;color:#8bd6f2;")
        layout.addWidget(heading)
        help_label = QLabel(
            "Use the keypad as you would the scanner buttons. "
            "The ◀ / ▶ controls rotate the scanner knob; the center "
            "button presses it. Keypad operations can change scanner settings.")
        help_label.setWordWrap(True)
        layout.addWidget(help_label)
        dial_box = QGroupBox("ROTARY KNOB")
        dial_row = QHBoxLayout(dial_box)
        dial_row.addStretch(1)
        self.dial = RotaryDial()
        self.dial.activated.connect(self.send_key)
        self.dial.setEnabled(False)
        dial_row.addWidget(self.dial, 1)
        dial_row.addStretch(1)
        layout.addWidget(dial_box, 1)
        panel = QGroupBox("KEYPAD")
        grid = QGridLayout(panel)
        self.keypad_buttons = []

        def button(label, code, row, col, color="#344d71", span=1):
            b = QPushButton(label)
            b.setMinimumHeight(40)
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            b.setStyleSheet(
                f"QPushButton {{background:{color}; color:white;"
                "font-size:17px;font-weight:700;border-radius:8px;padding:8px;}"
                "QPushButton:hover {border:2px solid #dceeff;}"
                "QPushButton:disabled {background:#414750;color:#9ca4b0;}")
            b.clicked.connect(lambda checked=False, k=code: self.send_key(k))
            b.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            b.customContextMenuRequested.connect(
                lambda point, widget=b, k=code, name=label:
                    self.show_keypad_context_menu(widget, point, k, name))
            b.setEnabled(False)
            grid.addWidget(b, row, col, 1, span)
            self.keypad_buttons.append(b)

        button("SYSTEM", "A", 0, 0, "#2167b1")
        button("DEPT", "B", 0, 1, "#2167b1")
        button("CHANNEL", "C", 0, 2, "#2167b1")
        button("MENU", "M", 1, 0, "#7654a6")
        button("FUNC", "F", 1, 1, "#7654a6")
        button("AVOID", "L", 1, 2, "#bd6b23")
        button("◀ KNOB", "<", 2, 0, "#536779")
        button("PUSH KNOB", "^", 2, 1, "#536779")
        button("KNOB ▶", ">", 2, 2, "#536779")
        for row, keys in enumerate((("1","2","3"), ("4","5","6"),
                                    ("7","8","9")), start=3):
            for col, key in enumerate(keys):
                button(key, key, row, col)
        button("./NO", ".", 6, 0, "#536779")
        button("0", "0", 6, 1)
        button("E/YES", "E", 6, 2, "#1b8a5a")
        button("REPLAY", "Y", 7, 0, "#536779")
        button("BACKLIGHT", "V", 7, 1, "#536779")
        button("RANGE", "R", 7, 2, "#536779")
        for column in range(3):
            grid.setColumnStretch(column, 1)
        for row in range(8):
            grid.setRowStretch(row, 1)
        layout.addWidget(panel, 3)
        self.keypad_feedback = QLabel("Connect to enable keypad.")
        self.keypad_feedback.setWordWrap(True)
        layout.addWidget(self.keypad_feedback)
    def show_keypad_context_menu(self, widget, point, code, label):
        """Contextual SDS100 key reference, with only verified remote actions enabled."""
        menu = QMenu(widget)
        connected = bool(self.thread and self.thread.isRunning())
        names = {
            "A": "System hold / release (Scan Mode)",
            "B": "Department hold / release (Scan Mode)",
            "C": "Channel hold / release",
            "M": "Open / back out of scanner menu",
            "F": "Activate Function mode",
            "L": "Avoid current channel / exit menu",
            "Y": "Replay recent transmissions",
            "V": "Backlight / volume control",
            "R": "Range key",
            "^": "Press rotary knob / select",
            "<": "Rotate knob left", ">": "Rotate knob right",
            ".": "Decimal point / No / cancel", "E": "Enter / Yes / store",
            "1": "Number 1 / Favorites List quick key",
            "2": "Number 2 / Favorites List quick key",
            "3": "Number 3 / Favorites List quick key",
            "4": "Number 4 / Favorites List quick key",
            "5": "Number 5 / Favorites List quick key",
            "6": "Number 6 / Favorites List quick key",
            "7": "Number 7 / Favorites List quick key",
            "8": "Number 8 / Favorites List quick key",
            "9": "Number 9 / Favorites List quick key",
            "0": "Number 0 / Favorites List quick key",
        }
        func_names = {
            "A": "System controls (scanner-mode dependent)",
            "B": "Hold / release site (Scan Mode)",
            "C": "Toggle modulation (Hold Mode)",
            "M": "Open current mode options (Search / Close Call / Weather / Waterfall / Tone-Out)",
            "L": "Review scan/search avoids (Hold Mode)",
            "Y": "Start / stop recording (FUNC + REPLAY)",
            "V": "Squelch control (physical knob)",
            "1": "Activate Search Key 1 (Scan Hold)",
            "2": "Activate Search Key 2 (Scan Hold)",
            "3": "Activate Search Key 3 (Scan Hold)",
            "4": "Toggle attenuation (Receive/Hold)",
            "5": "Open dimmer settings (Hold Mode)",
            "6": "Toggle Weather Alert Priority (Hold Mode)",
            "7": "Toggle IF Exchange (Hold Mode)",
            "8": "Repeater view: use FUNC + long press below (Hold Mode)",
            "9": "Toggle Simple / Detailed display (Hold Mode)",
            "0": "Toggle channel volume offset (Scan Hold)",
            ".": "Cycle priority scan modes",
            "E": "Toggle ID Search (Scan) / Quick Search (Hold)",
        }
        long_names = {
            "4": "Toggle Global Attenuation (FUNC + hold 4)",
            "6": "Enter Weather Scan (FUNC + hold 6)",
            "8": "Show repeater frequency (FUNC + hold 8)",
            "9": "Cycle color / B&W / white-on-black (FUNC + hold 9)",
            "L": "Avoid clearing action (user-tested FUNC + long AVOID; scope varies)",
            "Y": "Recording review / replay action (user-tested FUNC + long REPLAY)",
        }
        press = menu.addAction("Press — " + names.get(code, label))
        press.setEnabled(connected)
        press.triggered.connect(lambda checked=False, k=code: self.send_key(k))
        if code in func_names:
            action = menu.addAction("FUNC + press — " + func_names[code])
            # 8 is only documented as FUNC + long press, not a short-press action.
            action.setEnabled(connected and code != "8")
            if code != "8":
                action.triggered.connect(
                    lambda checked=False, k=code, desc=func_names[code]:
                    self.send_key_sequence(("F", k), desc))
        if code in long_names:
            menu.addSeparator()
            long_action = menu.addAction("FUNC + LONG PRESS — " + long_names[code])
            if code == "6":
                long_action.setEnabled(connected)
                long_action.setToolTip("Implemented with documented JPM,WX_MODE,NORMAL command")
                long_action.triggered.connect(self.enter_weather_scan)
            elif code in ("4", "8", "9", "L", "Y"):
                long_action.setEnabled(connected)
                long_action.setToolTip("User-verified: momentary FUNC, followed by KEY,<key>,L")
                long_action.triggered.connect(
                    lambda checked=False, k=code, desc=long_names[code]:
                    self.send_function_long_press(k, desc))
            else:
                long_action.setEnabled(False)
                long_action.setToolTip("Long-press remote behavior not verified")
        menu.addSeparator()
        mode_note = menu.addAction("ⓘ Function actions depend on scanner mode / Hold state")
        mode_note.setEnabled(False)
        diagnostic = menu.addAction("Keypress Protocol Diagnostic…")
        diagnostic.triggered.connect(self.open_keypad_diagnostic)
        reference = menu.addAction("Keypad command reference…")
        reference.triggered.connect(self.show_keypad_reference)
        menu.exec(widget.mapToGlobal(point))

    def open_keypad_diagnostic(self):
        if not self.thread or not self.thread.isRunning():
            QMessageBox.information(self, "Scanner disconnected", "Connect the SDS100 to open the keypress diagnostic.")
            return
        self.key_diagnostic = KeyProtocolDiagnostic(self)
        self.key_diagnostic.show()

    def send_key_sequence(self, codes, description):
        if not self.thread or not self.thread.isRunning():
            self.command_reply("Scanner disconnected — no keys sent.")
            return
        for code in codes:
            self.thread.send_command(f"KEY,{code},P")
        self.command_reply("QUEUED: " + description)

    def send_function_long_press(self, code, description):
        """Queue the two user-tested commands in order on the scanner I/O thread.

        The worker's FIFO queue serializes these commands; no H/R modes are used.
        The device still determines the active FUNC state and action.
        """
        if not self.thread or not self.thread.isRunning():
            self.command_reply("Scanner disconnected — no keys sent.")
            return
        self.thread.send_command("KEY,F,P")
        self.thread.send_command(f"KEY,{code},L")
        self.command_reply(f"QUEUED: {description} (KEY,F,P → KEY,{code},L)")

    def enter_weather_scan(self):
        if not self.thread or not self.thread.isRunning():
            self.command_reply("Scanner disconnected — no command sent.")
            return
        # Spec v1.02 page 8 documents JPM,WX_MODE,NORMAL.
        # This avoids guessing KEY_MODE for a held-down key.
        self.thread.send_command("JPM,WX_MODE,NORMAL")
        self.command_reply("QUEUED: Weather Scan (JPM,WX_MODE,NORMAL)")

    def show_keypad_reference(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("SDS100 Keypad Function Reference")
        dialog.resize(720, 480)
        layout = QVBoxLayout(dialog)
        text = QTextEdit()
        text.setReadOnly(True)
        text.setPlainText(
            f"SDS100 virtual keypad • v{VERSION}\n\n"
            "Right-click a key for its context-specific physical-key functions. "
            "Most FUNC functions require Scan Hold or Channel Hold mode.\n\n"
            "FUNC + 1/2/3: Search keys (Scan Hold)\n"
            "FUNC + 4: Channel/search attenuation (Receive/Hold)\n"
            "FUNC + hold 4: Global attenuation — verified remote sequence\n"
            "FUNC + 5: Dimmers (Hold)\n"
            "FUNC + 6: Weather Alert Priority (Hold)\n"
            "FUNC + hold 6: Weather Scan — virtual menu uses JPM,WX_MODE,NORMAL\n"
            "FUNC + 7: IF Exchange (Hold)\n"
            "FUNC + hold 8: Repeater frequency — verified remote sequence\n"
            "FUNC + 9: Simple/Detailed display (Hold)\n"
            "FUNC + hold 9: Color/B&W/WB display — verified remote sequence\n"
            "FUNC + 0: Channel volume offset (Scan Hold)\n"
            "FUNC + ./NO: Priority modes\n"
            "FUNC + E/YES: ID Search (Scan) / Quick Search (Hold)\n"
            "FUNC + REPLAY: Start/stop recording\n"
            "FUNC + hold REPLAY: Recording/replay action — user-tested remote sequence; observe scanner state\n"
            "FUNC + hold AVOID: Avoid-clearing action — user-tested remote sequence; affects scanner state\n"
            "Physical manual also documents hold AVOID (without FUNC) to clear avoids; not yet enabled.\n\n"
            "User-tested long-press actions send KEY,F,P followed by KEY,<key>,L. "
            "The supplied remote spec does not document L; behavior was user-tested on an SDS100. "
            "Weather Scan continues to use JPM,WX_MODE,NORMAL.\n\n"
            "Sources: Easier to Read SDS100/200 Manual, Key Operations (pp. 7–8); "
            "SDS100/200 Remote Command Specification v1.02, KEY and JPM.")
        layout.addWidget(text)
        close = QPushButton("Close")
        close.clicked.connect(dialog.accept)
        layout.addWidget(close)
        dialog.exec()

    def send_key(self, code):
        if not self.thread or not self.thread.isRunning():
            return
        # P = momentary press; key codes are SDS100 documented codes.
        command = f"KEY,{code},P"
        self.thread.send_command(command)
        self.command_reply("QUEUED: " + command)

    def change_poll_interval(self, value):
        # Applies immediately to a running connection; a plain int assignment
        # is read by the worker on its next loop.
        if self.thread and self.thread.isRunning():
            self.thread.poll_ms = value
            self.active_poll_ms = value

    def toggle(self):
        if self.thread and self.thread.isRunning():
            self.release_diagnostic_key()
            self.thread.stop()
            return
        # Statistics are not reset here: they are built from the saved
        # history at startup and keep accumulating across connections.
        self.event = None
        self.last_seen = None
        self.active_poll_ms = self.interval.value()
        self.thread = ScannerThread(self.port.currentText().strip(),
                                    int(self.baud.currentText()),
                                    self.interval.value())
        self.thread.xml_received.connect(self.process_xml)
        self.thread.message.connect(self.connection_message)
        self.thread.command_result.connect(self.command_reply)
        self.thread.command_result.connect(self.scanner_identity)
        self.thread.command_result.connect(self.scanner_output)
        self.thread.graph_received.connect(self.waterfall_graph.add_frame)
        self.thread.list_received.connect(self.handle_list_xml)
        self.thread.finished.connect(lambda: self.connect_btn.setText("CONNECT"))
        self.thread.start()
        self.connect_btn.setText("DISCONNECT")
        self.save_settings()

    def connection_message(self, message):
        if message == "DISCONNECTED":
            self.dial.setEnabled(False)
            for btn in self.control_buttons + self.keypad_buttons:
                btn.setEnabled(False)
            self.finish_event()
            self.connect_btn.setText("CONNECT")
            self.scanner_label.setText("Scanner: not connected")
            self.connected = False
            self.set_settings_enabled(False)
            self.update_waterfall_status(ET.Element("ScannerInfo"))
            self.update_waterfall_controls()
        elif message == "CONNECTED":
            self.dial.setEnabled(True)
            for btn in self.control_buttons + self.keypad_buttons:
                btn.setEnabled(True)
            self.connected = True
            self.set_settings_enabled(True)
            self.update_waterfall_controls()
        elif message.startswith("ERROR:"):
            QMessageBox.warning(self, "Serial error", message)
        self.status.setText(message)
        self.status.setStyleSheet(
            "color:#52dc95;" if message == "CONNECTED" else "color:#ed8b8b;"
        )

    @staticmethod
    def attr(node, key, default="—"):
        return node.attrib.get(key, default).strip() if node is not None else default

    def process_xml(self, xml):
        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            return
        system = root.find("System")
        department = root.find("Department")
        self.current_system_index = self.valid_index(system)
        self.current_dept_index = self.valid_index(department)
        # SrchFrequency is reported in Custom/Quick Search and Close Call modes
        # (verified from SDS100 GSI samples, 2026-10-26).
        channel = next((node for tag in ("ConvFrequency", "TGID", "TrunkingChannel",
                                         "SrchFrequency")
                        if (node := root.find(tag)) is not None), None)
        prop = root.find("Property")
        self.current_channel_index = self.valid_index(channel)
        self.current_channel_type = (
            "CFREQ" if channel is not None and channel.tag == "ConvFrequency"
            else "TGID" if channel is not None and channel.tag == "TGID"
            else None
        )
        mode = root.attrib.get("Mode", "—")
        frequency = self.attr(channel, "Freq")
        if frequency in ("—", ""):
            # Trunked calls carry no Freq on the TGID element; the voice
            # frequency in use is reported separately in SiteFrequency.
            frequency = self.attr(root.find("SiteFrequency"), "Freq")
        if frequency == "":
            frequency = "—"
        if channel is not None and channel.tag == "SrchFrequency":
            # Search and Close Call hits have no system, department or channel
            # name. Log the mode as the system, the search bank (if any) as the
            # department, and the frequency as the channel, so statistics group
            # search hits by frequency.
            info = {
                "System": mode,
                "Department": self.attr(root.find("SearchBanks"), "Name"),
                "Channel": frequency,
                "Frequency": frequency,
                "Talkgroup": self.attr(channel, "TGID"),
                "Mode": mode,
                "RSSI": self.attr(prop, "Rssi"),
            }
        else:
            info = {
                "System": self.attr(system, "Name"),
                "Department": self.attr(department, "Name"),
                "Channel": self.attr(channel, "Name"),
                "Frequency": frequency,
                "Talkgroup": self.attr(channel, "TGID"),
                "Mode": mode,
                "RSSI": self.attr(prop, "Rssi"),
            }
        if info["Talkgroup"] in ("TGID None", "None", ""):
            info["Talkgroup"] = "—"
        for name in ("System", "Department", "Channel"):
            if not info[name]:
                info[name] = "—"
        # Display-only fields (not part of the reception key or the CSV).
        site = self.attr(root.find("Site"), "Name") or "—"
        unit = root.find("UnitID")
        unit_name = self.attr(unit, "Name")
        unit_id = self.attr(unit, "U_Id")
        if unit is None and channel is not None:
            unit_id = self.attr(channel, "U_Id")   # SrchFrequency reports U_Id
            unit_name = unit_id
        if unit_id in ("UID None", "None", "", "—"):
            unit_text = "—"
        elif unit_name and unit_name not in ("—", unit_id):
            # A unit ID with a stored name (alias) shows both.
            unit_text = f"{unit_name} ({unit_id})"
        else:
            unit_text = unit_id
        display = dict(info, **{"Site": site, "Unit ID": unit_text})
        for key, value in display.items():
            self.fields[key].setText(value)
        self.update_waterfall_status(root)
        self.sync_audio(prop)
        self.sync_recording(prop)
        self.check_qsh(info["Frequency"])

        try:
            rssi = int(info["RSSI"])
            if rssi == -999:
                raise ValueError
            # Approximate visual range; not a calibrated S-meter.
            strength = max(0, min(100, round((rssi + 120) / 70 * 100)))
            self.signal.setValue(strength)
            self.signal.setFormat(f"RSSI: {rssi} dBm (approximate bar)")
        except ValueError:
            self.signal.setValue(0)
            self.signal.setFormat("Signal strength: unavailable")

        mute = self.attr(prop, "Mute").lower()
        receiving = mute == "unmute" and info["Channel"] != "—"
        now = datetime.now()
        key = tuple(info[k] for k in ("System", "Department", "Channel",
                                      "Frequency", "Talkgroup"))
        if receiving:
            self.status.setText("● RECEIVING")
            self.status.setStyleSheet("color:#52dc95; font-size:22px; font-weight:bold;")
            if self.event is None or self.event["key"] != key:
                self.finish_event()
                self.event = {"key": key, "start": now, "last": now,
                              "info": info.copy()}
                self.event_alerted = self.check_alerts(display)
            else:
                self.event["last"] = now
            if unit_text != "—" and (key, unit_id) != self.last_unit_key:
                # A new radio keyed up: log it, and check unit ID alerts (P25
                # often reports the unit a moment after the call starts). At
                # most one alert is raised per reception.
                if not self.event_alerted:
                    self.event_alerted = self.check_alerts(display, unit_only=True)
                self.last_unit_key = (key, unit_id)
                self.log_unit(display, unit_id, unit_name)
        else:
            self.last_unit_key = None
            self.finish_event()
            self.status.setText("SCANNING")
            self.status.setStyleSheet("color:#e6a65a; font-size:22px; font-weight:bold;")

    def finish_event(self):
        if self.event is None:
            return
        event = self.event
        self.event = None
        # Duration is approximate because GSI is polled rather than
        # event-driven. The transmission ended somewhere between the last poll
        # that saw it and the next poll, so the end is estimated as one polling
        # interval after the last sighting. This is the same whether the event
        # ended normally, changed channel, or was cut off by a disconnect.
        end = event["last"] + timedelta(milliseconds=self.active_poll_ms)
        duration = max(0.0, (end - event["start"]).total_seconds())
        info = event["info"]
        row = [
            event["start"].strftime("%Y-%m-%d %H:%M:%S"),
            end.strftime("%Y-%m-%d %H:%M:%S"),
            f"{duration:.1f}",
            info["System"], info["Department"], info["Channel"],
            info["Frequency"], info["Talkgroup"], info["RSSI"]
        ]
        self.add_row(row)
        self.add_stat(row)
        try:
            DAILY_LOG_DIR.mkdir(parents=True, exist_ok=True)
            path = daily_log_path(event["start"])
            fresh = not path.exists() or path.stat().st_size == 0
            with path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if fresh:
                    writer.writerow(HEADERS)
                writer.writerow(row)
        except OSError as exc:
            # Warn with a dialog once per session; afterwards use the status
            # bar so a persistent problem doesn't raise a dialog per reception.
            if not self.csv_error_shown:
                self.csv_error_shown = True
                QMessageBox.warning(self, "CSV save failed",
                                    f"{exc}\n\nFurther save errors this session "
                                    "will be shown in the status bar.")
            else:
                self.statusBar().showMessage(f"CSV save failed: {exc}", 10000)

    def add_row(self, row):
        self.history_rows.insert(0, list(row))
        del self.history_rows[500:]
        self.filter_history()

    def clear_history_display(self):
        self.history_rows.clear()
        self.filter_history()

    def filter_history(self, _text=None):
        term = self.history_search.text().strip().casefold()
        visible = [row for row in self.history_rows
                   if not term or any(term in str(value).casefold() for value in row)]
        self.table.setSortingEnabled(False)
        self.table.setUpdatesEnabled(False)
        try:
            self.table.setRowCount(len(visible))
            for r, row in enumerate(visible):
                for c, value in enumerate(row):
                    self.table.setItem(r, c, QTableWidgetItem(str(value)))
        finally:
            self.table.setUpdatesEnabled(True)
            self.table.setSortingEnabled(True)
        self.history_match_count.setText(f"{len(visible):,} / {len(self.history_rows):,}")
        self.table.verticalScrollBar().setValue(0)

    def load_history(self):
        paths = sorted(DAILY_LOG_DIR.glob("reception_history_????-??-??.csv"))
        if LEGACY_LOG_FILE.exists():
            paths.insert(0, LEGACY_LOG_FILE)
        recent = deque(maxlen=500)
        problems = []
        for path in paths:
            # Each file is read in full before its rows are counted, so a file
            # that fails part-way never adds partial statistics.
            try:
                # utf-8-sig matches the archive browser and accepts a BOM.
                with path.open(newline="", encoding="utf-8-sig") as f:
                    reader = csv.reader(f)
                    if next(reader, None) != HEADERS:
                        continue
                    rows = [row for row in reader if len(row) == len(HEADERS)]
            except (OSError, csv.Error, UnicodeDecodeError) as exc:
                problems.append(f"{path.name}: {exc}")
                continue
            for row in rows:
                self.add_stat(row, refresh=False)
                recent.append(row)
        self.history_rows = list(reversed(recent))
        self.filter_history()
        self.refresh_stats()
        if problems:
            QMessageBox.warning(
                self, "History load warning",
                "These history files could not be read and were skipped. "
                "The files themselves were not changed.\n\n" + "\n".join(problems))

    def add_stat(self, row, refresh=True):
        # Statistics count completed reception events, not individual XML polls.
        try:
            duration = max(0.0, float(row[2]))
        except (ValueError, IndexError):
            duration = 0.0
        key = (row[5], row[3])
        self.statistics[key][0] += 1
        self.statistics[key][1] += duration
        self.total_receptions += 1
        self.total_seconds += duration
        if refresh:
            self.refresh_stats()

    def refresh_stats(self):
        self.summary.setText(
            f"{self.total_receptions:,} receptions • "
            f"{self.total_seconds:,.1f} seconds • "
            f"{len(self.statistics):,} active channels")
        ranked = sorted(self.statistics.items(),
                        key=lambda pair: (-pair[1][0], -pair[1][1]))
        self.stats_table.setSortingEnabled(False)
        self.stats_table.setRowCount(min(20, len(ranked)))
        for r, ((channel, system), (count, seconds)) in enumerate(ranked[:20]):
            for c, value in enumerate(
                (channel, system, str(count), f"{seconds:.1f}")
            ):
                self.stats_table.setItem(r, c, QTableWidgetItem(value))
        self.stats_table.setSortingEnabled(True)
        # Refreshes always show the leading statistics rows.
        self.stats_table.verticalScrollBar().setValue(0)

    def save_settings(self):
        self.settings.setValue("port", self.port.currentText())
        self.settings.setValue("baud", self.baud.currentText())
        self.settings.setValue("poll_ms", self.interval.value())
        self.settings.setValue("geometry", self.saveGeometry())
        for dock in self.docks:
            if dock.isFloating():
                self.settings.setValue("floating/" + dock.objectName(),
                                       dock.saveGeometry())
        self.settings.setValue("reception_splitter", self.reception_splitter.saveState())
        self.settings.setValue("dock_state", self.saveState())
        # Only save waterfall window geometry once it has been opened, so a
        # never-opened window doesn't overwrite the saved position.
        if getattr(self, "waterfall_geometry_restored", False):
            self.settings.setValue("waterfall/geometry", self.waterfall_window.saveGeometry())
            self.settings.setValue("waterfall/splitter", self.waterfall_splitter.saveState())
        self.settings.setValue("waterfall/open", self.waterfall_window.isVisible())
        self.settings.sync()

    def closeEvent(self, event):
        if self.thread and self.thread.isRunning():
            # Queued before stop(); the worker sends queued commands before
            # closing the port, so a diagnostic-held key is released.
            self.release_diagnostic_key()
            self.thread.stop()
        self.finish_event()
        self.save_settings()
        self.waterfall_window.hide()    # closes with the main window
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Monitor()
    window.show()
    sys.exit(app.exec())
