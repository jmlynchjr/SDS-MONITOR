# SDS100 Monitor

**Live monitoring, reception logging and remote control for the Uniden SDS100 scanner, on Linux.**

![Version](https://img.shields.io/badge/version-1.0--RC--Beta-orange)
![License: GPL v3+](https://img.shields.io/badge/license-GPL--3.0--or--later-blue)
![Platform](https://img.shields.io/badge/platform-Linux%20(Kubuntu)-lightgrey)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)

> **Status: v1.0-RC-Beta — release candidate, beta.** Feature-complete for 1.0 and tested on a real SDS100, but not yet widely used. Please back up your scanner's configuration before use and [report problems](../../issues).

SDS100 Monitor connects to an SDS100 over USB and shows what the scanner is receiving, keeps a searchable history of every reception, and lets you control the scanner from your desktop: holds and avoids, the keypad, volume and squelch, recording, quick keys, service types, location, and a live waterfall.

*Independent project — not affiliated with or endorsed by Uniden. See [ABOUT.md](ABOUT.md).*

## Features

**Monitoring and history**
- Live display of system, site, department, channel, frequency, talkgroup, unit ID, mode and signal strength.
- Every reception logged to daily CSV files, including trunked (with voice frequency), conventional, Custom/Quick Search and Close Call hits.
- Searchable history with right-click actions; archive browser for all past days; statistics by channel.
- **Activity charts:** activity by hour of day, per day or month, and top channels/talkgroups.
- **Unit ID log:** every radio unit heard, with a per-unit summary.
- **Alerts:** desktop notification and sound when a chosen channel, talkgroup, frequency or unit ID becomes active.

**Control**
- Hold (system, department, channel), resume scan, previous/next, temporary/permanent avoid and remove avoid.
- Virtual keypad and rotary knob, including FUNC and FUNC + long-press actions.
- Volume and squelch sliders, recording start/stop, set the scanner clock from the PC, tune to a frequency (Quick Search Hold).
- Battery level and charging state in the status bar.

**Scanner Tools** (View → Scanner Tools…)
- Browse favorites lists → systems → departments → channels/talkgroups loaded on the scanner, and hold or avoid any of them.
- Quick-key grids for favorites lists, systems and departments.
- Service type on/off, location and range with saved places.

**Waterfall** (View → Waterfall…)
- Separate, maximizable window with the scanner's live waterfall graph, click-to-tune, and span, step, hold, max-hold, gain and display controls.

## Requirements

- A **Uniden SDS100**, connected by USB and set to **Serial Port** mode (not Mass Storage).
- Linux with Python 3.9+, **PyQt6** and **pySerial**. Developed and tested on Kubuntu.
- Your user must be allowed to use the serial port. On Ubuntu-based systems, if you get "permission denied": `sudo usermod -aG dialout $USER`, then log out and back in.

## Install

```bash
sudo apt install python3-pyqt6 python3-serial
git clone <this repository URL> sds100-monitor   # or download and extract the source zip
cd sds100-monitor
bash install.sh
```

This installs to `~/SDS100Monitor-1.0-RC-Beta/` and adds **SDS100 Monitor** to the application menu. You can also run it straight from the source folder with `./launch.sh`.

To uninstall: `bash ~/SDS100Monitor-1.0-RC-Beta/uninstall.sh`. Your history, logs and settings are kept.

## Getting started

1. Connect the SDS100 by USB and choose **Serial Port** on the scanner.
2. Start SDS100 Monitor, pick the port (usually `/dev/ttyACM0`) and press **CONNECT**.
3. Panels are tabs that can be detached into their own windows (View menu, or right-click a tab).
4. Help → About shows the license, attribution and disclaimers.

Only one program can use the scanner's serial port at a time; SDS100 Monitor refuses to connect if another program (for example a terminal, or a second copy) has it open.

## Where your data is kept

Everything stays on your computer; nothing is sent over the internet.

| Path | Contents |
|---|---|
| `~/SDS100Monitor/history/` | reception history, one CSV per day |
| `~/SDS100Monitor/unit_ids/` | unit ID log, one CSV per day |
| `~/.config/SDS100Monitor/Monitor110.conf` | settings, window layout, alert rules, saved places |

## For developers

- [`docs/DEVELOPER_NOTES.md`](docs/DEVELOPER_NOTES.md) — architecture, the scanner protocol as implemented (what's verified and what isn't), data formats, project rules.
- [`docs/ROADMAP.md`](docs/ROADMAP.md) — planned features (event-driven status via PSI, Analyze tools) and ideas.
- [`tools/gsi_capture.py`](tools/gsi_capture.py) — capture the scanner's replies (status, waterfall data, any read-only command) for developing new features. Close SDS100 Monitor first.
- `bash tests/run_tests.sh` — logic tests using real scanner captures; needs only Python (no Qt, no scanner).

Command formats come from Uniden's *SDS100/SDS200/SDS150 Remote Command Specification* V2.00, checked against real captures wherever the specification is incomplete.

## License

Copyright © 2026 J. Lynch.

SDS100 Monitor is free software, licensed under the **GNU General Public License v3.0 or later** — see [LICENSE](LICENSE). It is distributed WITHOUT ANY WARRANTY.

Third-party components (Python, PyQt6, Qt, pySerial) are installed separately and keep their own licenses; see [ABOUT.md](ABOUT.md#attribution-third-party-software).

## AI use and disclaimers

This program was developed with substantial help from AI coding assistants (including Anthropic's Claude), directed, reviewed and tested by the developer. The full disclosure, trademark notice and disclaimers are in [ABOUT.md](ABOUT.md). In short:

- It **changes your scanner's settings** when you use its controls. Back up your configuration first.
- It is **not for emergency or safety-critical use**; logs and alerts are approximate.
- **Obey the law** where you live on receiving, recording and sharing radio communications.
- Uniden, SDS100 and Sentinel are trademarks of Uniden America Corporation; this project is not affiliated with Uniden.
