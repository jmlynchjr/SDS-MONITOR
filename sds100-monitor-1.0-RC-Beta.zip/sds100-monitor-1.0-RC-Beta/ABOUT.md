# About SDS100 Monitor

**SDS100 Monitor** v1.0-RC-Beta (release candidate, beta; internal build 1.1.21) — live monitoring, reception history, statistics and remote control for the Uniden SDS100 scanner, for Linux (Kubuntu).

**Developer and owner:** J. Lynch
**Copyright © 2026 J. Lynch**

---

## License

SDS100 Monitor is free and open-source software, licensed under the **GNU General Public License, version 3 or (at your option) any later version** (SPDX: `GPL-3.0-or-later`).

> SDS100 Monitor
> Copyright (C) 2026 J. Lynch
>
> This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
>
> This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
>
> You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

The full license text is in the `LICENSE` file distributed with the program.

**Why GPL v3:** SDS100 Monitor is built on PyQt6, which is distributed under the GPL v3. Software distributed together with PyQt6 under its free license must be GPL-compatible, so GPL-3.0-or-later is used for the whole program.

This license covers the program source code (`sds100_monitor.py`), its scripts (`install.sh`, `uninstall.sh`, `launch.sh`, `tools/gsi_capture.py`), the tests, the icon (`sds100-monitor.svg`) and the accompanying documentation, unless a file states otherwise. The sample scanner replies in `tests/samples/` are factual data captured from a scanner; radio unit IDs in them have been replaced with fictitious values.

---

## Attribution: third-party software

SDS100 Monitor uses the following software. It does not include or modify their code; they are installed separately (for example with `sudo apt install python3-pyqt6 python3-serial`) and remain under their own licenses.

| Component | Used for | Copyright / author | License |
|---|---|---|---|
| **Python 3** | programming language and standard library | Python Software Foundation | PSF License Agreement |
| **PyQt6** | Python bindings for Qt (windows, widgets, drawing) | Riverbank Computing Limited | GPL v3 (or Riverbank commercial license) |
| **Qt 6** | user-interface framework used through PyQt6 | The Qt Company Ltd. and other contributors | LGPL v3 / GPL v2 / GPL v3 (or commercial) |
| **pySerial** | serial-port communication with the scanner | Chris Liechti and contributors | BSD 3-Clause |

Optional desktop tools used only if present on the system: `notify-send` (libnotify) for alert notifications, `paplay` (PulseAudio/PipeWire) and the freedesktop sound theme for alert sounds. These are not distributed with the program.

### Scanner documentation

Scanner commands are implemented from Uniden's published documentation:

- *SDS100 (UB383Z) / SDS200 (UB384Z) / SDS150 (UB391Z) Remote Command Specification*, Version 2.00 (2025) and Version 1.02 (2023), Uniden America Corporation.
- *SDS200 Waterfall* operating manual and *Easier to Read SDS100/200 Manual*, Uniden America Corporation.

No Uniden software, firmware, database or document is included in this program. Behavior not fully described in those documents was determined by testing on the developer's own SDS100.

---

## Trademarks and affiliation

Uniden, Bearcat, SDS100, SDS200, SDS150 and Sentinel are trademarks or registered trademarks of Uniden America Corporation and/or its affiliates. Other product names are trademarks of their respective owners. They are used here only to identify the hardware the program works with.

**SDS100 Monitor is an independent project. It is not made, endorsed, sponsored, supported or approved by Uniden America Corporation or its affiliates.** For support with the scanner itself, contact Uniden.

---

## Use of artificial intelligence in development

This program was developed with substantial help from AI (artificial intelligence) coding assistants, directed, reviewed and tested by the developer:

- Internal builds 1.1.13 to 1.1.21, released as v1.0-RC-Beta, were developed with **Claude**, an AI assistant made by Anthropic. Claude wrote and revised code, tests and documentation, and analyzed the scanner's command specification and data captured from the scanner.
- Earlier versions were also developed with the help of AI tools.

All features were specified by the developer and tested on a real SDS100 before release. However, AI-generated code can contain mistakes that testing did not reveal. Please read the disclaimers below, and report any problems you find.

---

## Disclaimers

**No warranty.** The program is provided "as is", without warranty of any kind, express or implied, including fitness for a particular purpose. To the extent permitted by law, the developer is not liable for any damage or loss arising from its use, including changes to scanner settings, lost or corrupted scanner data, or damage to equipment (see sections 15 and 16 of the GNU GPL v3).

**It changes your scanner's settings.** Many features send commands that change the scanner's configuration: volume, squelch, avoids, quick keys, service types, location, clock, recording and key presses. Back up your scanner's configuration (for example with Uniden Sentinel) before using these features. The **Keypress Protocol Diagnostic** sends undocumented commands and is experimental; use it only while watching the scanner.

**Not for emergencies or safety-critical use.** Reception logs, durations, statistics and alerts are approximate. Status is read by polling, so short transmissions can be missed or merged, and alerts may be late or missed. Do not rely on this program for emergency notification, public safety or any purpose where a missed or incorrect alert could cause harm.

**Obey the law.** Laws on owning and using scanners, and on receiving, recording, logging or sharing radio communications, differ between countries, states and localities. In the United States, for example, federal law restricts intercepting certain communications and sharing or using what is heard. Some states limit scanner use in vehicles. You are responsible for using this program and your scanner lawfully.

**Your data stays on your computer.** The program sends nothing over the internet. Reception history, unit ID logs, alert rules and settings are stored only on your own computer (`~/SDS100Monitor/` and `~/.config/SDS100Monitor/`). Unit IDs identify radios, not people, but treat these logs with care if you share them.

**Compatibility.** Tested only with an SDS100 on Kubuntu Linux. Other scanner models, firmware versions and operating systems may behave differently.

---

## Source code and contributions

Under the GPL, anyone who receives this program may obtain, study, change and share its source code, provided that copies and modified versions are also distributed under GPL-3.0-or-later, with the source code and this notice. Modified versions should be clearly marked as changed and must not suggest that J. Lynch produced or endorses them.
