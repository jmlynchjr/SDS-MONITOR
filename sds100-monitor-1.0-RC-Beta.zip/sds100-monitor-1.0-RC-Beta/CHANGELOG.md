# Changelog

All notable changes to SDS100 Monitor. Before the first public release the program was developed as a series of internal builds (1.1.12 – 1.1.21); their notes are kept below.

## v1.0-RC-Beta — first public release candidate (beta)

Same features as internal build 1.1.21, prepared for publication:

- Licensed under **GPL-3.0-or-later**; `LICENSE` (GNU GPL v3 text) and license headers in all source files.
- `ABOUT.md`: attribution, trademarks, AI-use disclosure and disclaimers.
- New **Help** menu: *About SDS100 Monitor…* and *License…*.
- New `uninstall.sh`; `install.sh` checks for PyQt6 and pySerial and installs only the program files.
- Developer documentation (`docs/`), capture tool (`tools/gsi_capture.py`) and logic tests (`tests/`) included. Radio unit IDs in the test samples are replaced with fictitious values.
- The internal `cleanup_old_installs.sh` (specific to the developer's earlier installs) is not included.

## v1.1.21: Quick Keys fix

- **Fixed: the Quick Keys tab rejected the scanner's replies as "unexpected".** Replies were cut off at 160 characters before reaching the program's features, but a quick-key reply holds 100 values (about 200 characters). Replies are now passed on whole; only the text shown in the status line is shortened. Confirmed with an `FQK` reply captured from the SDS100.

## v1.1.20: Scanner Tools, alerts, charts and unit ID log

**View → Scanner Tools…** opens a window with five tabs (commands from Remote Command Specification V2.00):

- **Lists:** LOAD FAVORITES LISTS, then expand favorites lists → systems → departments / sites → channels or talkgroups. Each level is read from the scanner when you expand it (`GLT`). Right-click any system, department, site, channel or talkgroup to **hold** on it, **temporarily avoid**, **permanently avoid** (asks first), or **remove an avoid** — not just the one currently on screen. The avoid column shows each item's current state; the list refreshes after a change.
- **Quick Keys:** favorites list, system and department quick keys as 10 × 10 grids (green = enabled, grey = disabled, blank = not assigned). Click a key to turn it on or off (`FQK` / `SQK` / `DQK`). Choose which favorites list and system the lower grids show. Favorites list names appear in tooltips once the Lists tab has loaded them.
- **Service Types:** the 30 preset and 10 custom service types as checkboxes (`SVC`). READ, change, then APPLY; ALL ON / ALL OFF.
- **Location:** read and set the scanner's latitude, longitude and range (`LCR`). The spec doesn't define the number format, so the scanner must be read first; changes are sent in the same format and read back to confirm. **Saved places** store locations by name; double-click one to send it to the scanner.
- **Alerts:** rules such as "Channel is Sheriff East Dispatch", "Talkgroup is TGID:44002", "Unit ID contains 1000001" or "Any field contains Fire". A matching reception raises a desktop notification and a sound, at most once per reception and no more often than the repeat interval you choose (default 60 s). Rules can be switched off without deleting them; the last 50 alerts are listed. Quick way to add one: right-click a reception in history → Alert When This Channel / Talkgroup Is Active, or right-click a channel in the Lists tab.

**History → Activity Charts…:** receptions by hour of day, per day (per month for long periods) and the top 15 channels/talkgroups, for the last 7, 30, 90 or 365 days or all history. Filter by system; measure by number of receptions or air time. Hover a bar for its value.

**History → Unit ID Log…:** every radio unit heard is now logged to `~/SDS100Monitor/unit_ids/unit_ids_YYYY-MM-DD.csv` (time, unit ID and name, system, site, department, channel, talkgroup, frequency) — one row each time a different unit transmits. The viewer has a **Units** summary (times heard, first/last heard, main talkgroups) and **All entries**, with a period filter and search. Double-click a unit to see all its transmissions. The reception history CSV format is unchanged.

**Notes:** Only the favorites-list XML is shown as an example in the spec, so lists below that level are read generically, and long lists sent in parts are followed automatically. If anything shows up wrong, the updated `gsi_capture.py` (option `r`) saves the scanner's exact reply to read-only commands such as `GLT,SYS,0`, `FQK` or `LCR`.

## v1.1.19: Audio, battery, recording, clock and tuning

New sections in the **SCANNER CONTROL** panel (which now scrolls), using commands from Remote Command Specification V2.00:

- **Audio:** Volume and Squelch sliders (0–15 on the SDS100). They follow the scanner, so turning its knobs moves the sliders; while you drag a slider, the scanner's reports don't move it back. A change is sent once the slider stops moving (`VOL,n` / `SQL,n`).
- **Battery:** the status bar shows charge level and state (charging, fully charged, no external power…), checked every 30 seconds with `GCS`. Hover for voltage, current and battery temperature. It turns red at 15% or below when not charging, or if the scanner reports a temperature or power fault.
- **Recording:** start/stop button (`URC`), a red ● REC indicator in the status bar while recording, and plain explanations of the scanner's error codes (SD card error, battery too low, session limit, clock lost).
- **Scanner clock:** READ CLOCK shows the scanner's time, its difference from the PC, and whether the scanner reports its clock as valid. SET CLOCK FROM PC reads the scanner's daylight-saving setting first and keeps it, sets the date and time, then reads the clock back to confirm. If the result is about an hour off, it says so.
- **Tune to frequency:** type a frequency and HOLD ON FREQUENCY, or right-click a reception in history → Hold on This Frequency (`QSH`). The spec doesn't say how QSH expects the frequency, so the program tries 100 Hz units first (the older Uniden convention), then MHz if rejected. It confirms from the scanner's report that it really went to the requested frequency, and remembers the format that worked.
- The serial reader now also accepts replies ending in a line feed (GCS replies do).

## v1.1.18: Waterfall in its own window

- **View → Waterfall…** opens the waterfall in its own window, which can be moved, resized and maximized independently of the main window. It is no longer a dockable tab, so it doesn't hide the other panels.
- The live graph is on the left and takes all extra space when the window is enlarged. The controls are in a column on the right, with a draggable divider between them.
- The window's size, position, divider and open/closed state are remembered. If it was open when you quit, it reopens at the next start.
- Graph data is only requested from the scanner while the waterfall window is open.
- The waterfall was removed from the PANEL selector and the dock tabs.

## v1.1.17: Live waterfall graph

- **Live waterfall graph.** While the scanner is in waterfall mode, the panel shows the current signal trace (top) and a scrolling waterfall (bottom), with the marker drawn in green and the lower, center and upper frequencies along the bottom.
  - The data is the scanner's own waterfall graph, requested with `GWF,1,ON`: 240 levels per frame, one frame per request (format confirmed from SDS100 captures, 2026-10-26).
  - Update rate: 4, 2 or 1 frames per second. The graph and rate settings are remembered.
  - Contrast adjusts automatically to the noise floor.
  - The history clears when the span or center frequency changes, so old rows never line up with the wrong frequencies.
- **Click-to-tune.** Hover over the graph to see the frequency; double-click to move the scanner's marker there. It is rounded to the current step and sent as keypad entry + E, the same as the marker-frequency box. Only works while waterfall mode is detected (or the override is ticked).
- **One program at a time on the serial port.** SDS100 Monitor now refuses to connect if another program already has the scanner's port open, and says which one. It also locks the port while connected. Two programs reading the scanner at once split its replies and corrupt both.

## v1.1.16: Waterfall control panel

A new **WATERFALL** panel (from v1.1.18 it opens in its own window from View → Waterfall…). Key functions come from the SDS100/SDS200 Waterfall manual, and key codes and status fields from Remote Command Specification V2.00.

- **Waterfall status:** center frequency, span, range, step, modulation, marker frequency and RF gain, read from the scanner's status report while the waterfall is on screen.
- **Start waterfall:** two ways to start it.
  - *START WATERFALL (JPM)* sends `JPM,WF_MODE,0`. The spec lists WF_MODE but marks its index "Reserve", so this is **untested**; the reply (OK or NG) shows in the panel.
  - *START (FUNC + key)* uses the documented method: assign Waterfall to a search key on the scanner (Menu → Search for → Set Search Key → Search Key n → Waterfall), pick that key, and press START.
- **Display:** SPAN (Soft Key 2), STEP (FUNC + Soft Key 1), HOLD / SWEEP (Soft Key 3), MAX HOLD (FUNC + Soft Key 2), FFT / WF SPLIT (FUNC + 9), RF GAIN (FUNC + 0), EXIT TO SCAN (Soft Key 1).
- **Marker / tuning:** step and fast tuning (knob, FUNC + knob), MARKER TO CENTER (FUNC + Soft Key 3), CONFIRM (E), and a marker-frequency box that types the frequency on the keypad and presses E. Frequencies outside SDS100 coverage are rejected before anything is sent.
- **Safety:** in scan mode the soft keys act as System / Department / Channel hold, so all controls except START are enabled only while the scanner reports waterfall mode. If detection doesn't work on your scanner, a checkbox enables them anyway.
- Waterfall detection and the status fields were confirmed against status reports captured from the SDS100 in v1.1.17.

## v1.1.15

- **Site and Unit ID in Scanner Information.** For trunked calls, the panel now shows the site (e.g. "Greenville County Simulcast") and the unit ID of the radio transmitting. If the unit has a stored name, both are shown, e.g. "Engine 12 (UID:1000002)". Both can be copied from the right-click menu. They are display-only and not written to the history CSV, so the file format is unchanged.
- **Cleanup keeps only the newest version.** The cleanup script now removes every older install, including v9, v24 and earlier 1.1.x builds, unless kept with `--keep`. (Internal tool; not included in public releases.)

## v1.1.14: search, Close Call and trunked frequencies

Based on GSI samples captured from the SDS100 on 2026-10-26.

- **Search and Close Call hits are now logged.** They were previously ignored because the scanner reports them in a `SrchFrequency` element, with no system, department or channel name. In history and statistics:
  - System = the scanner mode (e.g. "Custom Search", "Close Call Only")
  - Department = the search bank name (e.g. "Custom 3"), or "—" for Close Call
  - Channel = the frequency, so statistics show which frequencies were most active
- **Trunked receptions now record the voice frequency.** It comes from the scanner's `SiteFrequency` report; before, trunked calls were logged with "—".
- Hold, avoid and next/previous controls stay unavailable during search hits; they need a stored channel.
- The CSV format is unchanged, so existing history files and the archive browser work as before.

## v1.1.13: bug fixes

- **Command replies are no longer lost.** Replies such as `KEY,OK` that arrived together with a GSI status update were discarded, so the control and keypad panels often showed only `SENT:`. Serial data is now read strictly in arrival order.
- **Saved statistics persist across connections.** Connecting used to reset the statistics to zero, hiding the totals loaded from saved history.
- **Damaged history files no longer crash the program.** An unreadable CSV is now skipped with one warning listing the file, and the other files still load. Files with a byte-order mark now load at startup too.
- **Queued commands are sent before disconnecting.** Commands still waiting when you disconnect or close the program are now sent before the port closes. A key held from the Keypress Protocol Diagnostic is released on disconnect and on program close, not only when the diagnostic window is closed.
- **REMOVE AVOID targets the right channel.** It now removes the avoid from the channel most recently avoided with TEMPORARY AVOID, which the button names. Before, it acted on whichever channel was displayed after the scanner moved on. Both actions ask for confirmation and show the channel name.
- **Diagnostic log survives reconnecting.** The diagnostic window's reply log keeps working after a disconnect/reconnect.
- **Consistent reception durations.** The end of a reception is estimated as one polling interval after it was last seen, whether it ended normally, changed channel, or was cut off by a disconnect.

## v1.1.13: smaller improvements

- Changing the polling interval takes effect immediately while connected.
- The status bar shows the connected scanner's model and firmware (from MDL/VER), with a note if the device does not report itself as an SDS100.
- Right-click menus now work on dock tab bars created by dragging panels into new groups.
- A CSV save failure shows a dialog once per session, then status-bar messages, instead of a dialog after every reception.
- Removed unused code and an outdated long-press explanation.
- The installer refuses to run from inside its own install folder.

## Earlier internal builds (up to v1.1.12)

These were all labelled v1.1.12 in earlier builds; the individual version numbers were not kept.

**Live monitor and history**
- Reception statistics and history use a draggable vertical splitter; the split is saved between sessions.
- New receptions scroll history to the newest entry; refreshed statistics scroll to the top.
- History → Browse CSV archives (also from Reception History): browse and search any daily CSV or the legacy history, 250 rows per page, export matching rows. Archives are read-only.

**Appearance and right-click menus**
- Decorated dock tab headers: rounded corners, clearer active tab, hover highlights, accent underline.
- Context menus with distinct mouse-over highlighting.
- Right-click the scanner status or an information value to copy fields, hold/resume (when connected), or open history.
- Right-click dock tabs or title areas to detach/reattach, hide, show all, reset, or save the layout.
- Reception History, Statistics and Archive Browser context menus.

**Virtual keypad**
- Right-click any key for normal press, FUNC + press, FUNC + LONG PRESS where available, and a keypad reference.
- Weather Scan uses the documented `JPM,WX_MODE,NORMAL`.
- User-verified FUNC + long-press actions for 4, 8, 9, AVOID and REPLAY send `KEY,F,P` followed by `KEY,<key>,L`. Avoid and Replay long-press actions are labelled user-tested, without claiming an exact result.
- Holding AVOID without FUNC (documented in the physical manual) is not yet enabled.

**Experimental Keypress Protocol Diagnostic**
- Right-click any key → Keypress Protocol Diagnostic. Sends single manual `KEY` commands with modes P/L/H/R, with a preview, an acknowledgement checkbox and extra confirmation for L/H, a reply log, and manual release. L/H/R are not documented in the remote command spec.
- Does not modify firmware or GPS.

The serial protocol and CSV format are unchanged throughout.
